import { pgTable, text, serial, integer, boolean, doublePrecision, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Properties table
export const properties = pgTable("properties", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  address: text("address").notNull(),
  price: text("price").notNull(),
  beds: integer("beds"),
  baths: integer("baths"),
  area: integer("area").notNull(),
  propertyType: text("property_type").notNull(),
  listingType: text("listing_type").notNull(),
  imageUrl: text("image_url").notNull(),
  additionalImages: jsonb("additional_images").$type<string[]>(),
  description: text("description"),
  features: jsonb("features").$type<string[]>(),
  lat: doublePrecision("lat").notNull(),
  lng: doublePrecision("lng").notNull(),
  landArea: integer("land_area"),
  yearBuilt: integer("year_built"),
  // Dati catastali
  cadastralNumber: text("cadastral_number"),
  cadastralZone: text("cadastral_zone"),
  cadastralSection: text("cadastral_section"),
  cadastralFolio: text("cadastral_folio"),
  cadastralParcel: text("cadastral_parcel"),
  cadastralSubparcel: text("cadastral_subparcel"),
  zoning: text("zoning"),
  buildingIndex: doublePrecision("building_index"),
  buildingHeight: doublePrecision("building_height"),
  createdAt: text("created_at").notNull().default("NOW()"),
});

// Professionals table
export const professionals = pgTable("professionals", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // architect, notary, artisan
  address: text("address").notNull(),
  phone: text("phone"),
  email: text("email"),
  description: text("description"),
  lat: doublePrecision("lat").notNull(),
  lng: doublePrecision("lng").notNull(),
  createdAt: text("created_at").notNull().default("NOW()"),
});

// Banks table
export const banks = pgTable("banks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  phone: text("phone"),
  email: text("email"),
  website: text("website"),
  lat: doublePrecision("lat").notNull(),
  lng: doublePrecision("lng").notNull(),
  logoUrl: text("logo_url"), // URL per il logo della banca
  createdAt: text("created_at").notNull().default("NOW()"),
});

// Create insert schemas
export const propertyInsertSchema = createInsertSchema(properties);
export const professionalInsertSchema = createInsertSchema(professionals);
export const bankInsertSchema = createInsertSchema(banks);

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  createdAt: text("created_at").notNull().default("NOW()"),
});

// Favorites table
export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  propertyId: integer("property_id").references(() => properties.id),
  professionalId: integer("professional_id").references(() => professionals.id),
  bankId: integer("bank_id").references(() => banks.id),
  createdAt: text("created_at").notNull().default("NOW()"),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  favorites: many(favorites),
}));

export const favoritesRelations = relations(favorites, ({ one }) => ({
  user: one(users, { fields: [favorites.userId], references: [users.id] }),
  property: one(properties, { fields: [favorites.propertyId], references: [properties.id] }),
  professional: one(professionals, { fields: [favorites.professionalId], references: [professionals.id] }),
  bank: one(banks, { fields: [favorites.bankId], references: [banks.id] }),
}));

// Create insert schemas
export const userInsertSchema = createInsertSchema(users, {
  username: (schema) => schema.min(3, "Nome utente deve essere di almeno 3 caratteri"),
  email: (schema) => schema.email("Inserisci un indirizzo email valido"),
  password: (schema) => schema.min(6, "La password deve essere di almeno 6 caratteri"),
});

export const favoriteInsertSchema = createInsertSchema(favorites);

// Create types
export type Property = typeof properties.$inferSelect;
export type InsertProperty = z.infer<typeof propertyInsertSchema>;

export type Professional = typeof professionals.$inferSelect;
export type InsertProfessional = z.infer<typeof professionalInsertSchema>;

export type Bank = typeof banks.$inferSelect;
export type InsertBank = z.infer<typeof bankInsertSchema>;

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof userInsertSchema>;

export type Favorite = typeof favorites.$inferSelect;
export type InsertFavorite = z.infer<typeof favoriteInsertSchema>;
