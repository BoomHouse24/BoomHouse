# BoomHouse - Piattaforma Immobiliare Svizzera

BoomHouse è un'applicazione web completa per la ricerca e la gestione immobiliare nel mercato svizzero. Integra dati catastali, mappe interattive, e strumenti finanziari per semplificare l'esperienza di ricerca immobiliare.

## Funzionalità Principali

- Ricerca avanzata di proprietà con filtri per tipo, prezzo, location e caratteristiche
- Mappe interattive con Leaflet.js che mostrano proprietà, professionisti e banche
- Visualizzazione dei dati catastali ufficiali
- Calcolo ipotecario con analisi finanziaria e esportazione PDF
- Booms per contenuti multimediali con audio integrato
- Interfaccia ottimizzata per dispositivi mobili
- Directory di professionisti (architetti, notai, artigiani)
- Pubblicazione annunci immobiliari

## Tecnologie Utilizzate

- Frontend: React, TailwindCSS, shadcn/ui
- Backend: Node.js con Express
- Database: PostgreSQL con Drizzle ORM
- Query Management: React Query (TanStack Query)
- Mappe: Leaflet.js
- Visualizzazione 3D: Three.js

## Installazione

1. Estrai il file ZIP in una cartella di progetto
2. Installa le dipendenze:

```bash
npm install
```

3. Configura il database PostgreSQL:

```bash
npm run db:push
npm run db:seed
```

4. Avvia l'applicazione:

```bash
npm run dev
```

## Struttura del Progetto

- `/client` - Frontend React
  - `/src/components` - Componenti UI
  - `/src/pages` - Pagine dell'applicazione
  - `/src/hooks` - Custom React hooks
  - `/src/lib` - Utilità e configurazioni

- `/server` - Backend Express
  - `routes.ts` - API endpoints
  - `auth.ts` - Autenticazione e autorizzazione
  - `storage.ts` - Funzioni di accesso al database

- `/shared` - Codice condiviso tra frontend e backend
  - `schema.ts` - Schema del database con Drizzle ORM

- `/db` - Configurazione e seeding del database

## Variabili d'ambiente richieste

- `DATABASE_URL` - URL per la connessione al database PostgreSQL
- `SESSION_SECRET` - Segreto per la gestione delle sessioni
- `LOCALCH_API_KEY` (opzionale) - Per l'integrazione con local.ch

## Note per lo Sviluppo

- Il sistema utilizza React Query per gestire lo stato delle richieste API
- I componenti sono stati ottimizzati per prestazioni mobile-first
- La mappatura utilizza OpenStreetMap tramite Leaflet
- Il calcolo ipotecario segue le normative svizzere aggiornate al 2025