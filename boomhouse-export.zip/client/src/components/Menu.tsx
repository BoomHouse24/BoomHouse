import { useState } from 'react';
import {
  Building,
  Building2,
  Mountain,
  PanelTop,
  ChevronDown,
  ChevronUp,
  Users,
  Home,
  Info,
  HelpCircle,
  Star,
  MessageSquare,
  Briefcase
} from 'lucide-react';

interface MenuItemProps {
  icon: React.ReactNode;
  title: string;
  href: string;
  children?: React.ReactNode;
}

const MenuItem: React.FC<MenuItemProps> = ({ icon, title, href, children }) => {
  const [isOpen, setIsOpen] = useState(false);

  if (children) {
    return (
      <div className="relative group">
        <div 
          className="flex items-center justify-between p-3 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer"
          onClick={() => setIsOpen(!isOpen)}
        >
          <div className="flex items-center">
            {icon}
            <span className="ml-3">{title}</span>
          </div>
          {isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </div>
        {isOpen && (
          <div className="pl-10 bg-gray-50 dark:bg-gray-900">
            {children}
          </div>
        )}
      </div>
    );
  }

  return (
    <a
      href={href}
      className="flex items-center p-3 hover:bg-gray-100 dark:hover:bg-gray-800"
    >
      {icon}
      <span className="ml-3">{title}</span>
    </a>
  );
};

export default function Menu() {
  return (
    <div className="bg-white dark:bg-gray-950 shadow-lg rounded-lg overflow-hidden w-full max-w-xs border border-gray-200 dark:border-gray-800">
      <div className="p-3 bg-blue-600 text-white font-medium">
        Menu principale
      </div>
      
      <div className="divide-y divide-gray-200 dark:divide-gray-800">
        {/* BOOMHOUSE Section */}
        <MenuItem 
          icon={<Home size={18} />} 
          title="BOOMHOUSE" 
          href="/"
        >
          <MenuItem icon={<Info size={18} />} title="Chi siamo" href="/chi-siamo" />
          <MenuItem icon={<HelpCircle size={18} />} title="Come funziona" href="/come-funziona" />
          <MenuItem icon={<Star size={18} />} title="Recensioni" href="/recensioni" />
          <MenuItem icon={<MessageSquare size={18} />} title="Contattaci" href="/contattaci" />
          <MenuItem icon={<Briefcase size={18} />} title="Diventa partner" href="/diventa-partner" />
        </MenuItem>
        
        {/* IMMOBILI Section */}
        <MenuItem 
          icon={<Building size={18} />} 
          title="IMMOBILI" 
          href="#"
        >
          <MenuItem icon={<Home size={18} />} title="Case e appartamenti" href="/case-appartamenti" />
          <MenuItem icon={<Building2 size={18} />} title="Immobili commerciali" href="/immobili-commerciali" />
          <MenuItem icon={<Mountain size={18} />} title="Terreni" href="/terreni" />
          <MenuItem icon={<PanelTop size={18} />} title="Annunci più visualizzati" href="/annunci-popolari" />
          <MenuItem icon={<Users size={18} />} title="Inserisci un annuncio" href="/inserisci-annuncio" />
        </MenuItem>
      </div>
    </div>
  );
}