import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar } from "@/components/ui/avatar";
import { AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { X, MessageSquare, Send } from "lucide-react";

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

export default function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [inputValue, setInputValue] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      text: "Benvenuto in BoomHouse! Come posso aiutarti?",
      isBot: true,
      timestamp: new Date(),
    },
  ]);
  const inputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Common questions and answers
  const commonResponses: Record<string, string> = {
    "ciao": "Ciao! Come posso aiutarti con BoomHouse oggi?",
    "aiuto": "Posso aiutarti con ricerche immobiliari, calcolo ipoteca, informazioni catastali e molto altro. Cosa ti interessa?",
    "ipoteca": "BoomHouse offre un calcolatore di ipoteca che ti permette di stimare la sostenibilità del tuo investimento. Puoi anche valutare l'impatto di lavori fatti in proprio sul costo totale.",
    "catasto": "BoomHouse integra dati catastali per tutte le proprietà. Puoi cercare proprietà per numero catastale, zona, sezione, foglio e particella.",
    "banche": "Abbiamo partnership con le principali banche svizzere. Puoi trovare la banca più vicina alle proprietà che ti interessano e ricevere consigli personalizzati sul tuo mutuo.",
    "professionisti": "BoomHouse ti mette in contatto con architetti, notai, artigiani e assicurazioni che operano nella zona della proprietà che ti interessa.",
    "contatti": "Hai domande o suggerimenti? Scrivi a info@boomhouse.ch o chiamaci al +41 XX XXX XX XX.",
    "terreni": "I terreni in vendita su BoomHouse includono informazioni dettagliate su accessi fognari, elettrici e altre utenze essenziali."
  };

  // Auto scroll to bottom on new messages
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleToggleChat = () => {
    setIsOpen(!isOpen);
    if (!isOpen) {
      // Focus the input field when opening the chat
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  };

  const getResponse = (userMessage: string): string => {
    const normalizedInput = userMessage.toLowerCase().trim();
    
    // Check for specific keywords in the user's message
    for (const [keyword, response] of Object.entries(commonResponses)) {
      if (normalizedInput.includes(keyword)) {
        return response;
      }
    }
    
    // Generic responses for unrecognized inputs
    const genericResponses = [
      "Mi dispiace, non ho informazioni specifiche su questo argomento. Posso aiutarti con ricerche immobiliari, calcolo ipoteche o informazioni sui professionisti.",
      "Non sono sicuro di capire. Prova a chiedermi di ipoteche, proprietà, catasto o professionisti come architetti, notai e assicurazioni.",
      "Questa è una domanda interessante. Per assistenza più dettagliata, ti consiglio di contattare il nostro team all'indirizzo info@boomhouse.ch.",
    ];
    
    return genericResponses[Math.floor(Math.random() * genericResponses.length)];
  };

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      id: `user-${Date.now()}`,
      text: inputValue,
      isBot: false,
      timestamp: new Date(),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    
    // Simulate bot typing with a small delay
    setTimeout(() => {
      const botResponse: Message = {
        id: `bot-${Date.now()}`,
        text: getResponse(inputValue),
        isBot: true,
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, botResponse]);
    }, 800);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };
  
  return (
    <>
      {/* Floating chat button */}
      <Button
        onClick={handleToggleChat}
        className={`fixed bottom-20 right-4 z-40 rounded-full w-12 h-12 p-0 shadow-lg ${
          isOpen ? "bg-gray-700" : "bg-primary"
        }`}
      >
        {isOpen ? <X size={20} /> : <MessageSquare size={20} />}
      </Button>

      {/* Chat window */}
      {isOpen && (
        <Card className="fixed bottom-36 right-4 z-40 w-80 md:w-96 shadow-xl border border-gray-200">
          <CardHeader className="bg-primary text-white py-3 px-4">
            <CardTitle className="text-base font-medium">Assistente BoomHouse</CardTitle>
          </CardHeader>
          <ScrollArea className="h-64 p-4">
            <CardContent className="space-y-4 pt-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${
                    message.isBot ? "justify-start" : "justify-end"
                  }`}
                >
                  <div
                    className={`flex items-start max-w-[80%] ${
                      message.isBot ? "flex-row" : "flex-row-reverse"
                    }`}
                  >
                    {message.isBot && (
                      <Avatar className="h-8 w-8 mr-2">
                        <AvatarImage src="/logo-small.svg" alt="BoomHouse" />
                        <AvatarFallback>BH</AvatarFallback>
                      </Avatar>
                    )}
                    <div
                      className={`rounded-lg px-3 py-2 text-sm ${
                        message.isBot
                          ? "bg-gray-100"
                          : "bg-primary text-white"
                      }`}
                    >
                      {message.text}
                    </div>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </CardContent>
          </ScrollArea>
          <CardFooter className="border-t p-2">
            <div className="flex w-full items-center space-x-2">
              <Input
                ref={inputRef}
                placeholder="Scrivi un messaggio..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                className="flex-1"
              />
              <Button size="icon" onClick={handleSendMessage}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </CardFooter>
        </Card>
      )}
    </>
  );
}