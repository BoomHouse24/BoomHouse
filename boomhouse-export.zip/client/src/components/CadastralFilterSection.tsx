import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { FilterType } from "@/lib/types";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface CadastralFilterSectionProps {
  filters: FilterType;
  setTempFilters: (filters: FilterType) => void;
}

export default function CadastralFilterSection({ 
  filters, 
  setTempFilters 
}: CadastralFilterSectionProps) {
  
  // Gestori dei cambiamenti di input
  const handleCadastralNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTempFilters({
      ...filters,
      cadastralNumber: e.target.value || undefined,
    });
  };

  const handleCadastralZoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTempFilters({
      ...filters,
      cadastralZone: e.target.value || undefined,
    });
  };

  const handleCadastralSectionChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTempFilters({
      ...filters,
      cadastralSection: e.target.value || undefined,
    });
  };

  const handleCadastralFolioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTempFilters({
      ...filters,
      cadastralFolio: e.target.value || undefined,
    });
  };

  const handleCadastralParcelChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTempFilters({
      ...filters,
      cadastralParcel: e.target.value || undefined,
    });
  };

  const handleZoningChange = (value: string) => {
    setTempFilters({
      ...filters,
      zoning: value || undefined,
    });
  };

  const handleMinBuildingIndexChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTempFilters({
      ...filters,
      minBuildingIndex: e.target.value ? parseFloat(e.target.value) : undefined,
    });
  };

  const handleMaxBuildingIndexChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTempFilters({
      ...filters,
      maxBuildingIndex: e.target.value ? parseFloat(e.target.value) : undefined,
    });
  };

  const handleMinBuildingHeightChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTempFilters({
      ...filters,
      minBuildingHeight: e.target.value ? parseFloat(e.target.value) : undefined,
    });
  };

  const handleMaxBuildingHeightChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTempFilters({
      ...filters,
      maxBuildingHeight: e.target.value ? parseFloat(e.target.value) : undefined,
    });
  };

  const handleCadastralOnlyChange = (checked: boolean) => {
    setTempFilters({
      ...filters,
      showCadastralOnly: checked,
    });
  };

  return (
    <Accordion type="single" collapsible className="w-full">
      <AccordionItem value="cadastral-filters">
        <AccordionTrigger className="text-sm font-medium text-gray-700">
          Filtri Catastali
        </AccordionTrigger>
        <AccordionContent>
          <div className="space-y-4">
            {/* Switch per mostrare solo proprietà con dati catastali */}
            <div className="flex items-center justify-between">
              <Label htmlFor="show-cadastral-only" className="text-sm text-gray-700">
                Solo proprietà con dati catastali
              </Label>
              <Switch
                id="show-cadastral-only"
                checked={filters.showCadastralOnly || false}
                onCheckedChange={handleCadastralOnlyChange}
              />
            </div>

            {/* Numero catastale */}
            <div>
              <Label htmlFor="cadastral-number" className="text-sm font-medium text-gray-700">
                Numero Catastale
              </Label>
              <Input
                id="cadastral-number"
                placeholder="Inserisci numero catastale"
                value={filters.cadastralNumber || ""}
                onChange={handleCadastralNumberChange}
                className="mt-1"
              />
            </div>

            {/* Zona e Sezione */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="cadastral-zone" className="text-sm font-medium text-gray-700">
                  Zona
                </Label>
                <Input
                  id="cadastral-zone"
                  placeholder="Zona"
                  value={filters.cadastralZone || ""}
                  onChange={handleCadastralZoneChange}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="cadastral-section" className="text-sm font-medium text-gray-700">
                  Sezione
                </Label>
                <Input
                  id="cadastral-section"
                  placeholder="Sezione"
                  value={filters.cadastralSection || ""}
                  onChange={handleCadastralSectionChange}
                  className="mt-1"
                />
              </div>
            </div>

            {/* Foglio e Particella */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="cadastral-folio" className="text-sm font-medium text-gray-700">
                  Foglio
                </Label>
                <Input
                  id="cadastral-folio"
                  placeholder="Foglio"
                  value={filters.cadastralFolio || ""}
                  onChange={handleCadastralFolioChange}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="cadastral-parcel" className="text-sm font-medium text-gray-700">
                  Particella
                </Label>
                <Input
                  id="cadastral-parcel"
                  placeholder="Particella"
                  value={filters.cadastralParcel || ""}
                  onChange={handleCadastralParcelChange}
                  className="mt-1"
                />
              </div>
            </div>

            {/* Zoning */}
            <div>
              <Label htmlFor="zoning" className="text-sm font-medium text-gray-700">
                Zona Urbanistica
              </Label>
              <Select
                value={filters.zoning || ""}
                onValueChange={handleZoningChange}
              >
                <SelectTrigger id="zoning" className="mt-1">
                  <SelectValue placeholder="Tutte le Zone" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Tutte le Zone</SelectItem>
                  <SelectItem value="residential">Residenziale</SelectItem>
                  <SelectItem value="commercial">Commerciale</SelectItem>
                  <SelectItem value="industrial">Industriale</SelectItem>
                  <SelectItem value="agricultural">Agricola</SelectItem>
                  <SelectItem value="mixed">Mista</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Indice di edificabilità */}
            <div>
              <Label htmlFor="building-index" className="text-sm font-medium text-gray-700">
                Indice di Edificabilità
              </Label>
              <div className="mt-1 flex space-x-2">
                <Input
                  type="number"
                  id="min-building-index"
                  placeholder="Min"
                  value={filters.minBuildingIndex || ""}
                  onChange={handleMinBuildingIndexChange}
                  className="block w-1/2"
                  step="0.1"
                />
                <Input
                  type="number"
                  id="max-building-index"
                  placeholder="Max"
                  value={filters.maxBuildingIndex || ""}
                  onChange={handleMaxBuildingIndexChange}
                  className="block w-1/2"
                  step="0.1"
                />
              </div>
            </div>

            {/* Altezza massima edificabile */}
            <div>
              <Label htmlFor="building-height" className="text-sm font-medium text-gray-700">
                Altezza Massima (m)
              </Label>
              <div className="mt-1 flex space-x-2">
                <Input
                  type="number"
                  id="min-building-height"
                  placeholder="Min"
                  value={filters.minBuildingHeight || ""}
                  onChange={handleMinBuildingHeightChange}
                  className="block w-1/2"
                  step="0.5"
                />
                <Input
                  type="number"
                  id="max-building-height"
                  placeholder="Max"
                  value={filters.maxBuildingHeight || ""}
                  onChange={handleMaxBuildingHeightChange}
                  className="block w-1/2"
                  step="0.5"
                />
              </div>
            </div>
          </div>
        </AccordionContent>
      </AccordionItem>
    </Accordion>
  );
}