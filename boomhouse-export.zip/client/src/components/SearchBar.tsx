import React, { useState, useEffect } from 'react';
import { FilterType } from '@/lib/types';

interface SearchBarProps {
  filters: FilterType;
  onFiltersChange: (filters: FilterType) => void;
  onSearchClick: () => void;
}

const SearchBar: React.FC<SearchBarProps> = ({ 
  filters, 
  onFiltersChange, 
  onSearchClick 
}) => {
  // Crea una copia locale dei filtri per evitare aggiornamenti immediati
  const [localFilters, setLocalFilters] = useState<FilterType>(filters);

  // Sincronizzazione quando i filtri esterni cambiano
  useEffect(() => {
    setLocalFilters(filters);
  }, [filters]);

  // Funzione per gestire gli aggiornamenti dei filtri locali
  const updateLocalFilters = (update: Partial<FilterType>) => {
    const newFilters = {
      ...localFilters,
      ...update
    };
    setLocalFilters(newFilters);
    
    // Non aggiorniamo i filtri globali immediatamente, lo faremo solo quando si clicca su Cerca
  };

  // Funzione per applicare i filtri quando si clicca su Cerca
  const handleSearch = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Aggiorna i filtri globali con i filtri locali
    onFiltersChange(localFilters);
    
    // Poi esegui l'azione di ricerca
    onSearchClick();
  };

  return (
    <div className="bg-[#0071c2] p-4 rounded-sm shadow-lg">
      <div className="flex flex-col md:flex-row gap-3 items-stretch">
        <div className="flex-1">
          <label className="text-white text-sm font-medium mb-1 block">Tipo annuncio</label>
          <div className="relative">
            <select 
              className="w-full h-10 border-none rounded-sm px-3 focus:outline-none focus:ring-2 focus:ring-yellow-400 appearance-none"
              value={localFilters.listingType || "all"}
              onChange={(e) => updateLocalFilters({ listingType: e.target.value as any })}
            >
              <option value="all">Tutti gli annunci</option>
              <option value="In Vendita">In Vendita</option>
              <option value="In Affitto">In Affitto</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-white">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
              </svg>
            </div>
          </div>
        </div>
        <div className="flex-1">
          <label className="text-white text-sm font-medium mb-1 block">Tipo proprietà</label>
          <div className="relative">
            <select 
              className="w-full h-10 border-none rounded-sm px-3 focus:outline-none focus:ring-2 focus:ring-yellow-400 appearance-none"
              value={localFilters.propertyType}
              onChange={(e) => updateLocalFilters({ propertyType: e.target.value })}
            >
              <option value="all">Tutte le proprietà</option>
              <option value="residential">Appartamento</option>
              <option value="residential">Casa</option>
              <option value="commercial">Commerciale</option>
              <option value="land">Terreno</option>
              <option value="industrial">Industriale</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-white">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
              </svg>
            </div>
          </div>
        </div>
        <div className="flex-[2]">
          <label className="text-white text-sm font-medium mb-1 block">Dove cerchi?</label>
          <input 
            type="text" 
            className="w-full h-10 border-none rounded-sm px-3 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            placeholder="Luogo, CAP o indirizzo"
            value={localFilters.searchQuery || ""}
            onChange={(e) => updateLocalFilters({ searchQuery: e.target.value })}
          />
        </div>
        <div className="flex items-end">
          <button 
            type="button"
            className="h-10 bg-[#0095ff] hover:bg-[#00aeff] text-white border border-white md:min-w-[150px] px-4 rounded-sm flex items-center justify-center"
            onClick={handleSearch}
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-4 w-4 mr-2" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon>
            </svg>
            Cerca
          </button>
        </div>
      </div>
    </div>
  );
};

export default SearchBar;