import { useState, useEffect } from 'react';

interface AnimatedLogoProps {
  size?: number;
  isAnimating?: boolean;
  color?: string;
  backgroundColor?: string;
}

export default function AnimatedLogo({ 
  size = 24, 
  isAnimating = false,
  color = "#ffffff", 
  backgroundColor = "#0071c2"
}: AnimatedLogoProps) {
  const [rotation, setRotation] = useState(0);

  useEffect(() => {
    let intervalId: NodeJS.Timeout;
    
    if (isAnimating) {
      intervalId = setInterval(() => {
        setRotation(prev => (prev + 10) % 360);
      }, 50);
    }
    
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [isAnimating]);

  return (
    <div 
      className="inline-block" 
      style={{ 
        transform: isAnimating ? `rotate(${rotation}deg)` : 'none',
        transition: 'transform 0.2s ease-in-out'
      }}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill={backgroundColor}
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        style={{ borderRadius: '50%' }}
      >
        {/* Tetto casa */}
        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
        
        {/* Porta */}
        <path d="M9 22V12h6v10" fill={color} />
      </svg>
    </div>
  );
}