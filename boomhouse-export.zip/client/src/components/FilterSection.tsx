import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Search, Home, Building, DollarSign } from "lucide-react";
import { FilterType } from "@/lib/types";
import CadastralFilterSection from "@/components/CadastralFilterSection";

interface FilterSectionProps {
  filters: FilterType;
  setFilters: (filters: FilterType) => void;
}

export default function FilterSection({ filters, setFilters }: FilterSectionProps) {
  const queryClient = useQueryClient();
  const [tempFilters, setTempFilters] = useState<FilterType>(filters);
  
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTempFilters({
      ...tempFilters,
      searchQuery: e.target.value,
    });
  };
  
  const handlePostalCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTempFilters({
      ...tempFilters,
      postalCode: e.target.value,
    });
  };

  const handlePropertyTypeChange = (value: string) => {
    setTempFilters({
      ...tempFilters,
      propertyType: value,
    });
  };

  const handleLocationChange = (value: string) => {
    setTempFilters({
      ...tempFilters,
      location: value,
    });
  };

  const handleMinPriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setTempFilters({
      ...tempFilters,
      minPrice: value ? parseInt(value) : undefined,
    });
  };

  const handleMaxPriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setTempFilters({
      ...tempFilters,
      maxPrice: value ? parseInt(value) : undefined,
    });
  };

  const handleFeatureChange = (feature: string, checked: boolean) => {
    const newFeatures = checked
      ? [...(tempFilters.features || []), feature]
      : (tempFilters.features || []).filter(f => f !== feature);
    
    setTempFilters({
      ...tempFilters,
      features: newFeatures,
    });
  };

  const handleProfessionalTypeChange = (value: string) => {
    setTempFilters({
      ...tempFilters,
      professionalType: value as "all" | "architect" | "notary" | "artisan",
    });
  };
  
  const handleListingTypeChange = (value: string) => {
    setTempFilters({
      ...tempFilters,
      listingType: value as "all" | "In Vendita" | "In Affitto",
    });
  };

  const handleReset = () => {
    const resetFilters: FilterType = {
      searchQuery: "",
      propertyType: "all",
      location: "all",
      postalCode: "",
      minPrice: undefined,
      maxPrice: undefined,
      features: [],
      professionalType: "all",
      listingType: "all",
      // Reset dei filtri catastali
      cadastralNumber: undefined,
      cadastralZone: undefined,
      cadastralSection: undefined,
      cadastralFolio: undefined,
      cadastralParcel: undefined,
      minBuildingIndex: undefined,
      maxBuildingIndex: undefined,
      minBuildingHeight: undefined,
      maxBuildingHeight: undefined,
      zoning: undefined,
      showCadastralOnly: false,
    };
    setTempFilters(resetFilters);
    setFilters(resetFilters);
    
    // Invalida le query per forzare il ricaricamento dei dati con i filtri resettati
    queryClient.invalidateQueries({ queryKey: ['/api/properties'] });
    queryClient.invalidateQueries({ queryKey: ['/api/professionals'] });
    queryClient.invalidateQueries({ queryKey: ['/api/banks'] });
  };

  const handleApply = () => {
    // Imposta i filtri
    setFilters(tempFilters);
    
    // Invalida le query per forzare il ricaricamento dei dati con i nuovi filtri
    queryClient.invalidateQueries({ queryKey: ['/api/properties'] });
    queryClient.invalidateQueries({ queryKey: ['/api/professionals'] });
    queryClient.invalidateQueries({ queryKey: ['/api/banks'] });
  };

  return (
    <>
      <div className="mb-4">
        <Label htmlFor="search-query" className="block text-sm font-medium text-gray-700">Cerca Proprietà</Label>
        <div className="mt-1 relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-gray-400" />
          </div>
          <Input
            type="text"
            id="search-query"
            placeholder="Inserisci indirizzo, tipo di proprietà..."
            value={tempFilters.searchQuery || ""}
            onChange={handleSearchChange}
            className="block w-full pl-10"
          />
        </div>
      </div>

      <div className="mb-4">
        <Label htmlFor="property-type" className="block text-sm font-medium text-gray-700">Tipo di Proprietà</Label>
        <Select
          value={tempFilters.propertyType}
          onValueChange={handlePropertyTypeChange}
        >
          <SelectTrigger id="property-type" className="mt-1">
            <SelectValue placeholder="Tutte le Proprietà" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutte le Proprietà</SelectItem>
            <SelectItem value="residential">Residenziale</SelectItem>
            <SelectItem value="commercial">Commerciale</SelectItem>
            <SelectItem value="land">Terreno</SelectItem>
            <SelectItem value="industrial">Industriale</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="mb-4">
        <Label htmlFor="listing-type" className="block text-sm font-medium text-gray-700">Tipo di Annuncio</Label>
        <Select
          value={tempFilters.listingType || "all"}
          onValueChange={handleListingTypeChange}
        >
          <SelectTrigger id="listing-type" className="mt-1">
            <SelectValue placeholder="Tutti gli Annunci" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutti gli Annunci</SelectItem>
            <SelectItem value="In Vendita">In Vendita</SelectItem>
            <SelectItem value="In Affitto">In Affitto</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <Label htmlFor="location" className="block text-sm font-medium text-gray-700">Località</Label>
          <Select
            value={tempFilters.location}
            onValueChange={handleLocationChange}
          >
            <SelectTrigger id="location" className="mt-1">
              <SelectValue placeholder="Tutte le Località" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tutte le Località</SelectItem>
              <SelectItem value="lugano">Lugano</SelectItem>
              <SelectItem value="bellinzona">Bellinzona</SelectItem>
              <SelectItem value="locarno">Locarno</SelectItem>
              <SelectItem value="mendrisio">Mendrisio</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="postal-code" className="block text-sm font-medium text-gray-700">Codice Postale</Label>
          <Input
            type="text"
            id="postal-code"
            placeholder="es. 6900"
            value={tempFilters.postalCode || ""}
            onChange={handlePostalCodeChange}
            className="mt-1 w-full"
          />
        </div>
      </div>

      <div className="mb-4">
        <Label htmlFor="price-range" className="block text-sm font-medium text-gray-700">Fascia di Prezzo</Label>
        <div className="mt-1 flex space-x-2">
          <Input
            type="number"
            id="price-min"
            placeholder="Min"
            value={tempFilters.minPrice || ""}
            onChange={handleMinPriceChange}
            className="block w-1/2"
          />
          <Input
            type="number"
            id="price-max"
            placeholder="Max"
            value={tempFilters.maxPrice || ""}
            onChange={handleMaxPriceChange}
            className="block w-1/2"
          />
        </div>
      </div>

      <div className="mb-4">
        <Label htmlFor="professional-type" className="block text-sm font-medium text-gray-700">Tipo di Professionista</Label>
        <Select
          value={tempFilters.professionalType || "all"}
          onValueChange={handleProfessionalTypeChange}
        >
          <SelectTrigger id="professional-type" className="mt-1">
            <SelectValue placeholder="Tutti i Professionisti" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutti i Professionisti</SelectItem>
            <SelectItem value="architect">Architetti</SelectItem>
            <SelectItem value="notary">Notai</SelectItem>
            <SelectItem value="artisan">Artigiani</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <span className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Caratteristiche Proprietà</span>
        <div className="grid grid-cols-2 gap-2">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="feature-parking"
              checked={tempFilters.features?.includes("Parcheggio Sotterraneo") || false}
              onCheckedChange={(checked) => handleFeatureChange("Parcheggio Sotterraneo", checked as boolean)}
            />
            <Label htmlFor="feature-parking" className="text-sm text-gray-700 dark:text-gray-300">Parcheggio</Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="feature-garden"
              checked={tempFilters.features?.includes("Giardino") || false}
              onCheckedChange={(checked) => handleFeatureChange("Giardino", checked as boolean)}
            />
            <Label htmlFor="feature-garden" className="text-sm text-gray-700 dark:text-gray-300">Giardino</Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="feature-balcony"
              checked={tempFilters.features?.includes("Balcone") || false}
              onCheckedChange={(checked) => handleFeatureChange("Balcone", checked as boolean)}
            />
            <Label htmlFor="feature-balcony" className="text-sm text-gray-700 dark:text-gray-300">Balcone</Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox
              id="feature-pool"
              checked={tempFilters.features?.includes("Piscina") || false}
              onCheckedChange={(checked) => handleFeatureChange("Piscina", checked as boolean)}
            />
            <Label htmlFor="feature-pool" className="text-sm text-gray-700 dark:text-gray-300">Piscina</Label>
          </div>
        </div>
      </div>
      
      {/* Sezione Filtri Catastali */}
      <div className="mt-4 mb-4">
        <CadastralFilterSection 
          filters={tempFilters} 
          setTempFilters={setTempFilters} 
        />
      </div>

      <div className="mt-4 flex justify-end">
        <Button variant="outline" className="bg-gray-100 text-gray-800 mr-2" onClick={handleReset}>
          Ripristina
        </Button>
        <Button className="bg-primary text-white" onClick={handleApply}>
          Cerca
        </Button>
      </div>
    </>
  );
}
