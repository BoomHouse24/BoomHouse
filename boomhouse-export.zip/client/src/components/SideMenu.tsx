import React, { useState } from 'react';
import { useLocation } from 'wouter';
import {
  Building,
  Building2,
  Mountain,
  PanelTop,
  ChevronDown,
  ChevronUp,
  Upload,
  User,
  Home,
  Info,
  HelpCircle,
  Star,
  MessageSquare,
  Briefcase
} from 'lucide-react';

// Definizione dei gruppi di menu
const menuGroups = [
  {
    title: "BOOMHOUSE",
    icon: <Home size={18} />,
    items: [
      { title: "Chi siamo", icon: <Info size={18} />, href: "/chi-siamo" },
      { title: "Come funziona", icon: <HelpCircle size={18} />, href: "/come-funziona" },
      { title: "Recensioni", icon: <Star size={18} />, href: "/recensioni" },
      { title: "Contattaci", icon: <MessageSquare size={18} />, href: "/contattaci" },
      { title: "Diventa partner", icon: <Briefcase size={18} />, href: "/diventa-partner" }
    ]
  },
  {
    title: "IMMOBILI",
    icon: <Building size={18} />,
    items: [
      { title: "Case e appartamenti", icon: <Home size={18} />, href: "/case-appartamenti" },
      { title: "Immobili commerciali", icon: <Building2 size={18} />, href: "/immobili-commerciali" },
      { title: "Terreni", icon: <Mountain size={18} />, href: "/terreni" },
      { title: "Annunci più visualizzati", icon: <PanelTop size={18} />, href: "/annunci-popolari" },
      { title: "Inserisci un annuncio", icon: <Upload size={18} />, href: "/inserisci-annuncio" }
    ]
  }
];

const SideMenu: React.FC = () => {
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});
  const [, navigate] = useLocation();

  const toggleGroup = (title: string) => {
    setExpandedGroups(prev => ({
      ...prev,
      [title]: !prev[title]
    }));
  };

  const handleItemClick = (href: string) => {
    navigate(href);
  };

  return (
    <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg overflow-hidden shadow-lg">
      <div className="p-3 bg-blue-600 text-white font-medium">
        Menu principale
      </div>
      
      <div className="divide-y divide-gray-200 dark:divide-gray-800">
        {menuGroups.map((group) => (
          <div key={group.title} className="relative">
            <div 
              className="flex items-center justify-between p-3 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer"
              onClick={() => toggleGroup(group.title)}
            >
              <div className="flex items-center">
                {group.icon}
                <span className="ml-3 font-medium">{group.title}</span>
              </div>
              {expandedGroups[group.title] ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
            </div>
            
            {expandedGroups[group.title] && (
              <div className="pl-10 bg-gray-50 dark:bg-gray-900">
                {group.items.map((item) => (
                  <div
                    key={item.title}
                    className="flex items-center p-3 hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer"
                    onClick={() => handleItemClick(item.href)}
                  >
                    {item.icon}
                    <span className="ml-3">{item.title}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default SideMenu;