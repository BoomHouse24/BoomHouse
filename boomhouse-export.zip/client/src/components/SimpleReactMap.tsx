import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, LayersControl, useMap, Circle, ZoomControl } from 'react-leaflet';
import { PropertyType, ProfessionalType, BankType, ListingType } from "@/lib/types";
import { Loader2, MapPin, Home, Building, Landmark, Navigation, Search } from "lucide-react";
import "leaflet/dist/leaflet.css";
import L from 'leaflet';

// Importiamo il file CSS con gli stili personalizzati in stile Apple Maps
import "./mapStyles.css";

// Componente per aggiornare la vista della mappa
function ChangeMapView({ center, zoom }: { center: [number, number], zoom: number }) {
  const map = useMap();
  map.setView(center, zoom);
  return null;
}

interface SimpleReactMapProps {
  properties: PropertyType[];
  professionals: ProfessionalType[];
  banks: BankType[];
  onMarkerClick: (item: PropertyType | ProfessionalType | BankType, type: ListingType) => void;
  onOpenCalculator?: () => void;
}

const SimpleReactMap: React.FC<SimpleReactMapProps> = ({ 
  properties, 
  professionals, 
  banks, 
  onMarkerClick,
  onOpenCalculator
}) => {
  const [mapCenter, setMapCenter] = useState<[number, number]>([46.0036, 8.9510]); // Ticino, Svizzera
  const [mapZoom, setMapZoom] = useState(10);
  const [showProperties, setShowProperties] = useState(true);
  const [showProfessionals, setShowProfessionals] = useState(false);
  const [showBanks, setShowBanks] = useState(false);
  const [addressSearch, setAddressSearch] = useState('');
  const [searchedLocation, setSearchedLocation] = useState<[number, number] | null>(null);
  const [searchedLocationName, setSearchedLocationName] = useState<string | null>(null);
  const [currentLocation, setCurrentLocation] = useState<[number, number] | null>(null);
  
  // Crea icone personalizzate per i diversi tipi di marker in stile Apple Maps
  const createAppleStyleIcon = (color: string, type: string) => {
    // Scegli l'icona in base al tipo
    let iconSvg = '';
    let iconColor = color;
    
    switch(type) {
      case 'property':
        iconSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>`;
        break;
      case 'professional':
        iconSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path></svg>`;
        break;
      case 'bank':
        iconSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="14" x="2" y="3" rx="2"></rect><line x1="2" x2="22" y1="9" y2="9"></line><line x1="12" x2="12" y1="9" y2="17"></line><rect width="4" height="4" x="10" y="13" rx="1"></rect></svg>`;
        break;
      default:
        iconSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8"></circle></svg>`;
    }
    
    return L.divIcon({
      className: 'apple-style-icon',
      html: `
      <div style="position: relative;" class="location-marker">
        <div style="background-color: ${iconColor}; width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 4px rgba(0,0,0,0.2); transform: rotate(0deg); transform-origin: bottom center;">
          ${iconSvg}
        </div>
        <div style="position: absolute; bottom: -2px; left: 11px; width: 10px; height: 10px; background-color: ${iconColor}; transform: rotate(45deg);"></div>
      </div>`,
      iconSize: [32, 42],
      iconAnchor: [16, 42],
      popupAnchor: [0, -42]
    });
  };

  // Icona per la posizione cercata in stile Apple Maps
  const searchedLocationIcon = L.divIcon({
    className: 'apple-style-search-location',
    html: `
    <div style="position: relative;" class="location-marker">
      <div style="background-color: #ef4444; width: 40px; height: 40px; border-radius: 8px; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 8px rgba(0,0,0,0.3); transform: rotate(0deg); transform-origin: bottom center;">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
      </div>
      <div style="position: absolute; bottom: -2px; left: 15px; width: 10px; height: 10px; background-color: #ef4444; transform: rotate(45deg);"></div>
    </div>`,
    iconSize: [40, 50],
    iconAnchor: [20, 50],
    popupAnchor: [0, -50]
  });
  
  // Icona per la posizione attuale in stile Apple Maps
  const currentLocationIcon = L.divIcon({
    className: 'apple-style-current-location',
    html: `
    <div class="current-location-marker">
      <div style="width: 24px; height: 24px; background-color: rgba(59, 130, 246, 0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
        <div style="width: 18px; height: 18px; background-color: rgba(59, 130, 246, 0.4); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
          <div style="width: 10px; height: 10px; background-color: rgb(59, 130, 246); border-radius: 50%; border: 2px solid white;"></div>
        </div>
      </div>
    </div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  });

  const propertyIcon = createAppleStyleIcon('#007AFF', 'property'); // Blu Apple
  const professionalIcon = createAppleStyleIcon('#34C759', 'professional'); // Verde Apple
  const bankIcon = createAppleStyleIcon('#FF9500', 'bank'); // Arancione Apple
  
  // Gestisci la ricerca degli indirizzi
  const handleAddressSearch = async () => {
    if (!addressSearch.trim()) return;
    
    try {
      const response = await fetch(`/api/geocode?q=${encodeURIComponent(addressSearch)}&limit=1&lang=it`);
      
      if (!response.ok) {
        throw new Error('Errore nella ricerca dell\'indirizzo');
      }
      
      const data = await response.json();
      
      if (data && data.features && data.features.length > 0) {
        const feature = data.features[0];
        const coords = feature.geometry.coordinates;
        const lng = coords[0];
        const lat = coords[1];
        
        console.log("Indirizzo trovato:", lat, lng);
        
        // Salva la posizione cercata
        setSearchedLocation([lat, lng]);
        setSearchedLocationName(feature.properties?.display_name || addressSearch);
        
        // Aggiorna il centro della mappa
        setMapCenter([lat, lng]);
        setMapZoom(16);
      } else {
        alert('Indirizzo non trovato. Prova a essere più specifico.');
      }
    } catch (error) {
      console.error('Errore nella ricerca dell\'indirizzo:', error);
      alert('Si è verificato un errore durante la ricerca dell\'indirizzo.');
    }
  };
  
  // Ottieni la posizione corrente
  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          
          // Salva la posizione attuale
          setCurrentLocation([lat, lng]);
          
          // Aggiorna il centro della mappa
          setMapCenter([lat, lng]);
          setMapZoom(16);
        },
        (error) => {
          let message = 'Errore nel recupero della posizione.';
          
          switch(error.code) {
            case error.PERMISSION_DENIED:
              message = 'Accesso alla posizione negato.';
              break;
            case error.POSITION_UNAVAILABLE:
              message = 'Informazioni sulla posizione non disponibili.';
              break;
            case error.TIMEOUT:
              message = 'Richiesta della posizione scaduta.';
              break;
          }
          
          alert(message);
        }
      );
    } else {
      alert('La geolocalizzazione non è supportata dal tuo browser.');
    }
  };
  
  // Ottieni la posizione dell'utente al caricamento del componente
  useEffect(() => {
    navigator.geolocation?.getCurrentPosition(
      (position) => {
        setCurrentLocation([position.coords.latitude, position.coords.longitude]);
      },
      () => {
        // Fallisce silenziosamente se l'utente non concede i permessi
      }
    );
  }, []);
  
  return (
    <div className="flex flex-col h-full">
      {/* Barra di ricerca in stile Apple Maps */}
      <div className="p-4 bg-gradient-to-b from-white to-gray-50 shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3">
            {/* Ricerca indirizzo */}
            <div className="flex-1 relative">
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                <Search size={18} />
              </div>
              <input
                type="text"
                placeholder="Cerca indirizzo o luogo in Svizzera"
                value={addressSearch}
                onChange={(e) => setAddressSearch(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddressSearch()}
                className="search-box w-full pl-12 pr-10 py-3 font-light text-base"
              />
              {addressSearch && (
                <button 
                  onClick={() => setAddressSearch('')}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="15" y1="9" x2="9" y2="15"></line>
                    <line x1="9" y1="9" x2="15" y2="15"></line>
                  </svg>
                </button>
              )}
            </div>
              
            <button
              onClick={handleAddressSearch}
              className="search-button flex items-center"
            >
              <span>Cerca</span>
            </button>
              
            <button
              onClick={getCurrentLocation}
              title="Usa la mia posizione"
              className="location-button"
            >
              <Navigation size={18} />
            </button>
          </div>
          
          {/* Toggle per i marker - in stile più moderno */}
          <div className="flex items-center gap-4 mt-3 px-1">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full bg-[#007AFF] border border-white shadow-sm"></div>
              <label className="flex items-center cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={showProperties}
                  onChange={() => setShowProperties(!showProperties)}
                  className="sr-only"
                />
                <span className={`text-sm font-medium ${showProperties ? 'text-[#007AFF]' : 'text-gray-500'}`}>
                  Immobili
                </span>
              </label>
            </div>
            
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full bg-[#34C759] border border-white shadow-sm"></div>
              <label className="flex items-center cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={showProfessionals}
                  onChange={() => setShowProfessionals(!showProfessionals)}
                  className="sr-only"
                />
                <span className={`text-sm font-medium ${showProfessionals ? 'text-[#34C759]' : 'text-gray-500'}`}>
                  Professionisti
                </span>
              </label>
            </div>
            
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full bg-[#FF9500] border border-white shadow-sm"></div>
              <label className="flex items-center cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={showBanks}
                  onChange={() => setShowBanks(!showBanks)}
                  className="sr-only"
                />
                <span className={`text-sm font-medium ${showBanks ? 'text-[#FF9500]' : 'text-gray-500'}`}>
                  Banche
                </span>
              </label>
            </div>
          </div>
        </div>
      </div>
      
      {/* Mappa React Leaflet */}
      <div className="flex-1 relative" style={{ height: 'calc(100vh - 180px)' }}>
        <MapContainer 
          center={mapCenter} 
          zoom={mapZoom} 
          style={{ height: '100%', width: '100%' }}
          zoomControl={true}
          zoomAnimation={true}
          doubleClickZoom={true}
          scrollWheelZoom={true}
          attributionControl={true}
        >
          <ChangeMapView center={mapCenter} zoom={mapZoom} />
          
          <LayersControl position="topright">
            <LayersControl.BaseLayer checked name="Standard">
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
            </LayersControl.BaseLayer>
            <LayersControl.BaseLayer name="Satellite">
              <TileLayer
                attribution='Imagery &copy; Esri &copy; Maxar &copy; Earthstar Geographics'
                url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
              />
            </LayersControl.BaseLayer>
            <LayersControl.BaseLayer name="Catastale">
              <TileLayer
                attribution='&copy; <a href="https://www.swisstopo.admin.ch/">Swisstopo</a>'
                url="https://wmts.geo.admin.ch/1.0.0/ch.swisstopo.pixelkarte-farbe/default/current/3857/{z}/{x}/{y}.jpeg"
                tileSize={256}
              />
            </LayersControl.BaseLayer>
          </LayersControl>
          
          {/* Marker delle proprietà */}
          {showProperties && properties.map(property => (
            <Marker 
              key={`property-${property.id}`}
              position={[property.lat, property.lng]} 
              icon={propertyIcon}
              eventHandlers={{
                click: () => onMarkerClick(property, 'property')
              }}
            >
              <Popup>
                <div className="apple-popup">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-md mr-2 bg-[#007AFF] flex items-center justify-center text-white">
                      <Home size={16} />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-[15px] mb-0.5">{property.title}</h3>
                      <p className="text-[#007AFF] font-medium text-sm">{property.price}</p>
                    </div>
                  </div>
                  <div className="flex items-center mt-2 border-t pt-2 border-gray-100">
                    <div className="flex-1 text-xs text-gray-600">
                      {property.propertyType} · {property.area}m² {property.beds && `· ${property.beds} locali`}
                    </div>
                    <button 
                      className="apple-button apple-button-blue"
                      onClick={() => onMarkerClick(property, 'property')}
                    >
                      Dettagli
                    </button>
                  </div>
                </div>
              </Popup>
            </Marker>
          ))}
          
          {/* Marker dei professionisti */}
          {showProfessionals && professionals.map(professional => {
            const profType = professional.type === 'architect' ? 'Architetto' : 
                           professional.type === 'notary' ? 'Notaio' : 
                           professional.type === 'artisan' ? 'Artigiano' : 
                           professional.type;
            
            return (
              <Marker 
                key={`prof-${professional.id}`}
                position={[professional.lat, professional.lng]} 
                icon={professionalIcon}
                eventHandlers={{
                  click: () => onMarkerClick(professional, 'professional')
                }}
              >
                <Popup>
                  <div className="apple-popup">
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-md mr-2 bg-[#34C759] flex items-center justify-center text-white">
                        <Building size={16} />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-[15px] mb-0.5">{professional.name}</h3>
                        <p className="text-[#34C759] font-medium text-sm">{profType}</p>
                      </div>
                    </div>
                    <div className="flex items-center mt-2 border-t pt-2 border-gray-100">
                      <div className="flex-1 text-xs text-gray-600">
                        {professional.address}
                      </div>
                      <button 
                        className="apple-button apple-button-green"
                        onClick={() => onMarkerClick(professional, 'professional')}
                      >
                        Contatta
                      </button>
                    </div>
                  </div>
                </Popup>
              </Marker>
            );
          })}
          
          {/* Marker delle banche */}
          {showBanks && banks.map(bank => (
            <Marker 
              key={`bank-${bank.id}`}
              position={[bank.lat, bank.lng]} 
              icon={bankIcon}
              eventHandlers={{
                click: () => onMarkerClick(bank, 'bank')
              }}
            >
              <Popup>
                <div className="apple-popup">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-md mr-2 bg-[#FF9500] flex items-center justify-center text-white">
                      <Landmark size={16} />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-[15px] mb-0.5">{bank.name}</h3>
                      <p className="text-[#FF9500] font-medium text-sm">Istituto bancario</p>
                    </div>
                  </div>
                  <div className="flex items-center mt-2 border-t pt-2 border-gray-100">
                    <div className="flex-1 text-xs text-gray-600">
                      {bank.address}
                    </div>
                    <button 
                      className="apple-button apple-button-orange"
                      onClick={() => onMarkerClick(bank, 'bank')}
                    >
                      Contatta
                    </button>
                  </div>
                </div>
              </Popup>
            </Marker>
          ))}
          
          {/* Marker per la posizione cercata */}
          {searchedLocation && (
            <Marker
              position={searchedLocation}
              icon={searchedLocationIcon}
              zIndexOffset={1000}
            >
              <Popup>
                <div className="apple-popup">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-md mr-2 bg-[#ef4444] flex items-center justify-center text-white">
                      <MapPin size={16} />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-[15px] mb-0.5">Posizione cercata</h3>
                      <p className="text-[#ef4444] font-medium text-sm">Punto di interesse</p>
                    </div>
                  </div>
                  <div className="mt-2 border-t pt-2 border-gray-100">
                    <div className="text-xs text-gray-600">
                      {searchedLocationName || addressSearch}
                    </div>
                  </div>
                </div>
              </Popup>
            </Marker>
          )}
          
          {/* Marker per la posizione attuale */}
          {currentLocation && (
            <>
              <Marker
                position={currentLocation}
                icon={currentLocationIcon}
                zIndexOffset={1001}
              >
                <Popup>
                  <div className="apple-popup">
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-md mr-2 bg-[#3b82f6] flex items-center justify-center text-white">
                        <Navigation size={16} />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-[15px] mb-0.5">La tua posizione</h3>
                        <p className="text-[#3b82f6] font-medium text-sm">Posizione attuale</p>
                      </div>
                    </div>
                  </div>
                </Popup>
              </Marker>
              <Circle
                center={currentLocation}
                radius={200}
                pathOptions={{ 
                  color: '#3b82f6',
                  fillColor: '#3b82f6',
                  fillOpacity: 0.1,
                  weight: 1
                }}
              />
            </>
          )}
          
          {/* Barra di controlli inferiore in stile Apple Maps */}
          <div className="map-controls-bottom">
            <button className="map-control-button" onClick={getCurrentLocation} title="Centra sulla mia posizione">
              <Navigation size={16} className="text-blue-500" />
              <span className="ml-1 text-sm font-semibold">Posizione</span>
            </button>
            
            <button 
              className="map-control-button" 
              title="Calcolo ipotecario"
              onClick={onOpenCalculator}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500">
                <path d="M2 9a3 3 0 0 1 0-6h20a3 3 0 0 1 0 6H2Z"/>
                <path d="M13 6v16"/>
                <path d="M2 15h10"/>
                <path d="M2 12h10"/>
                <path d="M18 15v2"/>
                <path d="M18 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"/>
              </svg>
              <span className="ml-1 text-sm font-semibold">Ipoteca</span>
            </button>
            
            <button 
              className="map-control-button" 
              title="Più dettagli"
              onClick={() => {
                const helpMessage = `
                  BoomHouse - Mappa Interattiva
                  
                  • I punti blu sono immobili in vendita o affitto
                  • I punti verdi sono professionisti (architetti, notai)
                  • I punti arancioni sono banche e istituti di credito
                  
                  Usa i filtri in alto per mostrare o nascondere i marker.
                  Clicca su un marker per vedere i dettagli.
                `;
                alert(helpMessage);
              }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-500">
                <circle cx="12" cy="12" r="10"/>
                <line x1="12" x2="12" y1="8" y2="16"/>
                <line x1="8" x2="16" y1="12" y2="12"/>
              </svg>
              <span className="ml-1 text-sm font-semibold">Info</span>
            </button>
          </div>
        </MapContainer>
      </div>
    </div>
  );
};

export default SimpleReactMap;