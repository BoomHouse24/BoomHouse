import { ProfessionalType } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Briefcase, Gavel, Wrench } from "lucide-react";

interface ProfessionalCardProps {
  professional: ProfessionalType;
  onContact: () => void;
}

export default function ProfessionalCard({ professional, onContact }: ProfessionalCardProps) {
  const getIcon = () => {
    switch (professional.type) {
      case "architect":
        return <Briefcase className="h-4 w-4" />;
      case "notary":
        return <Gavel className="h-4 w-4" />;
      case "artisan":
        return <Wrench className="h-4 w-4" />;
      default:
        return <Briefcase className="h-4 w-4" />;
    }
  };

  return (
    <div className="flex items-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-secondary-100 dark:bg-gray-700 flex items-center justify-center text-secondary-700 dark:text-blue-300">
        {getIcon()}
      </div>
      <div className="ml-4 flex-1">
        <div className="text-sm font-medium text-gray-900 dark:text-gray-100">{professional.name}</div>
        <div className="text-xs text-gray-500 dark:text-gray-400">{professional.address}</div>
      </div>
      <Button 
        variant="outline" 
        size="sm"
        className="ml-2 text-secondary-700 dark:text-blue-300 bg-secondary-100 dark:bg-gray-700 hover:bg-secondary-200 dark:hover:bg-gray-600 border-secondary-200 dark:border-gray-600"
        onClick={onContact}
      >
        Contatta
      </Button>
    </div>
  );
}
