import { useState, useEffect } from "react";
import { PropertyType, ProfessionalType, BankType, ListingType } from "@/lib/types";
import { Button } from "@/components/ui/button";
import 'leaflet/dist/leaflet.css';

// Custom declarations to avoid TypeScript errors
declare global {
  interface Window {
    L: any;
    MapContainer: any;
    TileLayer: any;
    Marker: any;
    Popup: any;
    useMap: any;
    map: any;
  }
}

export default function Map({
  properties,
  professionals,
  banks,
  onMarkerClick
}: {
  properties: PropertyType[];
  professionals: ProfessionalType[];
  banks: BankType[];
  onMarkerClick: (item: PropertyType | ProfessionalType | BankType, type: ListingType) => void;
}) {
  const [mapLoaded, setMapLoaded] = useState(false);
  const [mapType, setMapType] = useState<"cadastral" | "satellite" | "standard">("standard");
  
  useEffect(() => {
    // La libreria Leaflet è già caricata tramite CDN in index.html
    if (typeof window !== 'undefined' && window.L) {
      // Il caricamento dinamico dei componenti di react-leaflet
      import('react-leaflet').then((ReactLeaflet) => {
        window.MapContainer = ReactLeaflet.MapContainer;
        window.TileLayer = ReactLeaflet.TileLayer;
        window.Marker = ReactLeaflet.Marker;
        window.Popup = ReactLeaflet.Popup;
        window.useMap = ReactLeaflet.useMap;
        
        setMapLoaded(true);
      });
    }
  }, []);

  // Funzione per creare icone personalizzate - usando il metodo Icon di base di Leaflet
  const createMarkerIcon = (type: ListingType) => {
    if (!window.L) return null;
    
    // Generiamo un URL base64 per un'immagine SVG minimalista
    const generateSVGUrl = (color: string) => {
      // SVG di un punto molto piccolo (4px di diametro)
      const svgContent = `
        <svg xmlns="http://www.w3.org/2000/svg" width="4" height="4" viewBox="0 0 4 4">
          <circle cx="2" cy="2" r="2" fill="${color}" />
        </svg>
      `;
      
      // Convertiamo in base64
      const base64 = btoa(svgContent);
      return `data:image/svg+xml;base64,${base64}`;
    };
    
    // Colori per i diversi tipi
    let iconUrl = '';
    
    if (type === "property") {
      iconUrl = generateSVGUrl("#3b82f6"); // Blu
    } else if (type === "professional") {
      iconUrl = generateSVGUrl("#10b981"); // Verde
    } else {
      iconUrl = generateSVGUrl("#f59e0b"); // Giallo/arancione
    }
    
    // Usiamo l'Icon standard di Leaflet con dimensioni molto piccole
    return window.L.icon({
      iconUrl: iconUrl,
      iconSize: [4, 4],     // Dimensione davvero minima
      iconAnchor: [2, 2],   // Al centro dell'icona
      popupAnchor: [0, -4]  // Popup appena sopra il punto
    });
  };

  if (!mapLoaded) {
    return (
      <div className="bg-white p-2 rounded-lg shadow-sm h-full">
        <div className="flex mb-2 space-x-2">
          <Button className="flex-1 bg-gray-100 text-gray-800 rounded-l">Mappa Catastale</Button>
          <Button className="flex-1 bg-gray-100 text-gray-800">Satellite</Button>
          <Button className="flex-1 bg-gray-100 text-gray-800 rounded-r">Standard</Button>
        </div>
        <div className="flex items-center justify-center h-[600px] border border-gray-200 rounded-lg">
          <div className="text-center p-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-lg font-medium">Caricamento mappa in corso...</p>
            <p className="text-gray-500 mt-2">Stiamo preparando la visualizzazione delle proprietà immobiliari.</p>
          </div>
        </div>
      </div>
    );
  }

  // Accedo ai componenti di react-leaflet
  const { MapContainer, TileLayer, Marker, Popup, useMap } = window;

  // Componente per accedere all'istanza della mappa
  const MapReference = () => {
    const map = useMap();
    
    useEffect(() => {
      if (map) {
        window.map = map;
      }
    }, [map]);
    
    return null;
  };

  // Funzione per posizionare l'utente sulla mappa
  const locateUser = () => {
    if (navigator.geolocation && window.map) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          window.map.setView([latitude, longitude], 16);
        },
        (error) => {
          console.error("Errore nella geolocalizzazione:", error);
          alert("Impossibile ottenere la posizione. Per favore controlla i permessi di localizzazione.");
        }
      );
    } else {
      alert("Geolocalizzazione non supportata dal tuo dispositivo");
    }
  };

  // Layer della mappa in base al tipo selezionato
  const getTileLayer = () => {
    const osmAttribution = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';
    const stamenAttribution = 'Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://creativecommons.org/licenses/by/3.0">CC BY 3.0</a> &mdash; Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';
    const esriAttribution = 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community';
    
    if (mapType === "satellite") {
      return (
        <TileLayer
          attribution={esriAttribution}
          url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
        />
      );
    } else if (mapType === "cadastral") {
      return (
        <TileLayer
          attribution={stamenAttribution}
          url="https://stamen-tiles-{s}.a.ssl.fastly.net/toner-lines/{z}/{x}/{y}{r}.png"
        />
      );
    } else { // standard
      return (
        <TileLayer
          attribution={osmAttribution}
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
      );
    }
  };

  return (
    <div className="bg-white p-2 rounded-lg shadow-sm h-full">
      <div className="flex mb-2 space-x-2">
        <Button
          onClick={() => setMapType("cadastral")}
          variant={mapType === "cadastral" ? "default" : "outline"}
          className={`flex-1 ${mapType === "cadastral" ? "bg-primary text-white" : "bg-gray-100 text-gray-800"} rounded-l`}
        >
          Mappa Catastale
        </Button>
        <Button
          onClick={() => setMapType("satellite")}
          variant={mapType === "satellite" ? "default" : "outline"}
          className={`flex-1 ${mapType === "satellite" ? "bg-primary text-white" : "bg-gray-100 text-gray-800"}`}
        >
          Satellite
        </Button>
        <Button
          onClick={() => setMapType("standard")}
          variant={mapType === "standard" ? "default" : "outline"}
          className={`flex-1 ${mapType === "standard" ? "bg-primary text-white" : "bg-gray-100 text-gray-800"} rounded-r`}
        >
          Standard
        </Button>
      </div>
      
      <div className="rounded-lg overflow-hidden border border-gray-200" style={{ height: '600px' }}>
        <MapContainer
          center={[46.0036, 8.9510]} // Centered on Lugano
          zoom={13}
          scrollWheelZoom={true}
          style={{ height: '100%', width: '100%' }}
          zoomControl={false}
        >
          <MapReference />
          {getTileLayer()}
          
          {/* Property Markers */}
          {properties.map((property) => (
            <Marker
              key={`property-${property.id}`}
              position={[property.lat, property.lng]}
              icon={createMarkerIcon("property")}
              eventHandlers={{
                click: () => {
                  onMarkerClick(property, "property");
                },
              }}
            >
              <Popup>
                <div className="text-center">
                  <h3 className="font-bold">{property.title}</h3>
                  <p className="text-primary font-semibold">{property.price}</p>
                  <Button 
                    variant="default" 
                    size="sm" 
                    className="mt-2 bg-primary w-full"
                    onClick={(e) => {
                      e.stopPropagation();
                      onMarkerClick(property, "property");
                    }}
                  >
                    Visualizza Dettagli
                  </Button>
                </div>
              </Popup>
            </Marker>
          ))}
          
          {/* Professional Markers */}
          {professionals.map((professional) => (
            <Marker
              key={`professional-${professional.id}`}
              position={[professional.lat, professional.lng]}
              icon={createMarkerIcon("professional")}
              eventHandlers={{
                click: () => {
                  onMarkerClick(professional, "professional");
                },
              }}
            >
              <Popup>
                <div className="text-center">
                  <h3 className="font-bold">{professional.name}</h3>
                  <p className="text-secondary font-semibold">
                    {professional.type === 'architect' ? 'Architetto' : 
                     professional.type === 'notary' ? 'Notaio' : 
                     professional.type === 'artisan' ? 'Artigiano' : 
                     professional.type}
                  </p>
                  <Button 
                    variant="default" 
                    size="sm" 
                    className="mt-2 bg-secondary w-full"
                    onClick={(e) => {
                      e.stopPropagation();
                      onMarkerClick(professional, "professional");
                    }}
                  >
                    Contatta
                  </Button>
                </div>
              </Popup>
            </Marker>
          ))}
          
          {/* Bank Markers */}
          {banks.map((bank) => (
            <Marker
              key={`bank-${bank.id}`}
              position={[bank.lat, bank.lng]}
              icon={createMarkerIcon("bank")}
              eventHandlers={{
                click: () => {
                  onMarkerClick(bank, "bank");
                },
              }}
            >
              <Popup>
                <div className="text-center">
                  <h3 className="font-bold">{bank.name}</h3>
                  <Button 
                    variant="default" 
                    size="sm" 
                    className="mt-2 bg-amber-500 w-full"
                    onClick={(e) => {
                      e.stopPropagation();
                      onMarkerClick(bank, "bank");
                    }}
                  >
                    Contatta
                  </Button>
                </div>
              </Popup>
            </Marker>
          ))}
          
          {/* Controlli personalizzati */}
          <div className="leaflet-bottom leaflet-right">
            <div className="leaflet-control leaflet-bar">
              <Button
                className="bg-white text-black p-2 hover:bg-gray-100"
                onClick={locateUser}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"></circle>
                  <circle cx="12" cy="12" r="4"></circle>
                  <line x1="4.93" y1="4.93" x2="9.17" y2="9.17"></line>
                  <line x1="14.83" y1="14.83" x2="19.07" y2="19.07"></line>
                  <line x1="14.83" y1="9.17" x2="19.07" y2="4.93"></line>
                  <line x1="14.83" y1="9.17" x2="18.36" y2="5.64"></line>
                  <line x1="4.93" y1="19.07" x2="9.17" y2="14.83"></line>
                </svg>
              </Button>
              <Button
                className="bg-white text-black p-2 hover:bg-gray-100 mt-1"
                onClick={() => window.map?.zoomIn()}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="12" y1="5" x2="12" y2="19"></line>
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
              </Button>
              <Button
                className="bg-white text-black p-2 hover:bg-gray-100 mt-1"
                onClick={() => window.map?.zoomOut()}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
              </Button>
            </div>
          </div>
        </MapContainer>
      </div>
      
      <div className="mt-2 text-xs text-gray-500">
        <p>Fonte dati: OpenStreetMap contributors | © {new Date().getFullYear()} BoomHouse</p>
      </div>
    </div>
  );
}