import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Loader2, X, MapPin } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface AddressSearchProps {
  onAddressFound: (lat: number, lng: number, name: string) => void;
}

export default function AddressSearch({ onAddressFound }: AddressSearchProps) {
  const [query, setQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [isMapReady, setIsMapReady] = useState(false);

  // Verifica se la mappa è pronta
  useEffect(() => {
    const checkMapStatus = () => {
      if (typeof window !== 'undefined' && window.map && window.L) {
        setIsMapReady(true);
      } else {
        setTimeout(checkMapStatus, 500);
      }
    };
    
    checkMapStatus();
    
    return () => {
      setIsMapReady(false);
    };
  }, []);

  const handleSearch = async () => {
    if (!query.trim()) return;
    
    setIsSearching(true);
    
    try {
      // Mostra indicatore di caricamento
      toast({
        title: "Ricerca in corso...",
        description: "Sto cercando l'indirizzo specificato",
      });
      
      // Usiamo un sistema di geocoding robusto con retry
      const maxRetries = 2;
      let retryCount = 0;
      let data;
      let response;
      
      // Funzione di geocoding con retry
      const performGeocoding = async () => {
        response = await fetch(`/api/geocode?q=${encodeURIComponent(query)}&limit=1&lang=it`);
        
        if (!response.ok) {
          throw new Error(`Errore HTTP: ${response.status}`);
        }
        
        return await response.json();
      };
      
      // Tentiamo il geocoding con strategia di retry
      while (retryCount <= maxRetries) {
        try {
          data = await performGeocoding();
          if (data && data.features && data.features.length > 0) {
            break; // Abbiamo ottenuto un risultato valido
          }
          retryCount++;
          
          if (retryCount <= maxRetries) {
            // Attendiamo prima di riprovare (backoff esponenziale)
            await new Promise(resolve => setTimeout(resolve, 500 * Math.pow(2, retryCount)));
          }
        } catch (geocodingError) {
          console.error(`Tentativo ${retryCount + 1} fallito:`, geocodingError);
          retryCount++;
          
          if (retryCount <= maxRetries) {
            await new Promise(resolve => setTimeout(resolve, 500 * Math.pow(2, retryCount)));
          } else {
            throw geocodingError; // Rilancia l'errore dopo tutti i tentativi
          }
        }
      }
      
      if (data && data.features && data.features.length > 0) {
        const feature = data.features[0];
        const coords = feature.geometry.coordinates;
        const lng = coords[0];
        const lat = coords[1];
        const name = feature.properties.name || query;
        const city = feature.properties.city || '';
        const street = feature.properties.street || '';
        const housenumber = feature.properties.housenumber || '';
        const displayName = `${name}${street ? ', ' + street : ''}${housenumber ? ' ' + housenumber : ''}${city ? ', ' + city : ''}`;
        
        console.log("Posizione trovata:", { lat, lng, displayName });
        
        // Se la mappa è pronta, aggiungiamo il marker direttamente
        if (isMapReady && window.map && typeof window.map.setView === 'function') {
          try {
            // Centriamo la mappa sulla posizione trovata
            window.map.setView([lat, lng], 16);
            
            // Attendiamo un breve istante per dare il tempo alla mappa di impostare la vista
            setTimeout(() => {
              try {
                // Rimuoviamo vecchi marker con classe "search-result-marker"
                window.map.eachLayer((layer: any) => {
                  if (layer && layer._icon && layer._icon.classList && 
                      layer._icon.classList.contains("search-result-marker")) {
                    window.map.removeLayer(layer);
                  }
                });
                
                // Creiamo un'icona di ricerca personalizzata
                const searchIcon = window.L.divIcon({
                  html: `<div class="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-white shadow-lg">
                          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="11" cy="11" r="8"></circle>
                            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                          </svg>
                        </div>`,
                  className: 'search-result-marker',
                  iconSize: [24, 24],
                  iconAnchor: [12, 12]
                });
                
                // Aggiungiamo un marker con popup
                const marker = window.L.marker([lat, lng], { icon: searchIcon }).addTo(window.map);
                
                marker.bindPopup(`
                  <div class="p-2 text-center">
                    <strong class="text-primary block mb-1">${displayName}</strong>
                    <span class="text-sm text-gray-600">Posizione ricercata</span>
                  </div>
                `).openPopup();
                
              } catch (delayedError) {
                console.error("Errore nell'aggiunta del marker:", delayedError);
              }
            }, 300);
          } catch (mapError) {
            console.error("Errore nell'interazione con la mappa:", mapError);
          }
        }
        
        // Chiamiamo sempre la callback per garantire il funzionamento
        onAddressFound(lat, lng, displayName);
        
        // Notifica di successo
        toast({
          title: "Indirizzo trovato",
          description: "La mappa è stata centrata sulla posizione",
          variant: "default"
        });
      } else {
        toast({
          title: "Indirizzo non trovato",
          description: "Non è stato possibile trovare l'indirizzo. Prova con termini più specifici o un altro formato.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Errore nella ricerca:", error);
      toast({
        title: "Errore di ricerca",
        description: "Si è verificato un errore durante la ricerca dell'indirizzo.",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="flex space-x-2 items-center w-full">
      <div className="relative flex-1">
        <Input
          type="text"
          placeholder="Cerca un indirizzo (es. Via Nassa 1, Lugano)"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              handleSearch();
            }
          }}
          className="pl-9 pr-4"
          disabled={isSearching}
        />
        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
          <MapPin size={16} className={isMapReady ? "text-primary" : "text-gray-400"} />
        </div>
        {query.trim().length > 0 && (
          <button 
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
            onClick={() => setQuery('')}
          >
            <X size={14} />
          </button>
        )}
      </div>
      <Button 
        variant="default" 
        size="sm"
        onClick={handleSearch}
        disabled={isSearching || !isMapReady}
        title={!isMapReady ? "Attendi il caricamento della mappa" : "Cerca indirizzo"}
      >
        {isSearching ? <Loader2 size={18} className="animate-spin" /> : <Search size={18} />}
      </Button>
    </div>
  );
}