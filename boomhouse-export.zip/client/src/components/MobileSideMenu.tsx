import React, { useState } from 'react';
import { Link } from 'wouter';
import {
  Building,
  Home,
  Info,
  HelpCircle,
  Star,
  MessageSquare,
  Briefcase,
  Play,
} from 'lucide-react';

const MobileSideMenu: React.FC = () => {
  return (
    <div className="bg-white dark:bg-gray-900 rounded-md overflow-hidden">
      {/* BOOMHOUSE Section */}
      <div className="mb-4">
        <div className="bg-gray-100 dark:bg-gray-800 px-4 py-3 flex items-center">
          <Home className="mr-2 h-5 w-5" />
          <span className="font-semibold">BOOMHOUSE</span>
        </div>
        <ul className="py-1">
          <li>
            <Link href="/chi-siamo" className="flex items-center px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-800">
              <Info className="mr-2 h-5 w-5 text-gray-600 dark:text-gray-400" />
              <span>Chi Siamo</span>
            </Link>
          </li>
          <li>
            <Link href="/come-funziona" className="flex items-center px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-800">
              <HelpCircle className="mr-2 h-5 w-5 text-gray-600 dark:text-gray-400" />
              <span>Come funziona</span>
            </Link>
          </li>
          <li>
            <Link href="/recensioni" className="flex items-center px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-800">
              <Star className="mr-2 h-5 w-5 text-gray-600 dark:text-gray-400" />
              <span>Recensioni</span>
            </Link>
          </li>
          <li>
            <Link href="/contattaci" className="flex items-center px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-800">
              <MessageSquare className="mr-2 h-5 w-5 text-gray-600 dark:text-gray-400" />
              <span>Contattaci</span>
            </Link>
          </li>
          <li>
            <Link href="/diventa-partner" className="flex items-center px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-800">
              <Briefcase className="mr-2 h-5 w-5 text-gray-600 dark:text-gray-400" />
              <span>Diventa partner</span>
            </Link>
          </li>
        </ul>
      </div>

      {/* IMMOBILI Section */}
      <div className="mb-4">
        <div className="bg-gray-100 dark:bg-gray-800 px-4 py-3 flex items-center">
          <Building className="mr-2 h-5 w-5" />
          <span className="font-semibold">IMMOBILI</span>
        </div>
        <ul className="py-1">
          <li>
            <Link href="/case-appartamenti" className="flex items-center px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-800">
              <Home className="mr-2 h-5 w-5 text-gray-600 dark:text-gray-400" />
              <span>Case e appartamenti</span>
            </Link>
          </li>
          <li>
            <Link href="/immobili-commerciali" className="flex items-center px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-800">
              <Building className="mr-2 h-5 w-5 text-gray-600 dark:text-gray-400" />
              <span>Immobili commerciali</span>
            </Link>
          </li>
          <li>
            <Link href="/terreni" className="flex items-center px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-800">
              <Home className="mr-2 h-5 w-5 text-gray-600 dark:text-gray-400" />
              <span>Terreni</span>
            </Link>
          </li>
        </ul>
      </div>

      {/* Boom Reels Button */}
      <Link href="/boom-reels" className="block bg-blue-600 hover:bg-blue-700 text-white px-4 py-3 mb-4">
        <div className="flex items-center">
          <Play className="mr-2 h-5 w-5" />
          <span className="font-semibold">Boom Reels</span>
        </div>
      </Link>
    </div>
  );
};

export default MobileSideMenu;