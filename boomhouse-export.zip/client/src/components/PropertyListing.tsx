import { useState, useRef } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, CheckCircle2, Image, Upload, X } from "lucide-react";
import AddressSearch from "./AddressSearch";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

// Funzione per controllare il contenuto NSFW/inappropriato delle immagini
// Questa sarebbe normalmente implementata con un servizio di moderazione AI
// Per ora facciamo un controllo di base sulle dimensioni e formato
function validateImage(file: File): Promise<{ valid: boolean; reason?: string }> {
  return new Promise((resolve) => {
    // Verifica le dimensioni del file (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      resolve({ valid: false, reason: "L'immagine è troppo grande. Il limite è di 5MB." });
      return;
    }

    // Verifica il tipo di file
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      resolve({ valid: false, reason: "Formato non supportato. Usa JPEG, PNG o WebP." });
      return;
    }

    // Crea un'anteprima per verificare le dimensioni dell'immagine
    const img = new window.Image();
    const objectUrl = URL.createObjectURL(file);
    
    img.onload = function() {
      URL.revokeObjectURL(objectUrl);
      
      // Verifica le dimensioni minime dell'immagine
      if (img.width < 200 || img.height < 200) {
        resolve({ valid: false, reason: "L'immagine è troppo piccola. Dimensione minima: 200x200 pixel." });
        return;
      }

      // In un'implementazione reale, qui si invierebbe l'immagine a un API di moderazione
      // per verificare contenuti NSFW o inappropriati
      
      resolve({ valid: true });
    };
    
    img.onerror = function() {
      URL.revokeObjectURL(objectUrl);
      resolve({ valid: false, reason: "Impossibile caricare l'immagine. Potrebbe essere danneggiata." });
    };
    
    img.src = objectUrl;
  });
}

// Schema di validazione
const propertyFormSchema = z.object({
  title: z.string().min(5, { message: "Il titolo deve essere di almeno 5 caratteri" }),
  description: z.string().min(20, { message: "La descrizione deve essere di almeno 20 caratteri" }),
  address: z.string().min(5, { message: "L'indirizzo è obbligatorio" }),
  price: z.string().min(1, { message: "Il prezzo è obbligatorio" }),
  propertyType: z.string().min(1, { message: "Il tipo di proprietà è obbligatorio" }),
  listingType: z.string().min(1, { message: "Specificare se in vendita o in affitto" }),
  beds: z.string().optional(),
  baths: z.string().optional(),
  area: z.string().min(1, { message: "La superficie è obbligatoria" }),
  landArea: z.string().optional(),
  yearBuilt: z.string().optional(),
  termsAgreed: z.boolean().refine(val => val === true, {
    message: "Devi accettare i termini e le condizioni"
  }),
  privacyAgreed: z.boolean().refine(val => val === true, {
    message: "Devi accettare la politica sulla privacy"
  }),
  contentAgreed: z.boolean().refine(val => val === true, {
    message: "Devi confermare che le immagini sono appropriate"
  }),
});

type PropertyFormValues = z.infer<typeof propertyFormSchema>;

export default function PropertyListing() {
  const [open, setOpen] = useState(false);
  const [images, setImages] = useState<{ file: File; preview: string; }[]>([]);
  const [coordinates, setCoordinates] = useState<{ lat: number; lng: number } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Configurazione del form con validazione
  const form = useForm<PropertyFormValues>({
    resolver: zodResolver(propertyFormSchema),
    defaultValues: {
      title: "",
      description: "",
      address: "",
      price: "",
      propertyType: "Appartamento",
      listingType: "For Sale",
      beds: "",
      baths: "",
      area: "",
      landArea: "",
      yearBuilt: "",
      termsAgreed: false,
      privacyAgreed: false,
      contentAgreed: false,
    },
  });

  // Gestione per l'aggiunta di immagini
  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    
    const newImages = [...images];
    let hasErrors = false;
    
    for (let i = 0; i < e.target.files.length; i++) {
      const file = e.target.files[i];
      
      // Verifica l'immagine
      const validation = await validateImage(file);
      
      if (!validation.valid) {
        toast({
          title: "Errore immagine",
          description: validation.reason,
          variant: "destructive",
        });
        hasErrors = true;
        continue;
      }
      
      // Crea l'anteprima
      const preview = URL.createObjectURL(file);
      newImages.push({ file, preview });
      
      // Limita a 10 immagini
      if (newImages.length >= 10) break;
    }
    
    if (hasErrors) {
      toast({
        title: "Alcune immagini non sono state caricate",
        description: "Verifica che le immagini rispettino i requisiti richiesti.",
        variant: "destructive",
      });
    }
    
    setImages(newImages);
    
    // Reset dell'input file
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  // Rimuovi un'immagine
  const removeImage = (index: number) => {
    const newImages = [...images];
    URL.revokeObjectURL(newImages[index].preview);
    newImages.splice(index, index + 1);
    setImages(newImages);
  };

  // Gestione dell'indirizzo con coordinate
  const handleAddressFound = (lat: number, lng: number, address: string) => {
    setCoordinates({ lat, lng });
    form.setValue("address", address);
  };

  // Mutazione per aggiungere un immobile
  const addPropertyMutation = useMutation({
    mutationFn: async (data: FormData) => {
      return await apiRequest("POST", "/api/properties", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/properties'] });
      setSuccess(true);
      setIsSubmitting(false);
      
      // Pulisci il form e le immagini dopo un breve periodo
      setTimeout(() => {
        form.reset();
        setImages([]);
        setCoordinates(null);
        setSuccess(false);
        setOpen(false);
      }, 3000);
    },
    onError: (error: any) => {
      setError(error.message || "Si è verificato un errore durante il caricamento dell'annuncio");
      setIsSubmitting(false);
    }
  });

  // Invio del form
  const onSubmit = async (data: PropertyFormValues) => {
    if (!user) {
      toast({
        title: "Accesso richiesto",
        description: "Devi effettuare l'accesso per pubblicare un annuncio",
        variant: "destructive",
      });
      return;
    }
    
    if (images.length === 0) {
      toast({
        title: "Immagini obbligatorie",
        description: "Devi caricare almeno un'immagine",
        variant: "destructive",
      });
      return;
    }
    
    if (!coordinates) {
      toast({
        title: "Indirizzo non valido",
        description: "Seleziona un indirizzo valido dalla ricerca",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    setError(null);
    
    try {
      // Preparazione dei dati per l'invio
      const formData = new FormData();
      
      // Dati di base
      Object.entries(data).forEach(([key, value]) => {
        if (key !== "termsAgreed" && key !== "privacyAgreed" && key !== "contentAgreed") {
          formData.append(key, value.toString());
        }
      });
      
      // Coordinate
      formData.append("lat", coordinates.lat.toString());
      formData.append("lng", coordinates.lng.toString());
      
      // Immagini
      images.forEach((image, index) => {
        formData.append(`image${index}`, image.file);
      });
      
      // Invio al server
      await addPropertyMutation.mutateAsync(formData);
    } catch (err) {
      console.error("Error submitting form:", err);
      setError("Si è verificato un errore durante il caricamento dell'annuncio");
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button id="publish-property-trigger" variant="default" className="flex items-center gap-2">
          <Upload size={16} /> Pubblica Annuncio
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Pubblica un annuncio immobiliare</DialogTitle>
        </DialogHeader>
        
        {success ? (
          <div className="flex flex-col items-center justify-center py-10">
            <CheckCircle2 className="text-green-500 h-16 w-16 mb-4" />
            <h3 className="text-xl font-semibold text-center">Annuncio pubblicato con successo!</h3>
            <p className="text-center text-muted-foreground mt-2">
              Il tuo annuncio è stato pubblicato e sarà presto visibile a tutti gli utenti.
            </p>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Errore</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-6">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Titolo dell'annuncio</FormLabel>
                        <FormControl>
                          <Input placeholder="es. Villa con piscina in zona tranquilla" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Descrizione</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Descrivi la proprietà in dettaglio..." 
                            className="min-h-[150px]" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="space-y-2">
                    <FormLabel>Indirizzo</FormLabel>
                    <AddressSearch onAddressFound={handleAddressFound} />
                    <FormField
                      control={form.control}
                      name="address"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input className="mt-2" {...field} readOnly />
                          </FormControl>
                          <FormDescription>
                            Cerca un indirizzo e selezionalo dai risultati
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="price"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Prezzo (CHF)</FormLabel>
                          <FormControl>
                            <Input placeholder="es. 1'250'000" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="area"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Superficie (m²)</FormLabel>
                          <FormControl>
                            <Input placeholder="es. 120" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="beds"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Camere da letto</FormLabel>
                          <FormControl>
                            <Input placeholder="es. 3" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="baths"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bagni</FormLabel>
                          <FormControl>
                            <Input placeholder="es. 2" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="propertyType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tipo di proprietà</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Seleziona tipo" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Appartamento">Appartamento</SelectItem>
                              <SelectItem value="Villa">Villa</SelectItem>
                              <SelectItem value="Casa">Casa</SelectItem>
                              <SelectItem value="Rustico">Rustico</SelectItem>
                              <SelectItem value="Terreno">Terreno</SelectItem>
                              <SelectItem value="Commerciale">Commerciale</SelectItem>
                              <SelectItem value="Altro">Altro</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="listingType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tipo di annuncio</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Seleziona tipo" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="For Sale">In vendita</SelectItem>
                              <SelectItem value="For Rent">In affitto</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="landArea"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Area terreno (m²)</FormLabel>
                          <FormControl>
                            <Input placeholder="es. 500" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="yearBuilt"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Anno di costruzione</FormLabel>
                          <FormControl>
                            <Input placeholder="es. 2010" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <FormLabel>Immagini (max 10)</FormLabel>
                    <div className="border border-dashed rounded-md p-4 text-center cursor-pointer hover:bg-gray-50 transition"
                         onClick={() => fileInputRef.current?.click()}>
                      <Image className="h-8 w-8 mx-auto text-gray-400" />
                      <p className="mt-2 text-sm text-gray-600">
                        Clicca per caricare immagini o trascina i file qui
                      </p>
                      <p className="text-xs text-gray-400 mt-1">
                        JPG, PNG o WebP fino a 5MB
                      </p>
                    </div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      className="hidden"
                      accept="image/jpeg,image/png,image/webp"
                      multiple
                      onChange={handleImageChange}
                    />
                    
                    {images.length > 0 && (
                      <div className="mt-4 grid grid-cols-3 gap-2">
                        {images.map((image, index) => (
                          <div key={index} className="relative group">
                            <img 
                              src={image.preview} 
                              alt={`Preview ${index}`}
                              className="h-24 w-full object-cover rounded-md" 
                            />
                            <button
                              type="button"
                              className="absolute top-1 right-1 bg-red-600 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition"
                              onClick={() => removeImage(index)}
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2 border-t pt-4 mt-4">
                    <FormField
                      control={form.control}
                      name="termsAgreed"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox 
                              checked={field.value} 
                              onCheckedChange={field.onChange} 
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>
                              Accetto i termini e le condizioni
                            </FormLabel>
                            <FormDescription>
                              Ho letto e accetto i termini e le condizioni di utilizzo della piattaforma.
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="privacyAgreed"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox 
                              checked={field.value} 
                              onCheckedChange={field.onChange} 
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>
                              Accetto la politica sulla privacy
                            </FormLabel>
                            <FormDescription>
                              Comprendo come vengono trattati i miei dati personali secondo la politica sulla privacy.
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="contentAgreed"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox 
                              checked={field.value} 
                              onCheckedChange={field.onChange} 
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>
                              Confermo la conformità delle immagini
                            </FormLabel>
                            <FormDescription>
                              Confermo che le immagini caricate sono di mia proprietà o ho il diritto di utilizzarle,
                              e che non contengono contenuti inappropriati o illegali.
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setOpen(false)}
                  disabled={isSubmitting}
                >
                  Annulla
                </Button>
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Pubblicazione in corso..." : "Pubblica annuncio"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}