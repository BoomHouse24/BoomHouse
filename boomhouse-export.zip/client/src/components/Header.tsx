import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Calculator, LogOut, Search, User, Heart, Moon, Sun, Home, Upload, Building, Info, HelpCircle, Star, MessageSquare, Briefcase } from "lucide-react";
import AddressSearch from "@/components/AddressSearch";
import { useAuth } from "@/hooks/use-auth";
import { useTheme } from "@/components/ThemeProvider";
import PropertyListing from "@/components/PropertyListing";
import AnimatedLogo from "@/components/AnimatedLogo";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface HeaderProps {
  onOpenCalculator: () => void;
}

export default function Header({ onOpenCalculator }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { user, logoutMutation } = useAuth();
  const [location, setLocation] = useLocation();
  const { theme, toggleTheme } = useTheme();
  
  // Simuliamo il caricamento quando si naviga tra le pagine
  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [location]);

  // Funzione di gestione degli indirizzi trovati
  const handleAddressFound = (lat: number, lng: number, name: string) => {
    console.log("Indirizzo trovato nel header:", lat, lng, name);
    // Non dobbiamo fare nulla qui, il componente AddressSearch gestisce già tutto
    // Nascondiamo la barra di ricerca dopo un successo
    setShowSearch(false);
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="bg-[#003580] dark:bg-[#00224f] shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link href="/" className="flex items-center space-x-2">
                <AnimatedLogo size={28} isAnimating={isLoading} />
                <h1 className="text-xl font-bold text-white cursor-pointer hover:text-blue-100 transition-colors">BoomHouse</h1>
              </Link>
            </div>
            <nav className="hidden md:ml-6 md:flex space-x-8">
              <Link href="/" className="border-b-2 border-white text-white px-1 pt-1 font-medium text-sm">
                Proprietà
              </Link>
              <Link href="/professionisti" className="border-transparent text-blue-100 hover:border-blue-300 hover:text-white border-b-2 px-1 pt-1 font-medium text-sm">
                Professionisti
              </Link>
              <Link href="/banche" className="border-transparent text-blue-100 hover:border-blue-300 hover:text-white border-b-2 px-1 pt-1 font-medium text-sm">
                Banche
              </Link>
              
              {/* Menu a tendina BOOMHOUSE */}
              <DropdownMenu>
                <DropdownMenuTrigger className="border-transparent text-blue-100 hover:border-blue-300 hover:text-white border-b-2 px-1 pt-1 font-medium text-sm flex items-center">
                  <Home className="mr-1 h-4 w-4" />
                  <span>BOOMHOUSE</span>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-56 bg-white dark:bg-gray-900">
                  <DropdownMenuItem onClick={() => setLocation("/chi-siamo")}>
                    <Info className="mr-2 h-4 w-4" />
                    <span>Chi siamo</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/come-funziona")}>
                    <HelpCircle className="mr-2 h-4 w-4" />
                    <span>Come funziona</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/recensioni")}>
                    <Star className="mr-2 h-4 w-4" />
                    <span>Recensioni</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/contattaci")}>
                    <MessageSquare className="mr-2 h-4 w-4" />
                    <span>Contattaci</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/diventa-partner")}>
                    <Briefcase className="mr-2 h-4 w-4" />
                    <span>Diventa partner</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              {/* Menu a tendina IMMOBILI */}
              <DropdownMenu>
                <DropdownMenuTrigger className="border-transparent text-blue-100 hover:border-blue-300 hover:text-white border-b-2 px-1 pt-1 font-medium text-sm flex items-center">
                  <Building className="mr-1 h-4 w-4" />
                  <span>IMMOBILI</span>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-56 bg-white dark:bg-gray-900">
                  <DropdownMenuItem onClick={() => setLocation("/case-appartamenti")}>
                    <Home className="mr-2 h-4 w-4" />
                    <span>Case e appartamenti</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/immobili-commerciali")}>
                    <Building className="mr-2 h-4 w-4" />
                    <span>Immobili commerciali</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/terreni")}>
                    <Home className="mr-2 h-4 w-4" />
                    <span>Terreni</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => document.getElementById("publish-property-trigger")?.click()}>
                    <Upload className="mr-2 h-4 w-4" />
                    <span>Inserisci un annuncio</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Link href="/boom-reels" className="flex items-center border-transparent text-white bg-blue-700 hover:bg-blue-800 rounded-full px-3 py-1 ml-2 font-medium text-sm">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                Boom Reels
              </Link>
            </nav>
          </div>

          <div className="hidden md:flex items-center space-x-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="rounded-full w-8 h-8 bg-white/90 dark:bg-gray-800 text-gray-600 dark:text-gray-200"
              aria-label="Cambia tema"
            >
              {theme === "dark" ? (
                <Sun className="h-4 w-4" />
              ) : (
                <Moon className="h-4 w-4" />
              )}
            </Button>

            {showSearch ? (
              <div className="w-64 flex-grow max-w-md mr-2">
                <AddressSearch onAddressFound={handleAddressFound} />
              </div>
            ) : (
              <>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowSearch(true)}
                  className="flex items-center space-x-1"
                >
                  <Search className="h-4 w-4" />
                  <span>Cerca indirizzo</span>
                </Button>
                <a 
                  href="/searchable_map.html" 
                  target="_blank" 
                  className="inline-flex items-center space-x-2 px-3 py-2 text-sm border rounded-md border-gray-300 bg-white dark:bg-gray-800 dark:border-gray-700 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700 shadow-sm"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
                  <span>Mappa avanzata</span>
                </a>
              </>
            )}
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                onClick={onOpenCalculator}
                className="flex items-center space-x-2 border-primary"
              >
                <Calculator className="h-4 w-4" />
                <span>Calcolo Ipoteca</span>
              </Button>
              
              <Button
                variant="default"
                className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white"
                onClick={() => document.getElementById("publish-property-trigger")?.click()}
              >
                <Upload className="h-4 w-4" />
                <span>Pubblica</span>
              </Button>
            </div>
            
            <div className="hidden">
              <PropertyListing />
            </div>

            {user ? (
              <>
                <Link href="/preferiti">
                  <Button 
                    variant="outline" 
                    className="flex items-center space-x-2"
                  >
                    <Heart className="h-4 w-4" />
                    <span>Preferiti</span>
                  </Button>
                </Link>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-9 w-9 rounded-full">
                      <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-white">
                        <User className="h-5 w-5" />
                      </div>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Il mio account</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>
                      <User className="mr-2 h-4 w-4" />
                      <span>Profilo</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setLocation("/preferiti")}>
                      <Heart className="mr-2 h-4 w-4" />
                      <span>Preferiti</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Logout</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <Link href="/auth">
                <Button className="booking-btn-secondary">
                  Accedi
                </Button>
              </Link>
            )}
          </div>

          <div className="flex md:hidden">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary"
            >
              <span className="sr-only">Open main menu</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d={mobileMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"}
                />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden bg-white dark:bg-gray-900 shadow-sm pb-3 pt-2">
          <div className="px-2 space-y-1">
            <div className="mb-2">
              <AddressSearch onAddressFound={handleAddressFound} />
            </div>
            <Link href="/" className="bg-gray-100 dark:bg-gray-800 text-primary dark:text-blue-300 block px-3 py-2 rounded-md text-base font-medium">
              Proprietà
            </Link>
            <Link href="/professionisti" className="text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white block px-3 py-2 rounded-md text-base font-medium">
              Professionisti
            </Link>
            <Link href="/banche" className="text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white block px-3 py-2 rounded-md text-base font-medium">
              Banche
            </Link>
            
            {/* Link BOOMHOUSE e IMMOBILI rimossi da questo menu */}
            
            {user && (
              <Link href="/preferiti" className="text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                <div className="flex items-center space-x-2">
                  <Heart className="h-4 w-4" />
                  <span>Preferiti</span>
                </div>
              </Link>
            )}
            
            <Button 
              variant="default"
              onClick={() => document.getElementById("publish-property-trigger")?.click()}
              className="mt-2 w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Upload className="h-4 w-4" />
              <span>Pubblica Annuncio</span>
            </Button>
            
            <Button 
              variant="outline" 
              onClick={onOpenCalculator}
              className="mt-2 w-full flex items-center justify-center space-x-2 border-primary dark:border-blue-500 dark:text-blue-300"
            >
              <Calculator className="h-4 w-4" />
              <span>Calcolo Ipoteca</span>
            </Button>
            <a 
              href="/searchable_map.html" 
              target="_blank" 
              className="mt-2 w-full flex items-center justify-center space-x-2 px-3 py-2 text-sm border rounded-md border-gray-300 bg-white dark:bg-gray-800 dark:border-gray-700 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700 shadow-sm"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
              <span>Mappa avanzata</span>
            </a>
            
            <Button
              variant="outline"
              onClick={toggleTheme}
              className="mt-2 w-full flex items-center justify-center space-x-2"
            >
              {theme === "dark" ? (
                <>
                  <Sun className="h-4 w-4" />
                  <span>Modalità chiara</span>
                </>
              ) : (
                <>
                  <Moon className="h-4 w-4" />
                  <span>Modalità scura</span>
                </>
              )}
            </Button>
            
            {user ? (
              <Button 
                variant="destructive" 
                onClick={handleLogout} 
                className="mt-2 w-full flex items-center justify-center"
              >
                <LogOut className="h-4 w-4 mr-2" />
                <span>Logout</span>
              </Button>
            ) : (
              <Link href="/auth">
                <Button 
                  className="mt-2 w-full booking-btn-secondary"
                >
                  Accedi
                </Button>
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
