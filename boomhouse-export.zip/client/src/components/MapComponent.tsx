import React, { useEffect, useRef, useState } from 'react';
import { PropertyType, ProfessionalType, BankType, ListingType } from "@/lib/types";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import AddressSearch from "./AddressSearch";

// Dichiarazione per Window globale
declare global {
  interface Window {
    L: any;
    map: any;
  }
}

interface MapComponentProps {
  properties: PropertyType[];
  professionals: ProfessionalType[];
  banks: BankType[];
  onMarkerClick: (item: PropertyType | ProfessionalType | BankType, type: ListingType) => void;
}

const MapComponent: React.FC<MapComponentProps> = ({ 
  properties, 
  professionals, 
  banks, 
  onMarkerClick 
}) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const [mapReady, setMapReady] = useState(false);
  const [activeLayer, setActiveLayer] = useState<'standard' | 'cadastral' | 'satellite'>('standard');
  
  // Display control states
  const [showProperties, setShowProperties] = useState(true);
  const [showProfessionals, setShowProfessionals] = useState(false);
  const [showBanks, setShowBanks] = useState(false);

  // Funzione per inizializzare la mappa
  const initializeMap = () => {
    if (!mapRef.current || typeof window === 'undefined' || !window.L) return;
    
    console.log("Initializing map...");
    
    // Rimuovi mappa esistente se presente
    if (window.map) {
      window.map.remove();
      window.map = null;
    }
    
    // Centro della mappa (Ticino, Svizzera)
    const center = [46.0036, 8.9510]; 
    
    // Crea la mappa
    const map = window.L.map(mapRef.current, {
      center,
      zoom: 10,
      minZoom: 7,
      maxZoom: 18,
      zoomControl: true,
      scrollWheelZoom: true,
      attributionControl: true
    });
    
    // Salva riferimento globale alla mappa
    window.map = map;
    
    // Inizializza i layer
    const baseLayers = {
      standard: window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19
      }),
      satellite: window.L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Imagery &copy; Esri &copy; Maxar &copy; Earthstar Geographics',
        maxZoom: 19
      }),
      cadastral: window.L.tileLayer.wms('https://wms.geo.admin.ch/', {
        layers: 'ch.swisstopo-vd.amtliche-vermessung',
        format: 'image/png',
        transparent: true,
        version: '1.3.0',
        attribution: '&copy; <a href="https://www.swisstopo.admin.ch/">Swisstopo</a>'
      })
    };
    
    // Aggiungi il layer base predefinito
    baseLayers[activeLayer].addTo(map);
    
    // Controllo dei layer
    window.L.control.layers({
      'Standard': baseLayers.standard,
      'Satellite': baseLayers.satellite,
      'Catastale': baseLayers.cadastral
    }).addTo(map);
    
    // Aggiungi controllo per lo zoom
    window.L.control.zoom({
      position: 'bottomright'
    }).addTo(map);
    
    // Aggiungi la scala
    window.L.control.scale({
      imperial: false,
      metric: true,
      position: 'bottomleft'
    }).addTo(map);
    
    // Aggiungiamo un pulsante personalizzato per la geolocalizzazione
    const locationButton = window.L.control({position: 'bottomright'});
    locationButton.onAdd = function() {
      const div = window.L.DomUtil.create('div', 'leaflet-bar leaflet-control');
      div.innerHTML = `<a href="#" title="Mostra la mia posizione" style="display:flex;align-items:center;justify-content:center;width:30px;height:30px;">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="10"></circle>
          <circle cx="12" cy="12" r="3"></circle>
        </svg>
      </a>`;
      
      // Aggiungiamo l'evento click
      div.onclick = function(e: MouseEvent) {
        e.preventDefault();
        
        if (navigator.geolocation) {
          map.spin(true);
          navigator.geolocation.getCurrentPosition(
            function(position) {
              // Success
              const lat = position.coords.latitude;
              const lng = position.coords.longitude;
              map.setView([lat, lng], 16);
              
              // Aggiungi un marker temporaneo
              const marker = window.L.marker([lat, lng], {
                icon: window.L.divIcon({
                  html: '<div style="width:16px;height:16px;border-radius:50%;background-color:#2563eb;border:2px solid white;box-shadow:0 0 10px rgba(0,0,0,0.5);"></div>',
                  className: 'location-marker',
                  iconSize: [16, 16],
                  iconAnchor: [8, 8]
                })
              }).addTo(map);
              
              // Rimuovi il marker dopo 5 secondi
              setTimeout(() => map.removeLayer(marker), 5000);
              
              map.spin(false);
              
              toast({
                title: "Posizione trovata",
                description: "La mappa è stata centrata sulla tua posizione attuale",
              });
            },
            function(error) {
              // Error
              map.spin(false);
              
              let errorMsg = "Impossibile determinare la tua posizione";
              switch(error.code) {
                case error.PERMISSION_DENIED:
                  errorMsg = "Accesso alla posizione negato";
                  break;
                case error.POSITION_UNAVAILABLE:
                  errorMsg = "Informazioni sulla posizione non disponibili";
                  break;
                case error.TIMEOUT:
                  errorMsg = "Richiesta della posizione scaduta";
                  break;
              }
              
              toast({
                title: "Errore di geolocalizzazione",
                description: errorMsg,
                variant: "destructive"
              });
            },
            {
              enableHighAccuracy: true,
              timeout: 10000,
              maximumAge: 0
            }
          );
        } else {
          toast({
            title: "Geolocalizzazione non supportata",
            description: "Il tuo browser non supporta la geolocalizzazione",
            variant: "destructive"
          });
        }
        
        return false;
      };
      
      return div;
    };
    locationButton.addTo(map);
    
    // Aggiungiamo un metodo spin alla mappa per mostrare un indicatore di caricamento
    map.spin = function(show: boolean) {
      // Implementazione semplice per mostrare/nascondere un indicatore di caricamento
      const spinnerClass = 'map-spinner';
      let spinner = document.querySelector(`.${spinnerClass}`);
      
      if (show) {
        if (!spinner) {
          spinner = document.createElement('div');
          spinner.className = spinnerClass;
          spinner.innerHTML = `<div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:rgba(255,255,255,0.8);border-radius:4px;padding:12px;z-index:1000;display:flex;flex-direction:column;align-items:center;box-shadow:0 2px 6px rgba(0,0,0,0.2);">
            <div style="width:24px;height:24px;border:3px solid #f3f3f3;border-top:3px solid #2563eb;border-radius:50%;animation:spin 1s linear infinite;"></div>
            <div style="margin-top:8px;font-size:14px;color:#333;">Caricamento...</div>
          </div>
          <style>@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }</style>`;
          const mapEl = document.querySelector('#map');
          if (mapEl) {
            mapEl.appendChild(spinner);
          }
        }
      } else if (spinner) {
        spinner.remove();
      }
    };
    
    // Gestione evento di cambio layer
    map.on('baselayerchange', function(e: any) {
      if (e.name === 'Standard') {
        setActiveLayer('standard');
      } else if (e.name === 'Satellite') {
        setActiveLayer('satellite');
      } else if (e.name === 'Catastale') {
        setActiveLayer('cadastral');
      }
    });
    
    // La mappa è pronta
    setMapReady(true);
    console.log("Map initialization complete");
    
    // Aggiungi i marker
    updateMarkers();
  };
  
  // Funzione per creare l'icona del marker
  const createMarkerIcon = (type: ListingType) => {
    if (!window.L) return null;
    
    // Colori per i diversi tipi di marker
    const colors = {
      property: '#2563eb', // Blu
      professional: '#16a34a', // Verde
      bank: '#d97706' // Arancione
    };
    
    const circleRadius = 8;
    const svgSize = circleRadius * 2;
    
    const svgContent = `
      <svg xmlns="http://www.w3.org/2000/svg" width="${svgSize}" height="${svgSize}" viewBox="0 0 ${svgSize} ${svgSize}">
        <circle cx="${circleRadius}" cy="${circleRadius}" r="${circleRadius}" fill="${colors[type]}" stroke="white" stroke-width="1"/>
      </svg>
    `;
    
    // Conversione SVG in base64
    const iconUrl = `data:image/svg+xml;base64,${btoa(svgContent)}`;
    
    return window.L.icon({
      iconUrl,
      iconSize: [svgSize, svgSize],
      iconAnchor: [circleRadius, circleRadius],
      popupAnchor: [0, -circleRadius]
    });
  };
  
  // Funzione per aggiornare i marker sulla mappa
  const updateMarkers = () => {
    if (!window.map || !window.L) return;
    
    // Rimuovi tutti i marker esistenti
    window.map.eachLayer((layer: any) => {
      if (layer instanceof window.L.Marker) {
        window.map.removeLayer(layer);
      }
    });
    
    // Aggiungi marker per le proprietà
    if (showProperties) {
      properties.forEach(property => {
        if (!property.lat || !property.lng) return;
        
        const marker = window.L.marker([property.lat, property.lng], {
          icon: createMarkerIcon('property')
        }).addTo(window.map);
        
        // Contenuto del popup
        const popupContent = document.createElement('div');
        popupContent.className = 'text-center p-2';
        popupContent.innerHTML = `
          <h3 class="font-bold text-lg mb-1">${property.title}</h3>
          <p class="text-blue-600 font-semibold mb-2">${property.price}</p>
          <p class="text-sm text-gray-600 mb-2">${property.propertyType}, ${property.listingType}</p>
          <button class="bg-blue-600 text-white rounded-sm px-3 py-1.5 w-full font-medium hover:bg-blue-700">
            Visualizza Dettagli
          </button>
        `;
        
        // Aggiungi evento click al pulsante
        const button = popupContent.querySelector('button');
        if (button) {
          button.addEventListener('click', () => {
            onMarkerClick(property, 'property');
            marker.closePopup();
          });
        }
        
        marker.bindPopup(popupContent);
      });
    }
    
    // Aggiungi marker per i professionisti
    if (showProfessionals) {
      professionals.forEach(professional => {
        if (!professional.lat || !professional.lng) return;
        
        const marker = window.L.marker([professional.lat, professional.lng], {
          icon: createMarkerIcon('professional')
        }).addTo(window.map);
        
        // Traduci il tipo di professionista
        const profType = professional.type === 'architect' ? 'Architetto' : 
                       professional.type === 'notary' ? 'Notaio' : 
                       professional.type === 'artisan' ? 'Artigiano' : 
                       professional.type;
        
        // Contenuto del popup
        const popupContent = document.createElement('div');
        popupContent.className = 'text-center p-2';
        popupContent.innerHTML = `
          <h3 class="font-bold text-lg mb-1">${professional.name}</h3>
          <p class="text-green-600 font-semibold mb-2">${profType}</p>
          <button class="bg-green-600 text-white rounded-sm px-3 py-1.5 w-full font-medium hover:bg-green-700">
            Contatta
          </button>
        `;
        
        // Aggiungi evento click al pulsante
        const button = popupContent.querySelector('button');
        if (button) {
          button.addEventListener('click', () => {
            onMarkerClick(professional, 'professional');
            marker.closePopup();
          });
        }
        
        marker.bindPopup(popupContent);
      });
    }
    
    // Aggiungi marker per le banche
    if (showBanks) {
      banks.forEach(bank => {
        if (!bank.lat || !bank.lng) return;
        
        const marker = window.L.marker([bank.lat, bank.lng], {
          icon: createMarkerIcon('bank')
        }).addTo(window.map);
        
        // Contenuto del popup
        const popupContent = document.createElement('div');
        popupContent.className = 'text-center p-2';
        popupContent.innerHTML = `
          <h3 class="font-bold text-lg mb-1">${bank.name}</h3>
          <button class="bg-amber-500 text-white rounded-sm px-3 py-1.5 w-full font-medium hover:bg-amber-600">
            Contatta
          </button>
        `;
        
        // Aggiungi evento click al pulsante
        const button = popupContent.querySelector('button');
        if (button) {
          button.addEventListener('click', () => {
            onMarkerClick(bank, 'bank');
            marker.closePopup();
          });
        }
        
        marker.bindPopup(popupContent);
      });
    }
  };
  
  // Gestione dell'indirizzo trovato nella ricerca
  const handleAddressFound = (lat: number, lng: number, displayName: string) => {
    console.log("Indirizzo trovato:", lat, lng, displayName);
    
    if (window.map) {
      // Centra la mappa sulla posizione
      window.map.setView([lat, lng], 16);
      
      // Rimuovi eventuali vecchi marker di ricerca
      window.map.eachLayer((layer: any) => {
        if (layer instanceof window.L.Marker && layer.options.searchMarker) {
          window.map.removeLayer(layer);
        }
      });
      
      // Crea un marker speciale per l'indirizzo cercato
      const searchMarker = window.L.marker([lat, lng], {
        searchMarker: true,
        icon: window.L.divIcon({
          html: `<div class="w-6 h-6 rounded-full bg-red-500 border-2 border-white shadow-md flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="white" stroke-width="2">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
                    <circle cx="12" cy="10" r="3" />
                  </svg>
                </div>`,
          className: '',
          iconSize: [24, 24],
          iconAnchor: [12, 24]
        })
      }).addTo(window.map);
      
      // Aggiungi popup con info sull'indirizzo
      searchMarker.bindPopup(`
        <div class="p-2">
          <strong class="block mb-1">${displayName}</strong>
          <span class="text-sm text-gray-600">Indirizzo cercato</span>
        </div>
      `).openPopup();
    }
  };
  
  // Carica Leaflet dinamicamente quando il componente viene montato
  useEffect(() => {
    // Funzione per caricare Leaflet
    const loadLeaflet = () => {
      // Se Leaflet è già caricato, inizializza subito la mappa
      if (typeof window !== 'undefined' && window.L) {
        initializeMap();
        return;
      }
      
      // Carica il CSS di Leaflet se non è già presente
      if (!document.querySelector('link[href*="leaflet.css"]')) {
        const leafletCss = document.createElement('link');
        leafletCss.rel = 'stylesheet';
        leafletCss.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
        leafletCss.integrity = 'sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=';
        leafletCss.crossOrigin = '';
        document.head.appendChild(leafletCss);
      }
      
      // Carica il JS di Leaflet se non è già presente
      if (!window.L) {
        const leafletScript = document.createElement('script');
        leafletScript.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
        leafletScript.integrity = 'sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=';
        leafletScript.crossOrigin = '';
        document.head.appendChild(leafletScript);
        
        leafletScript.onload = () => {
          // Inizializza la mappa immediatamente dopo il caricamento di Leaflet
          initializeMap();
        };
      }
    };
    
    loadLeaflet();
    
    // Cleanup
    return () => {
      if (window.map) {
        window.map.remove();
        window.map = null;
      }
    };
  }, []);
  
  // Aggiorna i marker quando cambiano le proprietà o lo stato di visualizzazione
  useEffect(() => {
    if (mapReady && window.map) {
      updateMarkers();
    }
  }, [showProperties, showProfessionals, showBanks, properties, professionals, banks, mapReady]);
  
  return (
    <div className="flex flex-col h-full">
      {/* Controlli mappa */}
      <div className="p-2 bg-white border-b border-gray-200 flex flex-wrap justify-between items-center gap-2">
        {/* Ricerca indirizzo */}
        <div className="flex-1 min-w-[200px]">
          <AddressSearch onAddressFound={handleAddressFound} />
        </div>
        
        {/* Filtri marker */}
        <div className="flex items-center gap-3 flex-wrap">
          <label className="inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={showProperties}
              onChange={() => setShowProperties(!showProperties)}
              className="sr-only peer"
            />
            <div className="relative w-10 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
            <span className="ml-2 text-sm font-medium text-gray-700">Immobili</span>
          </label>
          
          <label className="inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={showProfessionals}
              onChange={() => setShowProfessionals(!showProfessionals)}
              className="sr-only peer"
            />
            <div className="relative w-10 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-green-600"></div>
            <span className="ml-2 text-sm font-medium text-gray-700">Professionisti</span>
          </label>
          
          <label className="inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={showBanks}
              onChange={() => setShowBanks(!showBanks)}
              className="sr-only peer"
            />
            <div className="relative w-10 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
            <span className="ml-2 text-sm font-medium text-gray-700">Banche</span>
          </label>
        </div>
      </div>
      
      {/* Container mappa */}
      <div className="flex-1 relative">
        {!mapReady && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-100 z-10">
            <div className="text-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
              <p className="mt-2 text-sm text-gray-600">Caricamento mappa...</p>
            </div>
          </div>
        )}
        <div ref={mapRef} className="h-full w-full" id="map"></div>
      </div>
    </div>
  );
};

export default MapComponent;