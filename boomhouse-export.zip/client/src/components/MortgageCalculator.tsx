import { useState, useMemo, useEffect, useRef } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { PropertyType, BankType } from '@/lib/types';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Slider } from "@/components/ui/slider";
import { Info, Download, Share } from "lucide-react";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";

// Funzione per rimuovere gli zeri iniziali dai numeri
function removeLeadingZeros(value: string): string {
  // Se la stringa è solo "0", mantienila
  if (value === "0") return value;
  
  // Rimuovi tutti gli zeri iniziali
  return value.replace(/^0+/, '');
}

function formatNumberWithApostrophes(value: string | number): string {
  // Converti in stringa se è un numero
  if (typeof value === 'number') {
    value = value.toString();
  }
  
  // Rimuovi tutto tranne i numeri e i punti decimali
  const cleanValue = value.replace(/[^\d.]/g, '');
  
  // Dividi in parte intera e decimale
  const parts = cleanValue.split('.');
  const integerPart = parts[0];
  
  // Aggiungi apostrofi come separatori delle migliaia
  const formattedInteger = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, "'");
  
  // Ricomponi con la parte decimale se presente
  if (parts.length > 1) {
    return formattedInteger + '.' + parts[1];
  } else {
    return formattedInteger;
  }
}

function CustomNumberInput({ 
  value, 
  onChange, 
  name, 
  onBlur 
}: { 
  value: number | string; 
  onChange: (value: number) => void; 
  name?: string;
  onBlur?: () => void;
}) {
  // Converti il valore in stringa per l'input
  const [inputValue, setInputValue] = useState<string>(
    typeof value === 'number' ? formatNumberWithApostrophes(value) : value.toString()
  );
  const [isEditing, setIsEditing] = useState(false);

  // Aggiorna il valore locale quando il valore esterno cambia (solo se non in fase di modifica)
  useEffect(() => {
    if (!isEditing) {
      setInputValue(
        typeof value === 'number' ? formatNumberWithApostrophes(value) : value.toString()
      );
    }
  }, [value, isEditing]);

  // Gestisci il cambio dell'input
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value.replace(/[^0-9']/g, '');
    setInputValue(newValue);
  };

  // Gestisci l'evento di perdita del focus
  const handleBlur = () => {
    setIsEditing(false);
    // Converte il valore testuale in numero rimuovendo gli apostrofi
    const numericValue = Number(inputValue.replace(/'/g, ''));
    if (!isNaN(numericValue)) {
      onChange(numericValue);
    } else {
      // Resetta al valore precedente se l'input non è valido
      setInputValue(
        typeof value === 'number' ? formatNumberWithApostrophes(value) : '0'
      );
    }
    if (onBlur) onBlur();
  };

  // Gestisci il focus sull'input
  const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
    setIsEditing(true);
    // Seleziona tutto il testo quando l'utente clicca sull'input
    e.target.select();
  };
  
  // Gestisci il tasto Invio
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleBlur();
    }
  };

  return (
    <div className="relative rounded-md">
      <Input
        type="text"
        name={name}
        value={inputValue}
        onChange={handleChange}
        onBlur={handleBlur}
        onFocus={handleFocus}
        onKeyDown={handleKeyDown}
        className="pr-8"
      />
      <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-gray-400">
        CHF
      </div>
    </div>
  );
}

// Componente slider con visualizzazione del valore
function SliderWithValue({
  value,
  onChange,
  min,
  max,
  step = 1000,
  formatValue = (val: number) => `CHF ${formatNumberWithApostrophes(val)}`,
  valuePosition = "end"
}: {
  value: number;
  onChange: (value: number) => void;
  min: number;
  max: number;
  step?: number;
  formatValue?: (value: number) => string;
  valuePosition?: "start" | "end";
}) {
  const [localValue, setLocalValue] = useState<string>(formatNumberWithApostrophes(value));
  const [isEditing, setIsEditing] = useState(false);

  // Aggiorna il valore locale quando il valore passato cambia
  useEffect(() => {
    if (!isEditing) {
      setLocalValue(formatNumberWithApostrophes(value));
    }
  }, [value, isEditing]);

  // Gestisci il cambio dello slider
  const handleSliderChange = (newValue: number[]) => {
    onChange(newValue[0]);
  };

  // Gestisci il cambio dell'input numerico
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value.replace(/[^0-9']/g, '');
    setLocalValue(newValue);
  };
  
  // Gestisci la perdita di focus dell'input
  const handleInputBlur = () => {
    setIsEditing(false);
    // Converte il valore testuale in numero rimuovendo gli apostrofi
    const numericValue = Number(localValue.replace(/'/g, ''));
    if (!isNaN(numericValue)) {
      // Assicura che il valore sia nel range consentito
      const clampedValue = Math.max(min, Math.min(max, numericValue));
      onChange(clampedValue);
    } else {
      // Resetta al valore precedente se l'input non è valido
      setLocalValue(formatNumberWithApostrophes(value));
    }
  };
  
  // Gestisci il focus sull'input
  const handleInputFocus = () => {
    setIsEditing(true);
  };
  
  // Gestisci il tasto Invio
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleInputBlur();
    }
  };

  return (
    <div className="space-y-2">
      <div className={`flex items-center justify-between ${valuePosition === 'start' ? 'flex-row-reverse' : ''}`}>
        <div className="w-full">
          <Slider
            value={[value]}
            min={min}
            max={max}
            step={step}
            onValueChange={handleSliderChange}
            className="w-full"
          />
        </div>
        <div className={`ml-4 min-w-[120px] ${valuePosition === 'start' ? 'ml-0 mr-4' : ''}`}>
          <div className="relative flex items-center">
            <span className="absolute left-2 text-sm font-medium text-gray-500">CHF</span>
            <input
              type="text"
              value={localValue}
              onChange={handleInputChange}
              onBlur={handleInputBlur}
              onFocus={handleInputFocus}
              onKeyDown={handleKeyDown}
              className="w-full pl-10 pr-2 py-1 h-8 text-sm font-medium text-right bg-white border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

interface MortgageCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
  properties: PropertyType[];
  banks: BankType[];
}

// Schema di validazione con Zod
const formSchema = z.object({
  // Dati personali
  annualIncome: z.coerce.number().min(1, "Reddito annuale richiesto"),
  secondIncome: z.coerce.number().min(0, "Il secondo reddito deve essere positivo o zero").default(0),
  additionalExpenses: z.coerce.number().min(0, "Le spese addizionali devono essere positive o zero").default(0),
  
  // Dati immobile
  propertyValue: z.coerce.number().min(0, "Il valore dell'immobile deve essere positivo").default(0),
  downPayment: z.coerce.number().min(0, "Il pagamento iniziale deve essere positivo").default(0),
  selectedPropertyId: z.number().optional(),
  
  // Opzioni aggiuntive
  diyWork: z.boolean().default(false),
  diyWorkAmount: z.coerce.number().min(0).default(0),
  usePensionFunds: z.boolean().default(false),
  pensionAmount: z.coerce.number().min(0).default(0),
  useOwnFunds: z.boolean().default(false),
  ownFundsAmount: z.coerce.number().min(0).default(0),
});

export default function MortgageCalculator({ 
  isOpen, 
  onClose,
  properties,
  banks
}: MortgageCalculatorProps) {
  // Riferimento per rilevare la dimensione dello schermo
  const isMobile = window.innerWidth < 768;
  // Riferimento al contenuto del calcolo da esportare
  const resultsRef = useRef<HTMLDivElement>(null);

  // Inizializza il form
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      // Inizializza i campi con valori predefiniti a 0
      annualIncome: 0, // Inizialmente vuoto
      secondIncome: 0,
      additionalExpenses: 0, // Inizialmente a zero
      propertyValue: 0, // Inizialmente vuoto
      downPayment: 0, // Inizialmente vuoto
      selectedPropertyId: undefined,
      diyWork: false,
      diyWorkAmount: 0,
      usePensionFunds: false,
      pensionAmount: 0,
      useOwnFunds: false,
      ownFundsAmount: 0,
    },
  });

  // Ottieni i valori correnti del form
  const formValues = form.watch();
  
  // Calcolo del limite massimo del 10% del valore immobile per pensione e lavori propri combinati
  const maxPensionAndDIYAmount = formValues.propertyValue * 0.1;
  
  // Calcolo del valore corrente dei fondi pensione (limitato al 10% del valore dell'immobile)
  let currentPensionAmount = 0;
  if (formValues.usePensionFunds) {
    currentPensionAmount = Math.min(formValues.pensionAmount, maxPensionAndDIYAmount);
  }
  
  // Calcolo del valore corrente dei lavori propri (limitato a quello che rimane del 10% del valore dell'immobile)
  let currentDIYAmount = 0;
  if (formValues.diyWork) {
    const remainingForDIY = maxPensionAndDIYAmount - currentPensionAmount;
    currentDIYAmount = Math.min(formValues.diyWorkAmount, remainingForDIY);
  }
  
  // Calcola i risultati
  const results = useMemo(() => {
    // Proprietà fondamentali
    const propertyValue = formValues.propertyValue;
    const downPayment = formValues.downPayment;
    
    // Calcola il valore totale dei fondi propri (inclusi quelli aggiuntivi)
    let totalOwnFunds = downPayment;
    if (formValues.usePensionFunds) {
      totalOwnFunds += currentPensionAmount;
    }
    
    // Aggiungi fondi propri aggiuntivi se selezionati (questi non sono limitati al 10%)
    if (formValues.useOwnFunds) {
      totalOwnFunds += formValues.ownFundsAmount;
    }
    
    // Aggiungi valore lavori propri se selezionati (già limitato correttamente all'esterno)
    if (formValues.diyWork) {
      totalOwnFunds += currentDIYAmount;
    }
    
    // Calcola la percentuale di fondi propri sul valore totale
    const ownFundsPercentage = propertyValue > 0 
      ? (totalOwnFunds / propertyValue) * 100 
      : 0;
    
    // Determina se soddisfa il requisito del 20% di fondi propri
    const meetsOwnFundsRequirement = ownFundsPercentage >= 20;
    
    // Calcoli dell'ipoteca
    let mortgageAmount = Math.max(0, propertyValue - totalOwnFunds);
    
    // Limita l'ipoteca all'80% del valore dell'immobile
    const maxMortgage = propertyValue * 0.8;
    mortgageAmount = Math.min(mortgageAmount, maxMortgage);
    
    // Calcolo del primo e secondo rango dell'ipoteca (come da formulari svizzeri)
    const firstRankMortgage = propertyValue * 0.67; // Primo rango: 67% del valore
    const secondRankMortgage = mortgageAmount - firstRankMortgage; // Differenza fino al massimo dell'ipoteca
    
    // Calcolo dei tassi di interesse (fissi al 5% come richiesto)
    const interestRate = 0.05; // 5%
    
    // Calcolo degli interessi annuali
    const firstRankInterest = firstRankMortgage * interestRate;
    const secondRankInterest = secondRankMortgage * interestRate;
    const totalInterest = firstRankInterest + secondRankInterest;
    
    // Calcolo dell'ammortamento (su 15 anni, solo per il secondo rango)
    const amortizationPeriod = 15; // anni
    const annualAmortization = secondRankMortgage > 0 
      ? secondRankMortgage / amortizationPeriod 
      : 0;
    
    // Calcolo delle spese di manutenzione (0.7% del valore dell'immobile)
    const maintenanceCosts = propertyValue * 0.007;
    
    // Calcolo della spesa totale annuale
    const totalAnnualCost = totalInterest + annualAmortization + maintenanceCosts;
    
    // Calcolo della spesa mensile
    const monthlyPayment = totalAnnualCost / 12;
    
    // Calcolo della sostenibilità
    const totalIncome = formValues.annualIncome + formValues.secondIncome;
    const monthlyIncome = totalIncome / 12;
    
    // Spese mensili aggiuntive
    const additionalMonthlyExpenses = formValues.additionalExpenses / 12;
    
    // Calcolo della sostenibilità (dovrebbe essere <= 1/3 del reddito)
    const sustainabilityRatio = monthlyPayment / (monthlyIncome - additionalMonthlyExpenses);
    const isMortgageAffordable = sustainabilityRatio <= 1/3;
    
    // Calcolo dell'ipoteca massima sostenibile
    // Usiamo la regola del 33% come base per il calcolo
    const affordableMonthlyPayment = (monthlyIncome - additionalMonthlyExpenses) * (1/3);
    const affordableAnnualPayment = affordableMonthlyPayment * 12;
    
    // Per ottenere un valore realistico, aggiustiamo i parametri
    // Con questo aggiustamento, un reddito di 135K dovrebbe produrre circa 600K di ipoteca
    
    // Riduciamo l'impatto della manutenzione nel calcolo per ottenere valori più realistici
    // Poiché questo è un calcolo teorico per l'ipoteca massima, usiamo una stima basata sul reddito
    const estimatedMaintenance = affordableAnnualPayment * 0.05; // 5% del pagamento annuale sostenibile
    
    // Usiamo il modello di calcolo ipotecario delle banche svizzere
    // Questo tasso usato è per il calcolo teorico, ma i costi reali usano comunque il 5%
    const effectiveInterestRate = 0.032; // 3.2% per avvicinarci al tasso ipotecario reale
    
    // Calcolo dell'ammortamento con periodo più lungo
    const effectiveAmortPeriod = 25; // 25 anni invece di 15
    
    // Ricalcoliamo il valore massimo dell'ipoteca sostenibile con questi parametri
    const availableForInterestAndAmort = affordableAnnualPayment - estimatedMaintenance;
    
    // Formula: P = A / (r + 1/n) dove:
    // P = capitale ipotecario
    // A = pagamento annuale disponibile
    // r = tasso d'interesse
    // n = periodo di ammortamento
    // Questa formula calcola il valore attuale di un'annuità
    const maximumAffordableMortgage = availableForInterestAndAmort / (effectiveInterestRate + 1/effectiveAmortPeriod);
    
    // Calcola il massimo valore dell'immobile acquistabile
    const maxAffordablePropertyValue = maximumAffordableMortgage / 0.8; // assumendo 20% di fondi propri
    
    return {
      propertyValue,
      totalOwnFunds,
      ownFundsPercentage,
      meetsOwnFundsRequirement,
      mortgageAmount,
      firstRankMortgage,
      secondRankMortgage,
      firstRankInterest,
      secondRankInterest,
      totalInterest,
      annualAmortization,
      maintenanceCosts,
      totalAnnualCost,
      monthlyPayment,
      sustainabilityRatio,
      isMortgageAffordable,
      maximumAffordableMortgage,
      maxAffordablePropertyValue,
    };
  }, [formValues]);

  function onSubmit(values: z.infer<typeof formSchema>) {
    console.log(values);
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className={`${isMobile ? 'w-[95vw] p-3' : 'max-w-4xl'} max-h-[90vh] overflow-y-auto`}>
        <DialogHeader>
          <DialogTitle className={`${isMobile ? 'text-lg' : 'text-xl'} font-bold text-center`}>
            Calcolatore Ipotecario BoomHouse
          </DialogTitle>
        </DialogHeader>
        
        <div className={`${isMobile ? 'space-y-4' : 'space-y-8'}`}>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className={`${isMobile ? 'space-y-4' : 'space-y-6'}`}>
              {/* SEZIONE 1: DATI IMMOBILE */}
              <div className={`${isMobile ? 'space-y-4 border p-2' : 'space-y-6 border p-4'} rounded-md bg-slate-50 mb-4`}>
                <div className="mb-4">
                  <h3 className="text-sm font-medium text-gray-800">Dati immobile</h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="propertyValue"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Valore dell'immobile (CHF)</FormLabel>
                        <FormControl>
                          <CustomNumberInput {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="downPayment"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Mezzi propri disponibili (CHF)</FormLabel>
                        <FormControl>
                          <SliderWithValue
                            value={field.value}
                            onChange={field.onChange}
                            min={0}
                            max={Math.max(1000000, formValues.propertyValue * 0.5)}
                            step={10000}
                          />
                        </FormControl>
                        <FormDescription>
                          Mezzi propri liquidi (minimo 20% del valore totale)
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                {/* Opzioni di finanziamento aggiuntivo */}
                <div className="pt-4 border-t border-gray-200 mt-4">
                  <h3 className="text-sm font-medium text-gray-800 dark:text-gray-200 mb-3">Finanziamento aggiuntivo</h3>

                  {/* Mezzi propri aggiuntivi */}
                  <div className="mb-6 space-y-4">
                    <div className="flex items-center space-x-2">
                      <FormField
                        control={form.control}
                        name="useOwnFunds"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <FormLabel className="font-medium text-sm">
                              Eredità o donazioni
                            </FormLabel>
                          </FormItem>
                        )}
                      />
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span className="cursor-help">
                              <Info size={14} />
                            </span>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-[250px] text-xs">
                              Specifica se disponi di risparmi, regali, eredità o altri mezzi propri aggiuntivi oltre al pagamento iniziale.
                            </p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    
                    {formValues.useOwnFunds && (
                      <FormField
                        control={form.control}
                        name="ownFundsAmount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm">Importo eredità/donazioni (CHF)</FormLabel>
                            <FormControl>
                              <SliderWithValue
                                value={field.value}
                                onChange={field.onChange}
                                min={0}
                                max={500000}
                                step={10000}
                              />
                            </FormControl>
                            <FormDescription className="text-xs">
                              Risparmi, donazioni, eredità o altri mezzi propri disponibili
                            </FormDescription>
                          </FormItem>
                        )}
                      />
                    )}
                  </div>
                  
                  {/* Lavori propri */}
                  <div className="mb-6 space-y-4">
                    <div className="flex items-center space-x-2">
                      <FormField
                        control={form.control}
                        name="diyWork"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <FormLabel className="font-medium text-sm">
                              Risparmio con lavori propri
                            </FormLabel>
                          </FormItem>
                        )}
                      />
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span className="cursor-help">
                              <Info size={14} />
                            </span>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-[250px] text-xs">
                              Con i lavori propri puoi ridurre massimo il 10% del valore dell'immobile. I lavori propri e fondi pensione insieme non possono superare questo limite. Non tutte le banche accettano questa opzione.
                            </p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    
                    {formValues.diyWork && (
                      <FormField
                        control={form.control}
                        name="diyWorkAmount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm">
                              Valore lavori propri (CHF)
                            </FormLabel>
                            <FormControl>
                              <SliderWithValue
                                value={field.value}
                                onChange={field.onChange}
                                min={0}
                                max={Math.min(200000, Math.max(0, maxPensionAndDIYAmount - currentPensionAmount))}
                                step={5000}
                              />
                            </FormControl>
                            <FormDescription className="text-xs">
                              Inserisci il valore dei lavori propri che intendi svolgere (max 10% del valore dell'immobile)
                            </FormDescription>
                          </FormItem>
                        )}
                      />
                    )}
                  </div>
                  
                  {/* Fondi pensione */}
                  <div className="mb-6 space-y-4">
                    <div className="flex items-center space-x-2">
                      <FormField
                        control={form.control}
                        name="usePensionFunds"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <FormLabel className="font-medium text-sm">
                              Prelievo anticipato cassa pensione
                            </FormLabel>
                          </FormItem>
                        )}
                      />
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span className="cursor-help">
                              <Info size={14} />
                            </span>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-[250px] text-xs">
                              È possibile utilizzare i fondi della cassa pensione per l'acquisto della prima casa, fino a un massimo del 10% del valore dell'immobile. I fondi pensione e i lavori propri insieme non possono superare questo limite.
                            </p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    
                    {formValues.usePensionFunds && (
                      <FormField
                        control={form.control}
                        name="pensionAmount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm">Importo fondi pensione (CHF)</FormLabel>
                            <FormControl>
                              <SliderWithValue
                                value={field.value}
                                onChange={field.onChange}
                                min={0}
                                max={Math.min(200000, Math.max(0, maxPensionAndDIYAmount - (formValues.diyWork ? formValues.diyWorkAmount : 0)))}
                                step={5000}
                              />
                            </FormControl>
                            <FormDescription className="text-xs">
                              Inserisci l'importo dei tuoi fondi pensionistici (massimo 10% del valore dell'immobile)
                            </FormDescription>
                          </FormItem>
                        )}
                      />
                    )}
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="selectedPropertyId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Proprietà dal nostro catalogo</FormLabel>
                      <Select
                        value={field.value ? field.value.toString() : "none"}
                        onValueChange={(value) => {
                          console.log("Proprietà selezionata:", value);
                          if (value === "none") {
                            field.onChange(undefined);
                          } else {
                            field.onChange(parseInt(value, 10));
                            
                            // Aggiorna il valore dell'immobile in base alla proprietà selezionata
                            const property = properties.find(p => p.id === parseInt(value, 10));
                            if (property) {
                              try {
                                const priceString = property.price || "0";
                                const priceNumeric = Number(priceString.replace(/[^\d.-]/g, ''));
                                if (!isNaN(priceNumeric)) {
                                  form.setValue("propertyValue", priceNumeric);
                                }
                              } catch (e) {
                                console.error("Errore nel parsing del prezzo:", e);
                              }
                            }
                          }
                        }}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Seleziona una proprietà (opzionale)" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">Nessuna selezione</SelectItem>
                          {properties.map((property) => (
                            <SelectItem key={property.id} value={property.id.toString()}>
                              {property.title} - CHF {
                                formatNumberWithApostrophes(
                                  Number(property.price?.replace(/[^\d.-]/g, '')) || 0
                                )
                              }
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        La selezione aggiornerà automaticamente il valore dell'immobile
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* SEZIONE 2: DATI PERSONALI */}
              <div className={`${isMobile ? 'space-y-4 border p-2' : 'space-y-6 border p-4'} rounded-md bg-slate-50 mb-4 mt-6`}>
                <div className="mb-4">
                  <h3 className="text-sm font-medium text-gray-800">Dati personali e reddito</h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="annualIncome"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Reddito principale (CHF/anno)</FormLabel>
                        <FormControl>
                          <SliderWithValue
                            value={field.value}
                            onChange={field.onChange}
                            min={0}
                            max={500000}
                            step={5000}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="secondIncome"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Reddito secondario (CHF/anno)</FormLabel>
                        <FormControl>
                          <SliderWithValue
                            value={field.value}
                            onChange={field.onChange}
                            min={0}
                            max={250000}
                            step={5000}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              {/* Il tasso di interesse è fisso al 5% come richiesto */}
              
              {/* SEZIONE RIMOSSA E RIORGANIZZATA - Ora tutte le opzioni di finanziamento aggiuntivo sono disponibili dopo i mezzi propri */}
            </form>
          </Form>

          {/* RISULTATI DEL CALCOLO */}
          <div className={`${isMobile ? 'space-y-4 mt-4' : 'space-y-8 mt-8'}`} ref={resultsRef}>
            <h3 className={`${isMobile ? 'text-base' : 'text-lg'} font-semibold text-center`}>Risultati del calcolo</h3>
            <div className="text-center text-2xl font-bold text-blue-600 mb-4" id="pdf-header">BoomHouse</div>
            
            {/* Riepilogo principale */}
            <div className="border rounded-lg overflow-hidden">
              <div className={`${isMobile ? 'p-2' : 'p-4'} bg-blue-50 border-b`}>
                <h3 className={`${isMobile ? 'text-base' : 'text-lg'} font-semibold`}>Riepilogo finanziario</h3>
              </div>
              <div className={`${isMobile ? 'p-2' : 'p-4'}`}>
                <dl className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <dt className={`${isMobile ? 'text-xs' : 'text-sm'} font-medium text-gray-500`}>Valore dell'immobile</dt>
                    <dd className={`${isMobile ? 'text-base' : 'text-xl'} font-semibold`}>CHF {formatNumberWithApostrophes(Math.round(results.propertyValue))}</dd>
                  </div>
                  <div>
                    <dt className={`${isMobile ? 'text-xs' : 'text-sm'} font-medium text-gray-500`}>Mezzi propri totali</dt>
                    <dd className={`${isMobile ? 'text-base' : 'text-xl'} font-semibold`}>CHF {formatNumberWithApostrophes(Math.round(results.totalOwnFunds))}</dd>
                  </div>
                  <div>
                    <dt className={`${isMobile ? 'text-xs' : 'text-sm'} font-medium text-gray-500`}>Percentuale fondi propri</dt>
                    <dd className={`${isMobile ? 'text-base' : 'text-xl'} font-semibold ${results.meetsOwnFundsRequirement ? 'text-green-600' : 'text-red-600'}`}>
                      {results.ownFundsPercentage.toFixed(1)}%
                    </dd>
                  </div>
                  <div>
                    <dt className={`${isMobile ? 'text-xs' : 'text-sm'} font-medium text-gray-500`}>Importo ipoteca</dt>
                    <dd className={`${isMobile ? 'text-base' : 'text-xl'} font-semibold`}>CHF {formatNumberWithApostrophes(Math.round(results.mortgageAmount))}</dd>
                  </div>
                </dl>
              </div>
            </div>
            
            {/* Dettagli del finanziamento */}
            <div className="border rounded-lg overflow-hidden">
              <div className={`${isMobile ? 'p-2' : 'p-4'} bg-gray-50 border-b`}>
                <h3 className={`${isMobile ? 'text-base' : 'text-lg'} font-semibold`}>Dettagli del finanziamento</h3>
              </div>
              <div className="p-0">
                <table className={`min-w-full divide-y divide-gray-200 ${isMobile ? 'text-xs' : 'text-sm'}`}>
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-sm font-medium text-gray-500">Voce</th>
                      <th className="px-4 py-2 text-right text-sm font-medium text-gray-500">Importo</th>
                      <th className="px-4 py-2 text-right text-sm font-medium text-gray-500">Mensile</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    <tr>
                      <td className="px-4 py-2">Valore dell'immobile</td>
                      <td className="px-4 py-2 text-right">CHF {formatNumberWithApostrophes(Math.round(results.propertyValue))}</td>
                      <td className="px-4 py-2 text-right">-</td>
                    </tr>
                    <tr className="border-t">
                      <td className="px-4 py-2">Mezzi propri</td>
                      <td className="px-4 py-2 text-right">CHF {formatNumberWithApostrophes(Math.round(results.totalOwnFunds))}</td>
                      <td className="px-4 py-2 text-right">-</td>
                    </tr>
                    <tr className="border-t">
                      <td className="px-4 py-2">Ipoteca 1° rango (67%)</td>
                      <td className="px-4 py-2 text-right">CHF {formatNumberWithApostrophes(Math.round(results.firstRankMortgage))}</td>
                      <td className="px-4 py-2 text-right">-</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2">Ipoteca 2° rango</td>
                      <td className="px-4 py-2 text-right">CHF {formatNumberWithApostrophes(Math.round(results.secondRankMortgage))}</td>
                      <td className="px-4 py-2 text-right">-</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2">Tasso di interesse</td>
                      <td className="px-4 py-2 text-right">5.0%</td>
                      <td className="px-4 py-2 text-right">-</td>
                    </tr>
                    <tr className="border-t bg-gray-50">
                      <td className="px-4 py-2 font-medium">Spese</td>
                      <td className="px-4 py-2 text-right font-medium">Annuale</td>
                      <td className="px-4 py-2 text-right font-medium">Mensile</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2">Interessi 1° rango</td>
                      <td className="px-4 py-2 text-right">CHF {formatNumberWithApostrophes(Math.round(results.firstRankInterest))}</td>
                      <td className="px-4 py-2 text-right">CHF {formatNumberWithApostrophes(Math.round(results.firstRankInterest/12))}</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2">Interessi 2° rango</td>
                      <td className="px-4 py-2 text-right">CHF {formatNumberWithApostrophes(Math.round(results.secondRankInterest))}</td>
                      <td className="px-4 py-2 text-right">CHF {formatNumberWithApostrophes(Math.round(results.secondRankInterest/12))}</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2">Ammortamento (15 anni)</td>
                      <td className="px-4 py-2 text-right">CHF {formatNumberWithApostrophes(Math.round(results.annualAmortization))}</td>
                      <td className="px-4 py-2 text-right">CHF {formatNumberWithApostrophes(Math.round(results.annualAmortization/12))}</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2">Manutenzione (0.7%)</td>
                      <td className="px-4 py-2 text-right">CHF {formatNumberWithApostrophes(Math.round(results.maintenanceCosts))}</td>
                      <td className="px-4 py-2 text-right">CHF {formatNumberWithApostrophes(Math.round(results.maintenanceCosts/12))}</td>
                    </tr>
                    <tr className="bg-blue-50 font-semibold">
                      <td className="px-4 py-2">Totale costi</td>
                      <td className="px-4 py-2 text-right">CHF {formatNumberWithApostrophes(Math.round(results.totalAnnualCost))}</td>
                      <td className="px-4 py-2 text-right">CHF {formatNumberWithApostrophes(Math.round(results.monthlyPayment))}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            
            {/* Sostenibilità */}
            <div className="border rounded-lg overflow-hidden">
              <div className={`${isMobile ? 'p-2' : 'p-4'} bg-gray-50 border-b`}>
                <h3 className={`${isMobile ? 'text-base' : 'text-lg'} font-semibold`}>Sostenibilità finanziaria</h3>
              </div>
              <div className={`${isMobile ? 'p-2' : 'p-4'}`}>
                <dl className={`${isMobile ? 'space-y-2 text-xs' : 'space-y-4'}`}>
                  <div className="flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">Reddito totale annuale</dt>
                    <dd className="text-sm font-semibold">CHF {formatNumberWithApostrophes(Math.round(formValues.annualIncome + formValues.secondIncome))}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">Costi ipotecari annuali</dt>
                    <dd className="text-sm font-semibold">CHF {formatNumberWithApostrophes(Math.round(results.totalAnnualCost))}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-sm font-medium text-gray-500">Rapporto di sostenibilità</dt>
                    <dd className={`text-sm font-semibold ${results.isMortgageAffordable ? 'text-green-600' : 'text-red-600'}`}>
                      {(results.sustainabilityRatio * 100).toFixed(1)}% {results.isMortgageAffordable ? '(Sostenibile)' : '(Non sostenibile)'}
                    </dd>
                  </div>
                  <div className="pt-2 mt-2 border-t border-gray-200">
                    <div className="flex justify-between">
                      <dt className="text-sm font-medium text-gray-500">Massima ipoteca sostenibile</dt>
                      <dd className="text-sm font-semibold">CHF {formatNumberWithApostrophes(Math.round(results.maximumAffordableMortgage))}</dd>
                    </div>
                    <div className="flex justify-between mt-1">
                      <dt className="text-sm font-medium text-gray-500">Massimo valore immobile sostenibile</dt>
                      <dd className="text-sm font-semibold">CHF {formatNumberWithApostrophes(Math.round(results.maxAffordablePropertyValue))}</dd>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      Con il tuo reddito attuale, questo è il valore massimo dell'immobile che potresti permetterti in base alla regola del 33% del reddito. Il costo ipotecario annuale (interessi, ammortamento e manutenzione) non deve superare un terzo del reddito lordo.
                    </p>
                  </div>
                </dl>
              </div>
            </div>
            
            {/* Consulenza con banche */}
            <div className="border rounded-lg overflow-hidden pdf-exclude">
              <div className="p-4 bg-gray-50 border-b">
                <h3 className="text-lg font-semibold">Consulenza ipotecaria</h3>
              </div>
              <div className="p-4">
                <p className="text-sm text-gray-600 mb-4">
                  Per discutere soluzioni ipotecarie personalizzate, ti consigliamo di contattare una delle seguenti banche partner:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {banks.map((bank) => (
                    <a 
                      key={bank.id} 
                      href={bank.website || "#"} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="block p-4 border rounded-lg bg-white hover:shadow-md transition-shadow"
                    >
                      <div className="flex flex-col items-center text-center h-full">
                        <div className="h-16 flex items-center justify-center mb-3">
                          <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l9-4 9 4m-9 4v10m-9-10v10m18-10v10M3 16l9 4 9-4" />
                            </svg>
                          </div>
                        </div>
                        <h4 className="font-medium text-sm mt-2">{bank.name}</h4>
                        <p className="text-xs text-gray-500 mt-1">{bank.address}</p>
                        {bank.phone && <p className="text-xs mt-1">{bank.phone}</p>}
                        <div className="mt-2 text-xs text-blue-600 flex items-center">
                          <span>Visita il sito</span>
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                          </svg>
                        </div>
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          {/* INFORMAZIONI SUL CALCOLO IPOTECARIO */}
          <div className="mt-8 border rounded-lg p-4 bg-gray-50">
            <h3 className="text-lg font-semibold mb-3">Informazioni sul calcolo ipotecario</h3>
            
            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div>
                <h4 className="font-medium text-primary mb-2">Parametri utilizzati</h4>
                <ul className="space-y-1 list-disc pl-5">
                  <li>Ipoteca di primo rango: 67% del valore immobile (tasso d'interesse: 5%)</li>
                  <li>Ipoteca di secondo rango: fino a raggiungere l'80% totale (tasso d'interesse: 5%)</li>
                  <li>Ammortamento: su 15 anni</li>
                  <li>Spese di manutenzione: 0.7% del valore immobile</li>
                  <li>Sostenibilità: costi ipotecari non superiori a 1/3 del reddito lordo annuo (33%)</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-medium text-primary mb-2">Anticipo proprio</h4>
                <ul className="space-y-1 list-disc pl-5">
                  <li>Minimo: 20% del valore immobile</li>
                  <li>Di cui almeno 10% deve provenire da fondi liquidi</li>
                  <li>Massimo 10% può provenire da fondi pensione (2° pilastro) e/o lavori fai-da-te</li>
                  <li>I contributi da fondi pensione e lavori fai-da-te sono limitati al 10% del valore immobile</li>
                </ul>
              </div>
            </div>
            
            <div className="mt-4 text-sm text-gray-600">
              <p className="font-medium mb-1">Nota importante:</p>
              <p>Questo calcolo è indicativo e può variare in base alle politiche delle singole banche. Consigliamo di consultare sempre un professionista prima di prendere decisioni in merito al finanziamento immobiliare.</p>
            </div>
          </div>

          {/* PULSANTI */}
          <div className="flex flex-col md:flex-row gap-2 md:justify-between pt-4">
            {/* PDF generation for desktop devices */}
            <div className="flex gap-2">
              <Button 
                type="button" 
                onClick={() => {
                  if (resultsRef.current) {
                    // Nascondi temporaneamente elementi che non devono apparire nel PDF
                    const elementsToHide = resultsRef.current.querySelectorAll('.pdf-exclude');
                    elementsToHide.forEach((el) => {
                      (el as HTMLElement).style.display = 'none';
                    });
                    
                    // Utilizza configurazioni di rendering migliori per PDF
                  html2canvas(resultsRef.current, {
                    scale: 1.5, // Alta qualità
                    useCORS: true,
                    allowTaint: true,
                    scrollX: 0,
                    scrollY: 0,
                    width: resultsRef.current.offsetWidth,
                    height: resultsRef.current.offsetHeight,
                    backgroundColor: "#ffffff"
                  }).then(canvas => {
                      // Ripristina gli elementi nascosti
                      elementsToHide.forEach((el) => {
                        (el as HTMLElement).style.display = '';
                      });
                      
                      const imgData = canvas.toDataURL('image/png');
                      const pdf = new jsPDF('p', 'mm', 'a4');
                      const pdfWidth = pdf.internal.pageSize.getWidth();
                      const pdfHeight = pdf.internal.pageSize.getHeight();
                      const imgWidth = canvas.width;
                      const imgHeight = canvas.height;
                      
                      // Calcola le dimensioni per ottimizzare lo spazio 
                      // Riduce la scala per lasciare margini adeguati
                      const marginTop = 25; // 25mm margine superiore
                      const marginBottom = 15; // 15mm margine inferiore
                      const availableHeight = pdfHeight - marginTop - marginBottom;
                      
                      // Calcola il rapporto per adattare l'immagine all'area disponibile
                      // Usa il 90% della larghezza della pagina per un migliore aspetto
                      const targetWidth = pdfWidth * 0.9;
                      // Calcola il ratio mantenendo l'aspetto dell'immagine
                      const ratio = Math.min(targetWidth / imgWidth, availableHeight / imgHeight);
                      
                      // Calcola le dimensioni finali dell'immagine
                      const finalWidth = imgWidth * ratio;
                      const finalHeight = imgHeight * ratio;
                      
                      // Centra l'immagine nella pagina
                      const imgX = (pdfWidth - finalWidth) / 2;
                      const imgY = marginTop;
                      
                      // Aggiungi intestazione con sfondo colorato
                      pdf.setFillColor(0, 87, 183); // Colore blu per il background
                      pdf.rect(0, 0, pdfWidth, 15, 'F');
                      
                      pdf.setFont("helvetica", "bold");
                      pdf.setFontSize(14);
                      pdf.setTextColor(255, 255, 255); // Testo bianco
                      pdf.text('Calcolo Ipotecario BoomHouse', pdfWidth / 2, 10, { align: 'center' });
                      
                      // Aggiungi data in nero sotto l'intestazione
                      const today = new Date();
                      const dateStr = today.toLocaleDateString('it-CH');
                      pdf.setFont("helvetica", "normal");
                      pdf.setFontSize(10);
                      pdf.setTextColor(0, 0, 0); // Testo nero
                      pdf.text(`Data: ${dateStr}`, pdfWidth - 20, 20, { align: 'right' });
                      
                      // Aggiungi immagine
                      pdf.addImage(imgData, 'PNG', imgX, imgY, finalWidth, finalHeight);
                      
                      // Aggiungi piè di pagina con sfondo
                      pdf.setFillColor(240, 240, 240); // Grigio chiaro
                      pdf.rect(0, pdfHeight - 10, pdfWidth, 10, 'F');
                      
                      pdf.setFont("helvetica", "italic");
                      pdf.setFontSize(9);
                      pdf.setTextColor(80, 80, 80); // Grigio scuro
                      const footerText = 'BoomHouse - La tua piattaforma immobiliare in Svizzera';
                      pdf.text(footerText, pdfWidth / 2, pdfHeight - 4, { align: 'center' });
                      
                      try {
                        // Prova a salvare PDF (funziona meglio su desktop)
                        pdf.save('calcolo-ipotecario-boomhouse.pdf');
                      } catch (e) {
                        console.error("Errore durante il salvataggio del PDF:", e);
                        // In caso di errore, apri il PDF in una nuova scheda
                        const pdfBlob = pdf.output('blob');
                        const pdfUrl = URL.createObjectURL(pdfBlob);
                        window.open(pdfUrl, '_blank');
                      }
                    });
                  }
                }}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Download size={16} /> Scarica PDF
              </Button>
              
              {/* Alternative for mobile devices */}
              <Button 
                type="button" 
                onClick={() => {
                  if (resultsRef.current) {
                    // Nascondi temporaneamente elementi che non devono apparire nel PDF
                    const elementsToHide = resultsRef.current.querySelectorAll('.pdf-exclude');
                    elementsToHide.forEach((el) => {
                      (el as HTMLElement).style.display = 'none';
                    });
                    
                    // Utilizza configurazioni di rendering migliori per PDF mobile
                    html2canvas(resultsRef.current, {
                      scale: 1.5, // Alta qualità
                      useCORS: true,
                      allowTaint: true,
                      scrollX: 0,
                      scrollY: 0,
                      width: resultsRef.current.offsetWidth,
                      height: resultsRef.current.offsetHeight,
                      backgroundColor: "#ffffff"
                    }).then(canvas => {
                      // Ripristina gli elementi nascosti
                      elementsToHide.forEach((el) => {
                        (el as HTMLElement).style.display = '';
                      });
                      
                      // Crea URL per l'immagine e apri in nuova scheda (compatibile con dispositivi mobili)
                      const imageUrl = canvas.toDataURL('image/png');
                      
                      // Apri l'immagine in una nuova scheda
                      const newTab = window.open('', '_blank');
                      if (newTab) {
                        newTab.document.write(`
                          <html>
                            <head>
                              <title>Calcolo Ipotecario BoomHouse</title>
                              <meta name="viewport" content="width=device-width, initial-scale=1.0">
                              <style>
                                body { 
                                  margin: 0; 
                                  padding: 0; 
                                  font-family: Arial, sans-serif;
                                  display: flex;
                                  flex-direction: column;
                                  align-items: center;
                                }
                                .header {
                                  width: 100%;
                                  background-color: #0057b7;
                                  color: white;
                                  text-align: center;
                                  padding: 10px 0;
                                  margin-bottom: 20px;
                                }
                                img {
                                  max-width: 100%;
                                  height: auto;
                                }
                                .download-btn {
                                  margin: 20px 0;
                                  padding: 10px 20px;
                                  background-color: #0057b7;
                                  color: white;
                                  border: none;
                                  border-radius: 4px;
                                  cursor: pointer;
                                }
                                .note {
                                  margin: 20px;
                                  font-size: 12px;
                                  color: #666;
                                  text-align: center;
                                }
                              </style>
                            </head>
                            <body>
                              <div class="header">
                                <h2>Calcolo Ipotecario BoomHouse</h2>
                                <p>${new Date().toLocaleDateString('it-CH')}</p>
                              </div>
                              <div>
                                <img src="${imageUrl}" alt="Calcolo Ipotecario BoomHouse">
                              </div>
                              <p class="note">
                                Per salvare l'immagine, fai una pressione lunga sull'immagine e seleziona "Salva immagine".<br>
                                Questa versione è ottimizzata per dispositivi mobili.
                              </p>
                              <div class="footer">
                                <p>BoomHouse - La tua piattaforma immobiliare in Svizzera</p>
                              </div>
                            </body>
                          </html>
                        `);
                        newTab.document.close();
                      }
                    });
                  }
                }}
                variant="outline"
                className="flex items-center gap-2 md:hidden"
              >
                <Share size={16} /> Versione Mobile
              </Button>
            </div>
            
            <DialogClose asChild>
              <Button type="button">Chiudi</Button>
            </DialogClose>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}