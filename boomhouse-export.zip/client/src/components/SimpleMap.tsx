import React, { useEffect, useRef, useState } from 'react';
import { PropertyType, ProfessionalType, BankType, ListingType } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from "@/components/ui/tooltip";
import { useMobile } from '@/hooks/use-mobile';
import { Map, Building, LayoutGrid, Search, Info, MapPin, X, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import AddressSearch from '@/components/AddressSearch';

interface SimpleMapProps {
  properties: PropertyType[];
  professionals: ProfessionalType[];
  banks: BankType[];
  onMarkerClick: (item: PropertyType | ProfessionalType | BankType, type: ListingType) => void;
}

const SimpleMap: React.FC<SimpleMapProps> = ({ properties, professionals, banks, onMarkerClick }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const [activeLayer, setActiveLayer] = useState<'standard' | 'cadastral' | 'satellite'>('standard');
  const isMobile = useMobile();
  const { toast } = useToast();
  
  // Stati per controllare quali marker mostrare
  const [showProperties, setShowProperties] = useState<boolean>(true);
  const [showProfessionals, setShowProfessionals] = useState<boolean>(false);
  const [showBanks, setShowBanks] = useState<boolean>(false);
  
  // Funzione per cambiare il layer attivo
  const changeLayer = (newLayer: 'standard' | 'cadastral' | 'satellite') => {
    setActiveLayer(newLayer);
    
    // Utilizza window.map che viene definito nell'effetto sotto
    if (typeof window !== 'undefined' && window.map) {
      const map = window.map;
      
      // Definiamo i layer disponibili
      const baseLayers = {
        "standard": window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }),
        "satellite": window.L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
          attribution: 'Imagery &copy; Esri &copy; Maxar &copy; Earthstar Geographics'
        }),
        "cadastral": window.L.tileLayer.wms('https://wms.geo.admin.ch/', {
          layers: 'ch.swisstopo-vd.amtliche-vermessung',
          format: 'image/png',
          transparent: true,
          version: '1.3.0',
          attribution: '&copy; <a href="https://www.swisstopo.admin.ch/">Swisstopo</a>'
        })
      };
      
      // Rimuovi tutti i layer tiles esistenti
      map.eachLayer((layer: any) => {
        if (layer instanceof window.L.TileLayer) {
          map.removeLayer(layer);
        }
      });
      
      // Aggiungi il layer selezionato
      baseLayers[newLayer].addTo(map);
      
      // Conserva i marker esistenti
      updateVisibleMarkers();
    }
  };

  // Funzioni per aggiungere marker alla mappa
  // Funzione per creare icone marker
  const createMarkerIcon = (type: ListingType) => {
    // Definiamo i colori per ciascun tipo
    let color;
    
    if (type === 'property') {
      color = '#2563eb'; // Blu
    } else if (type === 'professional') {
      color = '#16a34a'; // Verde
    } else {
      color = '#d97706'; // Giallo-ambra per le banche
    }
    
    // Creiamo un cerchio SVG di dimensione media
    const circleRadius = 8; // Dimensione media, né troppo grande né troppo piccolo
    const svgSize = circleRadius * 2;
    
    // SVG per un semplice punto colorato
    const svgContent = `
      <svg xmlns="http://www.w3.org/2000/svg" width="${svgSize}" height="${svgSize}" viewBox="0 0 ${svgSize} ${svgSize}">
        <circle cx="${circleRadius}" cy="${circleRadius}" r="${circleRadius}" fill="${color}" stroke="white" stroke-width="1"/>
      </svg>
    `;
    
    // Convertiamo l'SVG in base64 per usarlo come URL
    const iconUrl = `data:image/svg+xml;base64,${btoa(svgContent)}`;
    
    // Configurazione icona
    return window.L.icon({
      iconUrl: iconUrl,
      iconSize: [svgSize, svgSize],
      iconAnchor: [circleRadius, circleRadius],
      popupAnchor: [0, -circleRadius]
    });
  };

  const addPropertyMarkers = () => {
    if (typeof window === 'undefined' || !window.map || !window.L) return;
    
    // Crea e aggiungi marker per le proprietà
    properties.forEach(property => {
      const marker = window.L.marker([property.lat, property.lng], {
        icon: createMarkerIcon('property')
      }).addTo(window.map);
      
      const popupContent = document.createElement('div');
      popupContent.className = "text-center";
      popupContent.style.minWidth = isMobile ? '180px' : '150px';
      popupContent.innerHTML = `
        <h3 class="font-bold text-lg">${property.title}</h3>
        <p class="text-blue-600 font-semibold">${property.price}</p>
        <button class="mt-2 bg-blue-600 text-white rounded px-3 py-2 w-full font-medium">
          Visualizza Dettagli
        </button>
      `;
      
      // Aggiungi evento click direttamente al pulsante
      const button = popupContent.querySelector('button');
      if (button) {
        button.addEventListener('click', () => {
          try {
            console.log("Click su proprietà:", property.id);
            onMarkerClick(property, 'property');
          } catch (e) {
            console.error("Errore nel click sulla proprietà:", e);
          }
        });
      }
      
      marker.bindPopup(popupContent);
    });
  };
  
  const addProfessionalMarkers = () => {
    if (typeof window === 'undefined' || !window.map || !window.L) return;
    
    // Crea e aggiungi marker per i professionisti
    professionals.forEach(professional => {
      const marker = window.L.marker([professional.lat, professional.lng], {
        icon: createMarkerIcon('professional')
      }).addTo(window.map);
      
      const profType = professional.type === 'architect' ? 'Architetto' : 
                       professional.type === 'notary' ? 'Notaio' : 
                       professional.type === 'artisan' ? 'Artigiano' : 
                       professional.type;
      
      const popupContent = document.createElement('div');
      popupContent.className = "text-center";
      popupContent.style.minWidth = isMobile ? '180px' : '150px';
      popupContent.innerHTML = `
        <h3 class="font-bold text-lg">${professional.name}</h3>
        <p class="text-green-600 font-semibold">${profType}</p>
        <button class="mt-2 bg-green-600 text-white rounded px-3 py-2 w-full font-medium">
          Contatta
        </button>
      `;
      
      // Aggiungi evento click direttamente al pulsante
      const button = popupContent.querySelector('button');
      if (button) {
        button.addEventListener('click', () => {
          try {
            console.log("Click su professionista:", professional.id);
            onMarkerClick(professional, 'professional');
          } catch (e) {
            console.error("Errore nel click sul professionista:", e);
          }
        });
      }
      
      marker.bindPopup(popupContent);
    });
  };
  
  const addBankMarkers = () => {
    if (typeof window === 'undefined' || !window.map || !window.L) return;
    
    // Crea e aggiungi marker per le banche
    banks.forEach(bank => {
      const marker = window.L.marker([bank.lat, bank.lng], {
        icon: createMarkerIcon('bank')
      }).addTo(window.map);
      
      const popupContent = document.createElement('div');
      popupContent.className = "text-center";
      popupContent.style.minWidth = isMobile ? '180px' : '150px';
      popupContent.innerHTML = `
        <h3 class="font-bold text-lg">${bank.name}</h3>
        <button class="mt-2 bg-amber-500 text-white rounded px-3 py-2 w-full font-medium">
          Contatta
        </button>
      `;
      
      // Aggiungi evento click direttamente al pulsante
      const button = popupContent.querySelector('button');
      if (button) {
        button.addEventListener('click', () => {
          try {
            console.log("Click su banca:", bank.id);
            onMarkerClick(bank, 'bank');
          } catch (e) {
            console.error("Errore nel click sulla banca:", e);
          }
        });
      }
      
      marker.bindPopup(popupContent);
    });
  };
  
  // Funzione per aggiornare i marker visibili sulla mappa
  const updateVisibleMarkers = () => {
    if (typeof window === 'undefined' || !window.map || !window.L) return;
    
    // Rimuovi tutti i marker esistenti
    window.map.eachLayer((layer: any) => {
      if (layer instanceof window.L.Marker) {
        window.map.removeLayer(layer);
      }
    });
    
    // Aggiungi marker in base allo stato
    if (showProperties) {
      addPropertyMarkers();
    }
    
    if (showProfessionals) {
      addProfessionalMarkers();
    }
    
    if (showBanks) {
      addBankMarkers();
    }
  };
  
  // Aggiungiamo un effetto per aggiornare i marker quando cambia lo stato di visibilità
  useEffect(() => {
    if (window.map) {
      updateVisibleMarkers();
    }
  }, [showProperties, showProfessionals, showBanks]);

  // Effetto per inizializzare la mappa
  useEffect(() => {
    // Assicuriamoci che Leaflet sia caricato prima e che il container esista
    if (typeof window !== 'undefined' && !window.L && mapContainerRef.current) {
      console.log('Leaflet non caricato, caricalo dinamicamente');
      
      // Carica il CSS di Leaflet
      const leafletCss = document.createElement('link');
      leafletCss.rel = 'stylesheet';
      leafletCss.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      leafletCss.integrity = 'sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=';
      leafletCss.crossOrigin = '';
      document.head.appendChild(leafletCss);
      
      // Carica il JS di Leaflet
      const leafletScript = document.createElement('script');
      leafletScript.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      leafletScript.integrity = 'sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=';
      leafletScript.crossOrigin = '';
      document.head.appendChild(leafletScript);
      
      // Carica Leaflet Geocoder per la ricerca degli indirizzi
      const geocoderScript = document.createElement('script');
      geocoderScript.src = 'https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js';
      document.head.appendChild(geocoderScript);
      
      const geocoderCss = document.createElement('link');
      geocoderCss.rel = 'stylesheet';
      geocoderCss.href = 'https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.css';
      document.head.appendChild(geocoderCss);
      
      // Aspetta che Leaflet sia caricato
      leafletScript.onload = () => {
        // Aspetta che il geocoder sia caricato
        geocoderScript.onload = () => {
          initializeMap();
        };
      };
    } else if (typeof window !== 'undefined' && window.L && mapContainerRef.current) {
      initializeMap();
    }
    
    function initializeMap() {
      if (!mapContainerRef.current || !window.L) return;
      
      try {
        console.log('Initializing map...');
        
        // Rimuovi mappa esistente se presente
        if (window.map) {
          window.map.remove();
        }
        
        // Inizializza la mappa
        const map = window.L.map(mapContainerRef.current).setView([46.0036, 8.9510], 13);
        window.map = map; // Memorizza la mappa nell'oggetto window
        
        // Aggiungi il layer base (OpenStreetMap)
        window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);
        
        // Aggiungi il controllo di geocoding (ricerca indirizzi) se disponibile
        if (window.L.Control.Geocoder) {
          const geocoder = window.L.Control.Geocoder.nominatim({
            geocodingQueryParams: {
              countrycodes: 'ch', // Solo Svizzera
              'accept-language': 'it',
            }
          });
          
          const control = window.L.Control.geocoder({
            geocoder: geocoder,
            position: 'topleft',
            placeholder: 'Cerca indirizzo...',
            defaultMarkGeocode: false,
            suggestMinLength: 3,
            errorMessage: 'Indirizzo non trovato',
            showResultIcons: true,
            suggestTimeout: 250,
            queryMinLength: 3
          }).on('markgeocode', function(e) {
            console.log("Geocoding result:", e);
            
            // Rimuovi eventuali marker precedenti
            map.eachLayer((layer: any) => {
              if (layer instanceof window.L.Marker && layer._icon && layer._icon.className.includes('search-marker')) {
                map.removeLayer(layer);
              }
            });
            
            const latlng = e.geocode.center;
            map.setView(latlng, 16);
            
            // Crea marker
            const marker = window.L.marker(latlng, {
              icon: window.L.divIcon({
                className: "search-marker",
                html: `<div style="background-color:rgba(0,0,255,0.7); width:24px; height:24px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:2px solid #fff; box-shadow: 0 0 10px rgba(0,0,0,0.3);"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="white"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5a2.5 2.5 0 0 1 0-5 2.5 2.5 0 0 1 0 5z"/></svg></div>`,
                iconSize: [24, 24],
                iconAnchor: [12, 24],
                popupAnchor: [0, -20]
              })
            }).addTo(map);
            
            // Mostra popup con info
            marker.bindPopup(`
              <div style="text-align:center;">
                <h3 style="font-weight:bold;">Indirizzo trovato</h3>
                <p>${e.geocode.name}</p>
                <p style="font-size:0.8em;">Coordinate: ${latlng.lat.toFixed(5)}, ${latlng.lng.toFixed(5)}</p>
              </div>
            `).openPopup();
            
            // Notifica
            toast({
              title: "Indirizzo trovato",
              description: "La mappa è stata centrata sulla posizione trovata",
              variant: "default"
            });
          }).addTo(map);
        }
        
        // Applica le impostazioni iniziali dei marker
        updateVisibleMarkers();
        
        // Configura i controlli del layer-switcher
        const baseLayers = {
          "Standard": window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          }),
          "Satellite": window.L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: 'Imagery &copy; Esri &copy; Maxar &copy; Earthstar Geographics'
          }),
          "Catastale": window.L.tileLayer.wms('https://wms.geo.admin.ch/', {
            layers: 'ch.swisstopo-vd.amtliche-vermessung',
            format: 'image/png',
            transparent: true,
            version: '1.3.0',
            attribution: '&copy; <a href="https://www.swisstopo.admin.ch/">Swisstopo</a>'
          })
        };
        
        // Aggiungiamo il controllo dei layer come parte integrante della mappa
        window.L.control.layers(baseLayers).addTo(map);
        
        // Assicuriamoci che il layer attivo sia selezionato di default
        if (activeLayer !== 'standard') {
          baseLayers[activeLayer === 'cadastral' ? "Catastale" : "Satellite"].addTo(map);
          baseLayers["Standard"].remove();
        }
        
        // Non abbiamo più bisogno della funzione globale handleMarkerClick
        // poiché abbiamo aggiunto i gestori di eventi direttamente ai pulsanti
        
        // Aggiungi pulsante di geolocalizzazione
        const geolocateControl = window.L.control({ position: 'bottomright' });
        geolocateControl.onAdd = () => {
          const container = window.L.DomUtil.create('div');
          container.className = 'leaflet-control';
          
          const button = window.L.DomUtil.create('button', '', container);
          button.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="${isMobile ? '32' : '24'}" height="${isMobile ? '32' : '24'}"><circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="4"></circle></svg>`;
          button.style.backgroundColor = 'white';
          button.style.border = '2px solid rgba(0,0,0,0.2)';
          button.style.borderRadius = '4px';
          button.style.cursor = 'pointer';
          button.style.padding = `${isMobile ? '8' : '5'}px`;
          button.style.boxShadow = '0 2px 4px rgba(0,0,0,0.2)';
          
          button.onclick = () => {
            if (navigator.geolocation) {
              // Cambia colore pulsante durante la ricerca
              button.style.backgroundColor = '#f0f0f0';
              
              navigator.geolocation.getCurrentPosition(
                (position) => {
                  map.setView([position.coords.latitude, position.coords.longitude], 16);
                  button.style.backgroundColor = 'white';
                },
                (error) => {
                  console.error('Errore di geolocalizzazione:', error);
                  alert('Impossibile ottenere la posizione.');
                  button.style.backgroundColor = 'white';
                }
              );
            }
            return false;
          };
          
          window.L.DomEvent.disableClickPropagation(container);
          return container;
        };
        geolocateControl.addTo(map);
        
        console.log('Map initialization complete');
      } catch (error) {
        console.error('Error initializing map:', error);
      }
    }
    
    // Cleanup
    return () => {
      if (typeof window !== 'undefined' && window.map) {
        window.map.remove();
        window.map = undefined;
      }
    };
  }, [properties, professionals, banks, isMobile, onMarkerClick]);

  // Stato per le ricerche
  const [showCadastralSearch, setShowCadastralSearch] = useState<boolean>(activeLayer === 'cadastral');
  const [cadastralSearchQuery, setCadastralSearchQuery] = useState<string>("");
  const [addressSearchQuery, setAddressSearchQuery] = useState<string>("");
  
  // Funzione di callback per AddressSearch
  const handleAddressFound = (lat: number, lng: number, name: string) => {
    console.log("Indirizzo trovato:", lat, lng, name);
    
    // Utilizziamo un timeout per assicurarci che la mappa sia completamente inizializzata
    setTimeout(() => {
      if (window.map && window.L) {
        try {
          // Creiamo un'icona personalizzata per il risultato della ricerca
          const icon = window.L.divIcon({
            className: "search-result-marker",
            html: `<div style="width:24px; height:24px; border-radius:12px; background-color:rgba(59, 130, 246, 0.8); border:2px solid white; display:flex; justify-content:center; align-items:center;"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg></div>`,
            iconSize: [24, 24],
            iconAnchor: [12, 24],
            popupAnchor: [0, -24]
          });
          
          // Rimuoviamo vecchi marker di ricerca
          window.map.eachLayer((layer: any) => {
            if (layer instanceof window.L.Marker && layer._icon && layer._icon.className.indexOf("search-result-marker") !== -1) {
              window.map.removeLayer(layer);
            }
          });
          
          // Aggiungiamo il marker
          const marker = window.L.marker([lat, lng], { icon }).addTo(window.map);
          
          // Aggiungiamo un popup
          marker.bindPopup(`
            <div style="text-align:center; padding:5px;">
              <strong>Indirizzo trovato</strong><br>
              <small>${name}</small>
            </div>
          `).openPopup();
          
          // Centriamo la mappa sulla posizione
          window.map.setView([lat, lng], 16);
          
          // Notifica di successo
          toast({
            title: "Indirizzo trovato",
            description: "La mappa è stata centrata sulla posizione",
            variant: "default"
          });
        } catch (error) {
          console.error("Errore nell'aggiunta del marker:", error);
        }
      } else {
        console.error("Mappa non disponibile");
      }
    }, 500); // Attendiamo 500ms per dare tempo alla mappa di caricarsi completamente
  };
  const [isSearching, setIsSearching] = useState(false);
  const [openSearchPopover, setOpenSearchPopover] = useState(false);
  
  // Effetto per mostrare/nascondere la ricerca catastale in base al layer attivo
  useEffect(() => {
    setShowCadastralSearch(activeLayer === 'cadastral');
  }, [activeLayer]);
  
  // Funzione per cercare indirizzi utilizzando OpenStreetMap Nominatim
  const searchAddress = async () => {
    if (!addressSearchQuery.trim()) return;
    
    try {
      console.log("Ricerca indirizzo:", addressSearchQuery);
      
      // Impostiamo lo stato di ricerca
      setIsSearching(true);
      
      // Mostra indicatore di caricamento
      toast({
        title: "Ricerca in corso...",
        description: "Sto cercando l'indirizzo specificato",
        variant: "default",
      });

      // Questo è un approccio semplificato che usa direttamente Nominatim
      try {
        // Formiamo la query da cercare
        const query = encodeURIComponent(`${addressSearchQuery}, Switzerland`);
        
        // Facciamo la richiesta
        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${query}&limit=1&countrycodes=ch`, {
          headers: {
            'Accept': 'application/json',
            'User-Agent': 'BoomHouse/1.0'
          }
        });
        
        // Verifichiamo la risposta
        if (!response.ok) {
          throw new Error(`Errore HTTP: ${response.status}`);
        }
        
        // Processiamo i dati
        const data = await response.json();
        
        if (data && data.length > 0) {
          // Abbiamo trovato la posizione
          const result = data[0];
          const lat = parseFloat(result.lat);
          const lon = parseFloat(result.lon);
          const name = result.display_name;
          
          console.log("Posizione trovata:", { lat, lon, name });
          
          // Verifichiamo che la mappa sia disponibile
          if (window.map) {
            // Creiamo un'icona personalizzata
            const icon = window.L.divIcon({
              className: "search-result-marker",
              html: `<div style="width:24px; height:24px; border-radius:12px; background-color:rgba(59, 130, 246, 0.8); border:2px solid white; display:flex; justify-content:center; align-items:center;"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg></div>`,
              iconSize: [24, 24],
              iconAnchor: [12, 24],
              popupAnchor: [0, -24]
            });
            
            // Rimuoviamo vecchi marker di ricerca
            window.map.eachLayer((layer: any) => {
              if (layer instanceof window.L.Marker && layer._icon && layer._icon.className.indexOf("search-result-marker") !== -1) {
                window.map.removeLayer(layer);
              }
            });
            
            // Aggiungiamo il marker
            const marker = window.L.marker([lat, lon], { icon }).addTo(window.map);
            
            // Aggiungiamo un popup
            marker.bindPopup(`
              <div style="text-align:center; padding:5px;">
                <strong>${addressSearchQuery}</strong><br>
                <small>${name}</small>
              </div>
            `).openPopup();
            
            // Centriamo la mappa sulla posizione
            window.map.setView([lat, lon], 16);
            
            // Notifica di successo
            toast({
              title: "Indirizzo trovato",
              description: "La mappa è stata centrata sulla posizione",
              variant: "default"
            });
            
            return;
          } else {
            console.error("Mappa non disponibile");
          }
        } else {
          // Nessun risultato trovato
          toast({
            title: "Indirizzo non trovato",
            description: "Non è stato possibile trovare l'indirizzo. Prova con termini più specifici.",
            variant: "destructive",
          });
        }
      } catch (error) {
        console.error("Errore nella ricerca:", error);
        toast({
          title: "Errore di ricerca",
          description: "Si è verificato un errore durante la ricerca dell'indirizzo.",
          variant: "destructive",
        });
      }
    } finally {
      setIsSearching(false);
    }
  };
  
  // Funzione per cercare mappale - specifica per la modalità catastale
  const searchCadastralParcel = () => {
    if (!cadastralSearchQuery.trim()) return;
    
    try {
      // Esempio di formato per la ricerca del mappale:
      // Comune-Sezione-Foglio-Particella
      // Es: "Lugano-1-23-456" or "CH-TI-Lugano-1-23-456"
      
      // In una situazione reale, qui chiameremmo un API di geocoding
      // per il catasto svizzero (maps.geo.admin.ch API)
      // Per questo esempio, simuliamo un punto in Svizzera.
      
      console.log("Ricerca mappale:", cadastralSearchQuery);
      
      if (typeof window !== 'undefined' && window.map && window.L) {
        // Coordinate simulate per il centro della Svizzera (Lugano area)
        const lat = 46.0111 + (Math.random() * 0.1 - 0.05); // simuliamo risultati vicini a Lugano
        const lng = 8.9581 + (Math.random() * 0.1 - 0.05);
        
        window.map.setView([lat, lng], 17);
        
        // Rimuovi eventuali marker di ricerca precedenti
        window.map.eachLayer((layer: any) => {
          if (layer instanceof window.L.Marker && layer._icon && layer._icon.className.includes('search-marker')) {
            window.map.removeLayer(layer);
          }
        });
        
        // Aggiungiamo un marker temporaneo per il punto trovato
        const searchMarker = window.L.marker([lat, lng], {
          icon: window.L.divIcon({
            className: "search-marker cadastral",
            html: `<div style="background-color:rgba(255,0,0,0.5); width:30px; height:30px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:2px solid #fff; font-weight:bold; color:white;">M</div>`,
            iconSize: [30, 30],
            iconAnchor: [15, 15]
          })
        }).addTo(window.map);
        
        // Mostra un popup con i dettagli del mappale
        searchMarker.bindPopup(
          `<div style="text-align:center;">
            <h3 style="font-weight:bold;">Mappale trovato</h3>
            <p>${cadastralSearchQuery}</p>
            <p style="font-size:0.8em;">Coordinate: ${lat.toFixed(5)}, ${lng.toFixed(5)}</p>
          </div>`
        ).openPopup();
        
        // Cambia il layer a catastale se non è già attivo
        if (activeLayer !== 'cadastral') {
          changeLayer('cadastral');
        }
        
        // Rimuovi il marker dopo 10 secondi
        setTimeout(() => {
          if (window.map && searchMarker) {
            window.map.removeLayer(searchMarker);
          }
        }, 10000);
      }
    } catch (error) {
      console.error("Errore nella ricerca del mappale:", error);
      alert("Si è verificato un errore durante la ricerca del mappale. Riprova più tardi.");
    }
  };
  
  return (
    <div className="bg-white p-2 rounded-lg shadow-sm h-full">
      {/* Pulsanti di cambio layer - versione desktop */}
      {!isMobile && (
        <div className="flex mb-2 space-x-2">
          <Button
            variant={activeLayer === 'cadastral' ? 'default' : 'outline'}
            className={`flex-1 ${activeLayer === 'cadastral' ? 'bg-primary text-white' : 'bg-gray-100 text-gray-800'} rounded-l`}
            onClick={() => {
              changeLayer('cadastral');
              setShowCadastralSearch(true);
            }}
          >
            Mappa Catastale
          </Button>
          <Button
            variant={activeLayer === 'satellite' ? 'default' : 'outline'}
            className={`flex-1 ${activeLayer === 'satellite' ? 'bg-primary text-white' : 'bg-gray-100 text-gray-800'}`}
            onClick={() => changeLayer('satellite')}
          >
            Satellite
          </Button>
          <Button
            variant={activeLayer === 'standard' ? 'default' : 'outline'}
            className={`flex-1 ${activeLayer === 'standard' ? 'bg-primary text-white' : 'bg-gray-100 text-gray-800'} rounded-r`}
            onClick={() => changeLayer('standard')}
          >
            Standard
          </Button>
        </div>
      )}
      
      {/* Pulsanti di cambio layer - versione mobile */}
      {isMobile && (
        <div className="flex justify-between mb-2 space-x-1">
          <Button
            variant={activeLayer === 'cadastral' ? 'default' : 'outline'}
            className={`flex-1 ${activeLayer === 'cadastral' ? 'bg-primary text-white' : 'bg-gray-100 text-gray-800'} rounded-l p-1`}
            onClick={() => {
              changeLayer('cadastral');
              setShowCadastralSearch(true);
            }}
            size="sm"
          >
            <Building size={20} className="mr-1" />
            <span className="text-xs">Catasto</span>
          </Button>
          <Button
            variant={activeLayer === 'satellite' ? 'default' : 'outline'}
            className={`flex-1 ${activeLayer === 'satellite' ? 'bg-primary text-white' : 'bg-gray-100 text-gray-800'} p-1`}
            onClick={() => changeLayer('satellite')}
            size="sm"
          >
            <LayoutGrid size={20} className="mr-1" />
            <span className="text-xs">Satellite</span>
          </Button>
          <Button
            variant={activeLayer === 'standard' ? 'default' : 'outline'}
            className={`flex-1 ${activeLayer === 'standard' ? 'bg-primary text-white' : 'bg-gray-100 text-gray-800'} rounded-r p-1`}
            onClick={() => changeLayer('standard')}
            size="sm"
          >
            <Map size={20} className="mr-1" />
            <span className="text-xs">Mappa</span>
          </Button>
        </div>
      )}
      
      {/* Campo di ricerca - cambia in base alla modalità attiva */}
      <div className="mb-3 flex space-x-2 items-center">
        {/* Campo di ricerca mappale quando il layer catastale è attivo */}
        {showCadastralSearch ? (
          <>
            <Input
              type="text"
              placeholder="Cerca mappale (es. Lugano-1-23-456)"
              value={cadastralSearchQuery}
              onChange={(e) => setCadastralSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  searchCadastralParcel();
                }
              }}
              className="flex-1"
            />
            <Button 
              variant="default" 
              size="sm"
              onClick={searchCadastralParcel}
            >
              <Search size={18} />
            </Button>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <span className="cursor-help">
                    <Info size={18} className="text-gray-500" />
                  </span>
                </TooltipTrigger>
                <TooltipContent className="max-w-[300px]">
                  <p className="text-xs">
                    Inserisci il numero di mappale nel formato Comune-Sezione-Foglio-Particella 
                    (es. Lugano-1-23-456) per cercare nel catasto.
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </>
        ) : (
          <AddressSearch onAddressFound={handleAddressFound}
          />
        )}
      </div>
      
      {/* Container per la mappa */}
      <div 
        ref={mapContainerRef} 
        className="rounded-lg overflow-hidden border border-gray-200" 
        style={{ height: isMobile ? '400px' : '600px', width: '100%' }}
      />
      
      {/* Filtri per marker */}
      <div className="mt-3 mb-1 flex flex-wrap gap-2">
        <div className="flex items-center">
          <input
            type="checkbox"
            id="show-properties"
            checked={showProperties}
            onChange={(e) => setShowProperties(e.target.checked)}
            className="mr-2 h-4 w-4 rounded border-gray-300"
          />
          <label htmlFor="show-properties" className="text-sm font-medium flex items-center">
            <div className="w-3 h-3 bg-blue-600 rounded-full mr-2 border border-white"></div>
            Immobili
          </label>
        </div>
        
        <div className="flex items-center">
          <input
            type="checkbox"
            id="show-professionals"
            checked={showProfessionals}
            onChange={(e) => setShowProfessionals(e.target.checked)}
            className="mr-2 h-4 w-4 rounded border-gray-300"
          />
          <label htmlFor="show-professionals" className="text-sm font-medium flex items-center">
            <div className="w-3 h-3 bg-green-600 rounded-full mr-2 border border-white"></div>
            Professionisti
          </label>
        </div>
        
        <div className="flex items-center">
          <input
            type="checkbox"
            id="show-banks"
            checked={showBanks}
            onChange={(e) => setShowBanks(e.target.checked)}
            className="mr-2 h-4 w-4 rounded border-gray-300"
          />
          <label htmlFor="show-banks" className="text-sm font-medium flex items-center">
            <div className="w-3 h-3 bg-amber-600 rounded-full mr-2 border border-white"></div>
            Banche e assicurazioni
          </label>
        </div>
      </div>
      
      {/* Footer con crediti */}
      <div className="mt-2 text-xs text-gray-500">
        <p>
          Fonte dati: {activeLayer === 'standard' ? 'OpenStreetMap contributors' : 
                     activeLayer === 'cadastral' ? 'Swisstopo' : 
                     'Esri, Maxar, Earthstar Geographics'} | © {new Date().getFullYear()} BoomHouse
        </p>
      </div>
    </div>
  );
};

// Estende l'oggetto Window per TypeScript
declare global {
  interface Window {
    L: any;
    map: any;
  }
}

export default SimpleMap;