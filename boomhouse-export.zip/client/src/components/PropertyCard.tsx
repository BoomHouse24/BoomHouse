import { PropertyType } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Heart, Share2 } from "lucide-react";

interface PropertyCardProps {
  property: PropertyType;
  onViewDetails: () => void;
}

export default function PropertyCard({ property, onViewDetails }: PropertyCardProps) {
  return (
    <div className="booking-card property-card bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden transition-all duration-200">
      <div className="relative">
        <img 
          src={property.imageUrl} 
          alt={property.title} 
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-0 right-0 m-2 flex flex-col gap-1">
          <span 
            className={`inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium ${
              property.listingType === "For Sale" 
                ? "bg-[#eff5ff] dark:bg-blue-900/50 text-[#0071c2] dark:text-blue-300" 
                : "bg-[#e7fde9] dark:bg-green-900/50 text-[#008009] dark:text-green-300"
            }`}
          >
            {property.listingType === "For Sale" ? "Vendita" : "Affitto"}
          </span>
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
            {property.propertyType === "residential" ? "Residenziale" :
             property.propertyType === "commercial" ? "Commerciale" :
             property.propertyType === "land" ? "Terreno" :
             property.propertyType === "industrial" ? "Industriale" :
             property.propertyType}
          </span>
        </div>
      </div>
      <div className="p-4">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-medium text-[#003580] dark:text-blue-300">{property.title}</h3>
            <p className="text-sm text-gray-600 dark:text-gray-300">{property.address}</p>
          </div>
          <p className="text-lg font-bold text-[#0071c2] dark:text-blue-300">{property.price}</p>
        </div>
        <div className="mt-2 flex items-center text-sm text-gray-500 dark:text-gray-400 space-x-4">
          {property.beds && (
            <div className="flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-4 w-4 mr-1"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path d="M7 2a1 1 0 00-.707 1.707L7 4.414v3.758a1 1 0 01-.293.707l-4 4C.817 14.769 2.156 18 4.828 18h10.343c2.673 0 4.012-3.231 2.122-5.121l-4-4A1 1 0 0113 8.172V4.414l.707-.707A1 1 0 0013 2H7zm2 6.172V4h2v4.172a3 3 0 00.879 2.12l1.168 1.168a4 4 0 01-8.092 0l1.17-1.169a3 3 0 00.879-2.12z" />
              </svg>
              <span>{property.beds} camere</span>
            </div>
          )}
          {property.baths && (
            <div className="flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-4 w-4 mr-1"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path
                  fillRule="evenodd"
                  d="M5.5 2a3.5 3.5 0 013.5 3.5V9H2V5.5A3.5 3.5 0 015.5 2zM11 9V5.5A5.5 5.5 0 000 5.5V9h11zm-2 3a2 2 0 013.88.5H12a1 1 0 01-1-1zm-7 0a1 1 0 011 1h.88A2 2 0 013 12zm7 2H3v5a3 3 0 003 3h4a3 3 0 003-3v-5h-7z"
                  clipRule="evenodd"
                />
              </svg>
              <span>{property.baths} bagni</span>
            </div>
          )}
          <div className="flex items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-4 w-4 mr-1"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fillRule="evenodd"
                d="M10 2a1 1 0 00-1 1v1.323l-3.954 1.582 1.599 1.599L10 5.762l3.355 1.742 1.599-1.599L10.954 4.323V3a1 1 0 00-1-1zM2.707 7.293l8.284 8.284a1 1 0 001.414 0l5.657-5.657a1 1 0 10-1.414-1.414L10 14.414l-7.293-7.293a1 1 0 00-1.414 0 1 1 0 000 1.414z"
                clipRule="evenodd"
              />
            </svg>
            <span>{property.area} m²</span>
          </div>
        </div>
        <div className="mt-4 flex justify-between items-center">
          <Button 
            onClick={onViewDetails}
            className="booking-btn-secondary text-sm px-3 py-1.5 dark:bg-blue-700 dark:hover:bg-blue-600 dark:text-white"
          >
            Visualizza Dettagli
          </Button>
          <div className="flex space-x-2">
            <Button variant="ghost" size="icon" className="text-[#0071c2] dark:text-blue-300 hover:text-[#003580] dark:hover:text-blue-200 h-8 w-8">
              <Heart className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className="text-[#0071c2] dark:text-blue-300 hover:text-[#003580] dark:hover:text-blue-200 h-8 w-8">
              <Share2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
