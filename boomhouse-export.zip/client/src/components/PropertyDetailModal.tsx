import { useRef } from "react";
import { PropertyType } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Check } from "lucide-react";

interface PropertyDetailModalProps {
  property: PropertyType | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function PropertyDetailModal({ property, isOpen, onClose }: PropertyDetailModalProps) {
  const mainImageRef = useRef<HTMLImageElement>(null);

  if (!property) return null;

  const updateMainImage = (imageSrc: string) => {
    if (mainImageRef.current) {
      mainImageRef.current.src = imageSrc;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl overflow-y-auto max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-gray-900">{property.title}</DialogTitle>
          <p className="text-sm text-gray-500">{property.address}</p>
        </DialogHeader>
        
        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <img 
              ref={mainImageRef}
              src={property.imageUrl} 
              alt={property.title} 
              className="w-full h-64 object-cover rounded-lg" 
            />
            
            <div className="mt-2 grid grid-cols-4 gap-2">
              {property.additionalImages?.map((img, index) => (
                <img 
                  key={index}
                  src={img} 
                  alt={`${property.title} view ${index + 1}`} 
                  className="w-full h-20 object-cover rounded-lg cursor-pointer" 
                  onClick={() => updateMainImage(img)}
                />
              ))}
            </div>
          </div>
          
          <div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="text-lg font-medium text-gray-900 mb-2">Dettagli Proprietà</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <span className="text-gray-500">Tipo:</span>
                  <span className="text-gray-900 ml-1">
                    {property.propertyType === 'residential' ? 'Residenziale' :
                     property.propertyType === 'commercial' ? 'Commerciale' :
                     property.propertyType === 'land' ? 'Terreno' :
                     property.propertyType === 'industrial' ? 'Industriale' :
                     property.propertyType}
                  </span>
                </div>
                <div>
                  <span className="text-gray-500">Stato:</span>
                  <span className="text-gray-900 ml-1">
                    {property.listingType === 'For Sale' ? 'In Vendita' : 
                     property.listingType === 'For Rent' ? 'In Affitto' : 
                     property.listingType}
                  </span>
                </div>
                {property.beds && (
                  <div>
                    <span className="text-gray-500">Camere:</span>
                    <span className="text-gray-900 ml-1">{property.beds}</span>
                  </div>
                )}
                {property.baths && (
                  <div>
                    <span className="text-gray-500">Bagni:</span>
                    <span className="text-gray-900 ml-1">{property.baths}</span>
                  </div>
                )}
                <div>
                  <span className="text-gray-500">Area:</span>
                  <span className="text-gray-900 ml-1">{property.area} m²</span>
                </div>
                {property.landArea && (
                  <div>
                    <span className="text-gray-500">Terreno:</span>
                    <span className="text-gray-900 ml-1">{property.landArea} m²</span>
                  </div>
                )}
                {property.yearBuilt && (
                  <div>
                    <span className="text-gray-500">Anno Costruzione:</span>
                    <span className="text-gray-900 ml-1">{property.yearBuilt}</span>
                  </div>
                )}
                <div>
                  <span className="text-gray-500">Prezzo:</span>
                  <span className="text-primary font-semibold ml-1">{property.price}</span>
                </div>
              </div>
              
              <h4 className="text-lg font-medium text-gray-900 mt-4 mb-2">Caratteristiche</h4>
              <div className="grid grid-cols-2 gap-2">
                {property.features?.map((feature, index) => (
                  <div key={index} className="flex items-center text-sm">
                    <Check className="h-4 w-4 text-secondary mr-2" />
                    <span>
                      {feature === 'Parking' ? 'Parcheggio' : 
                       feature === 'Garden' ? 'Giardino' : 
                       feature === 'Balcony' ? 'Balcone' : 
                       feature === 'Pool' ? 'Piscina' : 
                       feature === 'Air Conditioning' ? 'Aria Condizionata' :
                       feature === 'Fireplace' ? 'Camino' :
                       feature === 'Elevator' ? 'Ascensore' :
                       feature === 'Security System' ? 'Sistema di Sicurezza' :
                       feature}
                    </span>
                  </div>
                ))}
              </div>
              
              <div className="mt-4">
                <Button className="w-full bg-primary hover:bg-primary/90">
                  Contatta Agente
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-4">
          <h4 className="text-lg font-medium text-gray-900 mb-2">Descrizione</h4>
          <p className="text-sm text-gray-700">
            {property.description}
          </p>
        </div>
        
        <div className="mt-4">
          <h4 className="text-lg font-medium text-gray-900 mb-2">Posizione</h4>
          <div className="h-48 bg-gray-200 rounded-lg">
            <div className="w-full h-full flex items-center justify-center text-gray-600">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 mr-2"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                />
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                />
              </svg>
              <span>{property.address}</span>
            </div>
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Chiudi
          </Button>
          <Button className="bg-primary hover:bg-primary/90">
            Pianifica Visita
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
