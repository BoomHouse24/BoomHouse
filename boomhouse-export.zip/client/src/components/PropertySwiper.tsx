import { useState, useRef, useEffect } from 'react';
import { PropertyType } from '@/lib/types';
import { Heart, Share2, MessageCircle, ArrowRight, ChevronUp, ChevronDown, MapPin, Home, Building, Ban } from 'lucide-react';
import { useMobile } from '@/hooks/use-mobile';

interface PropertySwiperProps {
  properties: PropertyType[];
  onViewDetails: (property: PropertyType) => void;
}

export default function PropertySwiper({ properties, onViewDetails }: PropertySwiperProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [startY, setStartY] = useState(0);
  const [dragY, setDragY] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [liked, setLiked] = useState<Record<number, boolean>>({});
  const [comments, setComments] = useState<Record<number, number>>({});
  const [shares, setShares] = useState<Record<number, number>>({});
  const containerRef = useRef<HTMLDivElement>(null);
  const slidesRef = useRef<(HTMLDivElement | null)[]>([]);
  const isMobile = useMobile();

  // Inizializza dati casuali per like, commenti e condivisioni
  useEffect(() => {
    if (properties.length > 0) {
      const initialLikes: Record<number, boolean> = {};
      const initialComments: Record<number, number> = {};
      const initialShares: Record<number, number> = {};
      
      properties.forEach(property => {
        initialLikes[property.id] = false;
        initialComments[property.id] = Math.floor(Math.random() * 50);
        initialShares[property.id] = Math.floor(Math.random() * 20);
      });
      
      setComments(initialComments);
      setShares(initialShares);
    }
  }, [properties]);

  // Gestisce la navigazione con la rotellina del mouse
  useEffect(() => {
    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      
      if (e.deltaY > 0) {
        // Scroll down - next property
        if (activeIndex < properties.length - 1) {
          setActiveIndex(prev => prev + 1);
        }
      } else {
        // Scroll up - previous property
        if (activeIndex > 0) {
          setActiveIndex(prev => prev - 1);
        }
      }
    };

    const container = containerRef.current;
    if (container) {
      container.addEventListener('wheel', handleWheel, { passive: false });
    }

    return () => {
      if (container) {
        container.removeEventListener('wheel', handleWheel);
      }
    };
  }, [activeIndex, properties.length]);

  // Gestione touch per mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    setStartY(e.touches[0].clientY);
    setIsDragging(true);
    setDragY(0);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging) return;
    
    const currentY = e.touches[0].clientY;
    const newDragY = startY - currentY;
    setDragY(newDragY);
  };

  const handleTouchEnd = () => {
    if (!isDragging) return;
    
    // Cambia slide se il trascinamento è stato sufficiente
    if (Math.abs(dragY) > 100) {
      if (dragY > 0 && activeIndex < properties.length - 1) {
        setActiveIndex(prev => prev + 1);
      } else if (dragY < 0 && activeIndex > 0) {
        setActiveIndex(prev => prev - 1);
      }
    }
    
    setIsDragging(false);
    setDragY(0);
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (activeIndex < properties.length - 1) {
      setActiveIndex(prev => prev + 1);
    }
  };

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (activeIndex > 0) {
      setActiveIndex(prev => prev - 1);
    }
  };

  const toggleLike = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setLiked(prev => {
      const newValue = !prev[id];
      return { ...prev, [id]: newValue };
    });
  };
  
  if (properties.length === 0) {
    return (
      <div className="flex items-center justify-center h-full bg-black text-white">
        <div className="text-center">
          <Ban size={48} className="mx-auto mb-4 text-gray-400" />
          <p className="text-xl">Nessun immobile disponibile</p>
          <p className="text-gray-400 mt-2">Prova a modificare i filtri di ricerca</p>
        </div>
      </div>
    );
  }

  // Calcola lo stile di traslazione per l'effetto di scorrimento
  const getTransformStyle = () => {
    if (!isDragging) {
      return {
        transform: `translateY(-${activeIndex * 100}%)`,
        transition: 'transform 0.5s cubic-bezier(0.19, 1, 0.22, 1)'
      };
    } else {
      // Calcola una traslazione basata sul trascinamento corrente
      const dragPercent = dragY / (containerRef.current?.clientHeight || 1) * 100;
      const newTranslateY = -(activeIndex * 100) - dragPercent;
      return {
        transform: `translateY(${newTranslateY}%)`,
        transition: 'none'
      };
    }
  };

  return (
    <div 
      ref={containerRef}
      className="tiktok-container h-full w-full relative bg-black overflow-hidden" 
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Progress Indicator */}
      <div className="absolute top-4 left-0 right-0 z-30 flex justify-center gap-1 px-2">
        {properties.map((_, index) => (
          <div 
            key={index} 
            className={`h-1 rounded-full ${index === activeIndex ? 'bg-white w-6' : 'bg-white/40 w-4'} transition-all duration-300`}
          />
        ))}
      </div>
      
      {/* Navigation Controls */}
      <button 
        onClick={handlePrev}
        className={`absolute left-4 top-1/2 transform -translate-y-1/2 z-20 p-2 text-white rounded-full ${activeIndex === 0 ? 'opacity-0' : 'opacity-40 hover:opacity-80'} transition-opacity bg-black/30`}
        disabled={activeIndex === 0}
      >
        <ChevronUp size={40} />
      </button>
      
      <button 
        onClick={handleNext}
        className={`absolute left-4 bottom-1/4 transform -translate-y-1/2 z-20 p-2 text-white rounded-full ${activeIndex === properties.length - 1 ? 'opacity-0' : 'opacity-40 hover:opacity-80'} transition-opacity bg-black/30`}
        disabled={activeIndex === properties.length - 1}
      >
        <ChevronDown size={40} />
      </button>
      
      {/* Container for all property slides */}
      <div className="h-full w-full relative" style={getTransformStyle()}>
        {properties.map((property, index) => (
          <div 
            key={property.id}
            ref={el => slidesRef.current[index] = el}
            className="absolute top-0 left-0 w-full h-full"
            style={{ transform: `translateY(${index * 100}%)` }}
            onClick={() => onViewDetails(property)}
          >
            {/* Property Background Image */}
            <div className="absolute inset-0">
              <img 
                src={property.imageUrl} 
                alt={property.title} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/80"></div>
            </div>
            
            {/* Property Type Badge */}
            <div className="absolute top-6 left-4 z-10 flex items-center">
              <div className="bg-black/50 px-3 py-1 rounded-full flex items-center text-white text-sm">
                {property.propertyType === "residential" ? (
                  <>
                    <Home size={14} className="mr-1" />
                    <span>Residenziale</span>
                  </>
                ) : property.propertyType === "commercial" ? (
                  <>
                    <Building size={14} className="mr-1" />
                    <span>Commerciale</span>
                  </>
                ) : (
                  <>
                    <MapPin size={14} className="mr-1" />
                    <span>{property.propertyType}</span>
                  </>
                )}
              </div>
              
              <div className={`ml-2 px-3 py-1 rounded-full text-white text-sm ${property.listingType === "For Sale" ? "bg-blue-600" : "bg-green-600"}`}>
                {property.listingType === "For Sale" ? "Vendita" : "Affitto"}
              </div>
            </div>
            
            {/* Main content */}
            <div className="absolute bottom-0 left-0 right-0 p-4 z-10">
              {/* Property details */}
              <div className="flex justify-between items-end mb-6">
                <div className="w-3/4">
                  <h3 className="text-white text-2xl font-bold drop-shadow-lg mb-2">{property.title}</h3>
                  <div className="flex items-center text-white mb-2">
                    <MapPin size={16} className="mr-1" />
                    <span className="drop-shadow-md text-sm">{property.address}</span>
                  </div>
                  
                  <div className="flex items-center gap-3 mt-3">
                    {property.beds && (
                      <div className="bg-black/40 px-3 py-1 rounded-full text-white text-sm flex items-center">
                        <span>{property.beds} locali</span>
                      </div>
                    )}
                    
                    {property.baths && (
                      <div className="bg-black/40 px-3 py-1 rounded-full text-white text-sm flex items-center">
                        <span>{property.baths} bagni</span>
                      </div>
                    )}
                    
                    <div className="bg-black/40 px-3 py-1 rounded-full text-white text-sm flex items-center">
                      <span>{property.area} m²</span>
                    </div>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="text-white text-2xl font-bold drop-shadow-lg">{property.price}</div>
                </div>
              </div>
              
              {/* Actions bar at the bottom */}
              <div className="flex items-center justify-between">
                <button 
                  className="bg-white/10 backdrop-blur-sm border border-white/20 text-white px-4 py-2 rounded-full flex items-center hover:bg-white/20 transition-colors"
                  onClick={(e) => { e.stopPropagation(); onViewDetails(property); }}
                >
                  Dettagli completi
                  <ArrowRight size={16} className="ml-2" />
                </button>
                
                <div className="flex items-center gap-6">
                  {/* Like button */}
                  <div className="flex flex-col items-center">
                    <button 
                      className="w-10 h-10 rounded-full flex items-center justify-center bg-black/30 hover:bg-black/50 transition-colors"
                      onClick={(e) => toggleLike(property.id, e)}
                    >
                      <Heart 
                        size={24} 
                        className={liked[property.id] ? "fill-red-500 text-red-500" : "text-white"} 
                      />
                    </button>
                    <span className="text-white text-xs mt-1">{liked[property.id] ? 'Mi piace' : 'Like'}</span>
                  </div>
                  
                  {/* Comments button */}
                  <div className="flex flex-col items-center">
                    <button 
                      className="w-10 h-10 rounded-full flex items-center justify-center bg-black/30 hover:bg-black/50 transition-colors"
                      onClick={(e) => { e.stopPropagation(); }}
                    >
                      <MessageCircle size={24} className="text-white" />
                    </button>
                    <span className="text-white text-xs mt-1">{comments[property.id] || 0}</span>
                  </div>
                  
                  {/* Share button */}
                  <div className="flex flex-col items-center">
                    <button 
                      className="w-10 h-10 rounded-full flex items-center justify-center bg-black/30 hover:bg-black/50 transition-colors"
                      onClick={(e) => { 
                        e.stopPropagation();
                        if (navigator.share) {
                          navigator.share({
                            title: property.title,
                            text: `${property.title} - ${property.price}`,
                            url: window.location.href,
                          }).catch(err => {
                            console.error('Errore nella condivisione:', err);
                          });
                        } else {
                          setShares(prev => ({
                            ...prev,
                            [property.id]: (prev[property.id] || 0) + 1
                          }));
                          alert('Link copiato negli appunti!');
                        }
                      }}
                    >
                      <Share2 size={24} className="text-white" />
                    </button>
                    <span className="text-white text-xs mt-1">{shares[property.id] || 0}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Current page indicator */}
      <div className="absolute left-4 top-4 z-20 bg-black/50 text-white text-sm px-2 py-1 rounded-full">
        {activeIndex + 1}/{properties.length}
      </div>
      
      {/* Hint for swiping */}
      <div className="absolute bottom-28 left-1/2 transform -translate-x-1/2 z-10">
        <div className="animate-bounce bg-white/10 backdrop-blur-sm text-white px-4 py-2 rounded-full text-xs">
          Scorrere per vedere altri immobili
        </div>
      </div>
    </div>
  );
}