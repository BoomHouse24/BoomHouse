import { useState } from 'react';
import { PropertyType } from '@/lib/types';
import { List, Grid, Columns, Grip } from 'lucide-react';
import PropertySwiper from './PropertySwiper';
import PropertyCard from './PropertyCard';

interface PropertiesViewProps {
  properties: PropertyType[];
  onViewDetails: (property: PropertyType) => void;
}

export default function PropertiesView({ properties, onViewDetails }: PropertiesViewProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list' | 'swiper'>('grid');

  return (
    <div className="w-full">
      {/* View Mode Selector */}
      <div className="flex justify-between items-center py-4 mb-4 border-b border-[#e7e7e7]">
        <h2 className="text-xl font-bold text-[#262626]">
          Immobili in evidenza
        </h2>
        <div className="flex items-center space-x-2">
          <button 
            onClick={() => setViewMode('grid')} 
            className={`p-2 rounded-md transition-colors ${viewMode === 'grid' ? 'bg-[#f2f8fc] text-[#0071c2]' : 'text-gray-500 hover:bg-gray-100'}`}
            title="Vista griglia"
          >
            <Grid size={20} />
          </button>
          <button 
            onClick={() => setViewMode('list')} 
            className={`p-2 rounded-md transition-colors ${viewMode === 'list' ? 'bg-[#f2f8fc] text-[#0071c2]' : 'text-gray-500 hover:bg-gray-100'}`}
            title="Vista lista"
          >
            <List size={20} />
          </button>
          <button 
            onClick={() => setViewMode('swiper')} 
            className={`p-2 rounded-md transition-colors ${viewMode === 'swiper' ? 'bg-[#f2f8fc] text-[#0071c2]' : 'text-gray-500 hover:bg-gray-100'}`}
            title="Vista TikTok"
          >
            <Columns size={20} />
          </button>
        </div>
      </div>

      {/* Content based on view mode */}
      {viewMode === 'swiper' && (
        <div className="w-full h-[600px] border border-[#e7e7e7] overflow-hidden">
          <PropertySwiper 
            properties={properties} 
            onViewDetails={onViewDetails} 
          />
        </div>
      )}

      {viewMode === 'grid' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {properties.slice(0, 6).map((property) => (
            <PropertyCard 
              key={property.id} 
              property={property} 
              onViewDetails={() => onViewDetails(property)} 
            />
          ))}
        </div>
      )}

      {viewMode === 'list' && (
        <div className="space-y-4">
          {properties.slice(0, 6).map((property) => (
            <div 
              key={property.id} 
              className="flex flex-col md:flex-row border border-[#e7e7e7] rounded-sm overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => onViewDetails(property)}
            >
              <div className="md:w-1/3 h-48 md:h-auto relative">
                <img src={property.imageUrl} alt={property.title} className="w-full h-full object-cover" />
                <div className="absolute top-0 left-0 bg-[#003580] text-white text-xs px-2 py-1">
                  {property.propertyType === "residential" ? "Residenziale" :
                   property.propertyType === "commercial" ? "Commerciale" :
                   property.propertyType === "land" ? "Terreno" : 
                   property.propertyType === "industrial" ? "Industriale" : 
                   property.propertyType}
                </div>
                <div className="absolute top-0 right-0 px-2 py-1 text-white text-xs font-medium"
                  style={{backgroundColor: property.listingType === "For Sale" ? "#0071c2" : "#008009"}}>
                  {property.listingType === "For Sale" ? "Vendita" : "Affitto"}
                </div>
              </div>
              
              <div className="md:w-2/3 p-4">
                <div className="flex justify-between mb-2">
                  <h3 className="font-bold text-[#262626] text-lg">{property.title}</h3>
                  <span className="text-[#0071c2] font-bold whitespace-nowrap">{property.price}</span>
                </div>
                
                <p className="text-[#6b6b6b] mb-4">{property.address}</p>
                
                <div className="flex items-center text-sm text-[#6b6b6b] mb-4">
                  {property.beds && (
                    <div className="flex items-center mr-4">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M2 9v6h20V9"></path>
                        <path d="M2 19h20"></path>
                        <path d="M2 5h20"></path>
                      </svg>
                      {property.beds} locali
                    </div>
                  )}
                  
                  {property.baths && (
                    <div className="flex items-center mr-4">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M4 12h16a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2z"></path>
                        <path d="M6 12V6a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v6"></path>
                      </svg>
                      {property.baths} bagni
                    </div>
                  )}
                  
                  <div className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                    </svg>
                    {property.area} m²
                  </div>
                </div>
                
                <div className="mt-auto">
                  <button className="text-center py-2 px-4 text-sm text-[#0071c2] border border-[#0071c2] hover:bg-[#f2f8fc] rounded-sm">
                    Visualizza dettagli
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}