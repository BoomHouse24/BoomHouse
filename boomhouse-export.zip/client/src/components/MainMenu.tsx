import { useState } from 'react';
import { Building, Home, Info, HelpCircle, Star, MessageSquare, Briefcase } from 'lucide-react';

// Importa i componenti UI di base
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";

// Definizione della struttura delle voci di menu
const menuItems = [
  {
    title: "BOOMHOUSE",
    icon: <Home className="h-4 w-4 mr-2" />,
    items: [
      { title: "Chi siamo", href: "/chi-siamo", icon: <Info className="h-4 w-4 mr-2" /> },
      { title: "Come funziona", href: "/come-funziona", icon: <HelpCircle className="h-4 w-4 mr-2" /> },
      { title: "Recensioni", href: "/recensioni", icon: <Star className="h-4 w-4 mr-2" /> },
      { title: "Contattaci", href: "/contattaci", icon: <MessageSquare className="h-4 w-4 mr-2" /> },
      { title: "Diventa partner", href: "/diventa-partner", icon: <Briefcase className="h-4 w-4 mr-2" /> }
    ]
  },
  {
    title: "IMMOBILI",
    icon: <Building className="h-4 w-4 mr-2" />,
    items: [
      { title: "Case e appartamenti", href: "/case-appartamenti", icon: <Home className="h-4 w-4 mr-2" /> },
      { title: "Immobili commerciali", href: "/immobili-commerciali", icon: <Building className="h-4 w-4 mr-2" /> },
      { title: "Terreni", href: "/terreni", icon: <Building className="h-4 w-4 mr-2" /> },
      { title: "Annunci più visualizzati", href: "/annunci-popolari", icon: <Building className="h-4 w-4 mr-2" /> },
      { title: "Inserisci un annuncio", href: "/inserisci-annuncio", icon: <Building className="h-4 w-4 mr-2" /> }
    ]
  }
];

export default function MainMenu() {
  return (
    <NavigationMenu className="w-full max-w-xs">
      <NavigationMenuList className="flex flex-col items-start w-full">
        {menuItems.map((menuGroup) => (
          <NavigationMenuItem key={menuGroup.title} className="w-full">
            <NavigationMenuTrigger className="w-full flex items-center justify-between">
              <div className="flex items-center">
                {menuGroup.icon}
                <span>{menuGroup.title}</span>
              </div>
            </NavigationMenuTrigger>
            <NavigationMenuContent className="w-full max-w-xs bg-white dark:bg-gray-900 p-1 border border-gray-200 dark:border-gray-800 rounded-md shadow-lg">
              <ul className="grid gap-1 p-1 w-full">
                {menuGroup.items.map((item) => (
                  <li key={item.title} className="w-full">
                    <NavigationMenuLink asChild>
                      <a
                        href={item.href}
                        className="flex items-center p-3 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md"
                      >
                        {item.icon}
                        <span>{item.title}</span>
                      </a>
                    </NavigationMenuLink>
                  </li>
                ))}
              </ul>
            </NavigationMenuContent>
          </NavigationMenuItem>
        ))}
      </NavigationMenuList>
    </NavigationMenu>
  );
}