import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { ChevronDown, ChevronRight } from "lucide-react";
import { PropertyType, ProfessionalType, BankType, ListingType, FilterType } from "@/lib/types";
import PropertyCard from "./PropertyCard";
import ProfessionalCard from "./ProfessionalCard";
import BankCard from "./BankCard";
import FilterSection from "./FilterSection";
import { Button } from "@/components/ui/button";

interface SidebarProps {
  properties: PropertyType[];
  professionals: ProfessionalType[];
  banks: BankType[];
  onViewProperty: (property: PropertyType) => void;
  onContactProfessional: (professional: ProfessionalType) => void;
  onContactBank: (bank: BankType) => void;
  filters: FilterType;
  setFilters: (filters: FilterType) => void;
}

export default function Sidebar({
  properties,
  professionals,
  banks,
  onViewProperty,
  onContactProfessional,
  onContactBank,
  filters,
  setFilters,
}: SidebarProps) {
  const queryClient = useQueryClient();
  const [expandedSections, setExpandedSections] = useState({
    filters: false,
    properties: true,
    professionals: false,
    banks: false,
  });

  const toggleSection = (section: keyof typeof expandedSections) => {
    try {
      setExpandedSections({
        ...expandedSections,
        [section]: !expandedSections[section],
      });
    } catch (error) {
      console.error("Error toggling section:", error);
    }
  };

  return (
    <div className="w-full h-full bg-white dark:bg-gray-800 rounded-lg shadow-sm">
      {/* CSS for collapsed sidebar sections is in index.css */}
      
      {/* Filters section */}
      <div id="filters-section" className={`sidebar-section ${!expandedSections.filters ? 'collapsed' : ''} md:max-h-none border-b dark:border-gray-700`}>
        <div
          className="section-header flex justify-between items-center p-3 cursor-pointer"
          onClick={() => toggleSection('filters')}
        >
          <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100">Filtri</h2>
          {expandedSections.filters ? (
            <ChevronDown className="text-gray-500 dark:text-gray-400" />
          ) : (
            <ChevronRight className="text-gray-500 dark:text-gray-400" />
          )}
        </div>
        <div className="p-4 pt-0">
          <FilterSection filters={filters} setFilters={setFilters} />
        </div>
      </div>

      {/* Properties section */}
      <div id="properties-section" className={`sidebar-section ${!expandedSections.properties ? 'collapsed' : ''} md:max-h-none border-b dark:border-gray-700`}>
        <div
          className="section-header flex justify-between items-center p-3 cursor-pointer"
          onClick={() => toggleSection('properties')}
        >
          <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100">Proprietà</h2>
          <div className="flex items-center">
            <span className="text-sm text-gray-500 dark:text-gray-400 mr-2">{properties.length} trovate</span>
            {expandedSections.properties ? (
              <ChevronDown className="text-gray-500 dark:text-gray-400" />
            ) : (
              <ChevronRight className="text-gray-500 dark:text-gray-400" />
            )}
          </div>
        </div>

        <div className="p-4 pt-0 grid gap-4 property-list">
          {properties
            .filter(property => {
              // Filtra per tipo di annuncio se specificato
              if (filters.listingType && filters.listingType !== "all") {
                return property.listingType === filters.listingType;
              }
              return true;
            })
            .map((property) => (
              <PropertyCard
                key={property.id}
                property={property}
                onViewDetails={() => onViewProperty(property)}
              />
            ))
          }
          {properties.filter(p => 
            !filters.listingType || 
            filters.listingType === "all" || 
            p.listingType === filters.listingType
          ).length > 0 && (
            <div className="text-center py-3">
              <Button variant="outline" className="inline-flex items-center text-primary-700 bg-primary-100 hover:bg-primary-200">
                Carica Altro
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 ml-2"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                >
                  <path
                    fillRule="evenodd"
                    d="M16.707 10.293a1 1 0 010 1.414l-6 6a1 1 0 01-1.414 0l-6-6a1 1 0 111.414-1.414L9 14.586V3a1 1 0 012 0v11.586l4.293-4.293a1 1 0 011.414 0z"
                    clipRule="evenodd"
                  />
                </svg>
              </Button>
            </div>
          )}
          {properties.filter(p => 
            !filters.listingType || 
            filters.listingType === "all" || 
            p.listingType === filters.listingType
          ).length === 0 && (
            <div className="text-center py-6 text-gray-500">
              Nessuna proprietà trovata con i criteri selezionati.
            </div>
          )}
        </div>
      </div>

      {/* Professionals section */}
      <div id="professionals-section" className={`sidebar-section ${!expandedSections.professionals ? 'collapsed' : ''} md:max-h-none border-b dark:border-gray-700`}>
        <div
          className="section-header flex justify-between items-center p-3 cursor-pointer"
          onClick={() => toggleSection('professionals')}
        >
          <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100">Professionisti</h2>
          {expandedSections.professionals ? (
            <ChevronDown className="text-gray-500 dark:text-gray-400" />
          ) : (
            <ChevronRight className="text-gray-500 dark:text-gray-400" />
          )}
        </div>
        <div className="p-4 pt-0 space-y-4">
          {/* Architects */}
          <div>
            <h3 className="text-md font-medium text-gray-800 dark:text-gray-200 mb-2">Architetti</h3>
            <div className="space-y-3">
              {professionals
                .filter(p => p.type === 'architect')
                .map(professional => (
                  <ProfessionalCard
                    key={professional.id}
                    professional={professional}
                    onContact={() => onContactProfessional(professional)}
                  />
                ))
              }
            </div>
          </div>

          {/* Notaries */}
          <div>
            <h3 className="text-md font-medium text-gray-800 dark:text-gray-200 mb-2">Notai</h3>
            <div className="space-y-3">
              {professionals
                .filter(p => p.type === 'notary')
                .map(professional => (
                  <ProfessionalCard
                    key={professional.id}
                    professional={professional}
                    onContact={() => onContactProfessional(professional)}
                  />
                ))
              }
            </div>
          </div>

          {/* Artisans */}
          <div>
            <h3 className="text-md font-medium text-gray-800 dark:text-gray-200 mb-2">Artigiani</h3>
            <div className="space-y-3">
              {professionals
                .filter(p => p.type === 'artisan')
                .map(professional => (
                  <ProfessionalCard
                    key={professional.id}
                    professional={professional}
                    onContact={() => onContactProfessional(professional)}
                  />
                ))
              }
            </div>
          </div>
        </div>
      </div>

      {/* Banks section */}
      <div id="banks-section" className={`sidebar-section ${!expandedSections.banks ? 'collapsed' : ''} md:max-h-none`}>
        <div
          className="section-header flex justify-between items-center p-3 cursor-pointer"
          onClick={() => toggleSection('banks')}
        >
          <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100">Banche</h2>
          {expandedSections.banks ? (
            <ChevronDown className="text-gray-500 dark:text-gray-400" />
          ) : (
            <ChevronRight className="text-gray-500 dark:text-gray-400" />
          )}
        </div>
        <div className="p-4 pt-0 space-y-4">
          {banks.map(bank => (
            <BankCard
              key={bank.id}
              bank={bank}
              onContact={() => onContactBank(bank)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
