import { useState, useEffect, useRef } from 'react';
import { useLocation, Link } from 'wouter';
import { Map, FilmIcon, Plus, Tag, User } from 'lucide-react';

export default function MobileNavBar() {
  const [location] = useLocation();
  
  // Verifica quale pagina è attiva
  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 h-16 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 z-50">
      <div className="grid grid-cols-5 h-full">
        {/* Mappa */}
        <Link href="/" className={`flex flex-col items-center justify-center ${isActive('/') ? 'text-blue-600' : 'text-gray-600 dark:text-gray-400'}`}>
          <Map size={24} className={isActive('/') ? 'text-blue-600' : 'text-gray-600 dark:text-gray-400'} />
          <span className="text-xs mt-1">Mappa</span>
        </Link>
        
        {/* Booms */}
        <Link href="/booms" className={`flex flex-col items-center justify-center ${isActive('/booms') || isActive('/reels') ? 'text-blue-600' : 'text-gray-600 dark:text-gray-400'}`}>
          <FilmIcon size={24} className={isActive('/booms') || isActive('/reels') ? 'text-blue-600' : 'text-gray-600 dark:text-gray-400'} />
          <span className="text-xs mt-1">Booms</span>
        </Link>
        
        {/* Pubblica annuncio (bottone centrale) */}
        <Link href="/pubblica" className="relative flex flex-col items-center justify-center">
          <div className="absolute -top-6 bg-blue-600 rounded-full w-14 h-14 flex items-center justify-center shadow-lg">
            <Plus size={28} className="text-white" />
          </div>
          <span className="text-xs mt-7 text-gray-600 dark:text-gray-400">Pubblica</span>
        </Link>
        
        {/* Offerte */}
        <Link href="/offerte" className={`flex flex-col items-center justify-center ${isActive('/offerte') ? 'text-blue-600' : 'text-gray-600 dark:text-gray-400'}`}>
          <Tag size={24} className={isActive('/offerte') ? 'text-blue-600' : 'text-gray-600 dark:text-gray-400'} />
          <span className="text-xs mt-1">Offerte</span>
        </Link>
        
        {/* Account */}
        <Link href="/account" className={`flex flex-col items-center justify-center ${isActive('/account') ? 'text-blue-600' : 'text-gray-600 dark:text-gray-400'}`}>
          <User size={24} className={isActive('/account') ? 'text-blue-600' : 'text-gray-600 dark:text-gray-400'} />
          <span className="text-xs mt-1">Account</span>
        </Link>
      </div>
    </div>
  );
}