import { BankType } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Building2, ExternalLink } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface BankCardProps {
  bank: BankType;
  onContact: () => void;
}

export default function BankCard({ bank, onContact }: BankCardProps) {
  const handleOpenWebsite = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (bank.website) {
      window.open(bank.website, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l9-4 9 4m-9 4v10m-9-10v10m18-10v10M3 16l9 4 9-4" />
        </svg>
      </div>
      
      <div className="ml-4 flex-1">
        <div className="text-sm font-medium text-gray-900">{bank.name}</div>
        <div className="text-xs text-gray-500">{bank.address}</div>
      </div>
      
      <div className="flex items-center gap-2">
        {bank.website && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-blue-600 hover:text-blue-800 hover:bg-blue-50"
                  onClick={handleOpenWebsite}
                >
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Visita il sito web</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
        
        <Button 
          variant="outline" 
          size="sm"
          className="text-amber-700 bg-amber-100 hover:bg-amber-200 border-amber-200"
          onClick={onContact}
        >
          Contatta
        </Button>
      </div>
    </div>
  );
}
