import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import Home from "@/pages/Home";
import NotFound from "@/pages/not-found";
import ChatBot from "@/components/ChatBot";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import Professionisti from "@/pages/Professionisti";
import Banche from "@/pages/Banche";
import ChiSiamo from "@/pages/ChiSiamo";
import AuthPage from "@/pages/auth-page";
import TikTokView from "@/pages/TikTokView";
import PubblicaAnnuncio from "@/pages/PubblicaAnnuncio";
import Privacy from "@/pages/Privacy";
import Terms from "@/pages/Terms";
import Cookies from "@/pages/Cookies";
import Disclaimer from "@/pages/Disclaimer";
import Header from "@/components/Header";
import MobileNavBar from "@/components/MobileNavBar";
// Queste pagine verranno importate dinamicamente
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import { ThemeProvider } from "@/components/ThemeProvider";
import { useMobile } from "@/hooks/use-mobile";

function App() {
  // Utilizziamo l'hook per rilevare se siamo su mobile
  const isMobile = useMobile();

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="boomhouse-theme">
        <div className="min-h-screen bg-background text-foreground">
          <AuthProvider>
            {/* Aggiungiamo un padding-bottom su mobile per far spazio alla barra di navigazione */}
            <div className={isMobile ? "pb-16" : ""}>
              <Switch>
                <Route path="/" component={Home} />
                <Route path="/professionisti" component={Professionisti} />
                <Route path="/banche" component={Banche} />
                <Route path="/chi-siamo" component={ChiSiamo} />
                <Route path="/come-funziona">
                  {() => (
                    <div className="container mx-auto py-8">
                      <Header onOpenCalculator={() => console.log("No calculator available here")} />
                      <h1 className="text-2xl font-bold mb-4 mt-4">Come funziona</h1>
                      <p>Pagina in costruzione - Questa sezione spiegherà come funziona BoomHouse.</p>
                    </div>
                  )}
                </Route>
                <Route path="/recensioni">
                  {() => (
                    <div className="container mx-auto py-8">
                      <Header onOpenCalculator={() => console.log("No calculator available here")} />
                      <h1 className="text-2xl font-bold mb-4 mt-4">Recensioni</h1>
                      <p>Pagina in costruzione - Questa sezione mostrerà le recensioni degli utenti.</p>
                    </div>
                  )}
                </Route>
                <Route path="/contattaci">
                  {() => (
                    <div className="container mx-auto py-8">
                      <Header onOpenCalculator={() => console.log("No calculator available here")} />
                      <h1 className="text-2xl font-bold mb-4 mt-4">Contattaci</h1>
                      <p>Pagina in costruzione - Questa sezione permetterà di contattare BoomHouse.</p>
                    </div>
                  )}
                </Route>
                <Route path="/diventa-partner">
                  {() => (
                    <div className="container mx-auto py-8">
                      <Header onOpenCalculator={() => console.log("No calculator available here")} />
                      <h1 className="text-2xl font-bold mb-4 mt-4">Diventa Partner</h1>
                      <p>Pagina in costruzione - Questa sezione permetterà di diventare partner di BoomHouse.</p>
                    </div>
                  )}
                </Route>
                <Route path="/case-appartamenti">
                  {() => (
                    <div className="container mx-auto py-8">
                      <Header onOpenCalculator={() => console.log("No calculator available here")} />
                      <h1 className="text-2xl font-bold mb-4 mt-4">Case e Appartamenti</h1>
                      <p>Pagina in costruzione - Questa sezione mostrerà tutte le case e gli appartamenti disponibili.</p>
                    </div>
                  )}
                </Route>
                <Route path="/immobili-commerciali">
                  {() => (
                    <div className="container mx-auto py-8">
                      <Header onOpenCalculator={() => console.log("No calculator available here")} />
                      <h1 className="text-2xl font-bold mb-4 mt-4">Immobili Commerciali</h1>
                      <p>Pagina in costruzione - Questa sezione mostrerà tutti gli immobili commerciali disponibili.</p>
                    </div>
                  )}
                </Route>
                <Route path="/terreni">
                  {() => (
                    <div className="container mx-auto py-8">
                      <Header onOpenCalculator={() => console.log("No calculator available here")} />
                      <h1 className="text-2xl font-bold mb-4 mt-4">Terreni</h1>
                      <p>Pagina in costruzione - Questa sezione mostrerà tutti i terreni disponibili.</p>
                    </div>
                  )}
                </Route>
                <Route path="/inserisci-annuncio" component={PubblicaAnnuncio} />
                <Route path="/pubblica" component={PubblicaAnnuncio} />
                <Route path="/auth" component={AuthPage} />
                <Route path="/reels" component={TikTokView} />
                <Route path="/booms" component={TikTokView} />
                <Route path="/boom-reels" component={TikTokView} /> {/* Manteniamo anche il vecchio percorso per retrocompatibilità */}
                <Route path="/account">
                  {() => (
                    <div className="container mx-auto py-8">
                      <Header onOpenCalculator={() => console.log("No calculator available here")} />
                      <h1 className="text-2xl font-bold mb-4 mt-4">Il tuo account</h1>
                      <p>Pagina in costruzione - Questa sezione mostrerà tutte le informazioni del tuo profilo.</p>
                    </div>
                  )}
                </Route>
                <Route path="/offerte">
                  {() => (
                    <div className="container mx-auto py-8">
                      <Header onOpenCalculator={() => console.log("No calculator available here")} />
                      <h1 className="text-2xl font-bold mb-4 mt-4">Offerte</h1>
                      <p>Pagina in costruzione - Questa sezione mostrerà tutte le offerte speciali disponibili.</p>
                    </div>
                  )}
                </Route>
                {/* Pagine legali */}
                <Route path="/privacy" component={Privacy} />
                <Route path="/terms" component={Terms} />
                <Route path="/cookies" component={Cookies} />
                <Route path="/disclaimer" component={Disclaimer} />
                {/* Nota: abbiamo rimosso il ProtectedRoute per consentire l'accesso senza login */}
                <Route path="/preferiti">
                  {() => (
                    <div className="container mx-auto py-8">
                      <Header onOpenCalculator={() => console.log("No calculator available here")} />
                      <h1 className="text-2xl font-bold mb-4 mt-4">I tuoi preferiti</h1>
                      <p>Pagina in costruzione - Questa sezione mostrerà tutte le proprietà, i professionisti e le banche che hai aggiunto ai preferiti.</p>
                    </div>
                  )}
                </Route>
                <Route component={NotFound} />
              </Switch>
            </div>

            {/* Mostra la barra di navigazione mobile solo su dispositivi mobili */}
            {isMobile && <MobileNavBar />}
            
            <ChatBot />
          </AuthProvider>
          <Toaster />
        </div>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
