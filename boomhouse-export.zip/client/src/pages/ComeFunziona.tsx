import { Link } from "wouter";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";

export default function ComeFunziona() {
  // Funzione fittizia per il calcolo ipotecario (usata solo per il passaggio al componente Header)
  const openCalculator = () => {
    console.log("Questa funzione non fa nulla in questa pagina");
  };

  return (
    <>
      <Header onOpenCalculator={openCalculator} />
      <main className="container mx-auto py-10 px-4 md:px-6 lg:px-8 max-w-5xl">
        <h1 className="text-3xl font-bold text-primary mb-6">Come funziona BoomHouse</h1>
        
        <div className="space-y-8 mb-12">
          <section className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold mb-4">Trova la tua casa ideale</h2>
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
              BoomHouse ti permette di cercare immobili in tutta la Svizzera attraverso una mappa interattiva
              che integra dati catastali ufficiali. Puoi filtrare le ricerche per tipo di immobile, prezzo,
              superficie e molto altro ancora.
            </p>
            <div className="grid md:grid-cols-3 gap-6 my-8">
              <div className="bg-blue-50 dark:bg-blue-900/30 p-6 rounded-lg">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-800 rounded-full flex items-center justify-center mb-4">
                  <span className="text-blue-600 dark:text-blue-300 text-xl font-bold">1</span>
                </div>
                <h3 className="font-semibold mb-2">Cerca sulla mappa</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Esplora la mappa interattiva e trova immobili nella zona che preferisci
                </p>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/30 p-6 rounded-lg">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-800 rounded-full flex items-center justify-center mb-4">
                  <span className="text-blue-600 dark:text-blue-300 text-xl font-bold">2</span>
                </div>
                <h3 className="font-semibold mb-2">Filtra i risultati</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Usa i filtri avanzati per trovare esattamente ciò che stai cercando
                </p>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/30 p-6 rounded-lg">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-800 rounded-full flex items-center justify-center mb-4">
                  <span className="text-blue-600 dark:text-blue-300 text-xl font-bold">3</span>
                </div>
                <h3 className="font-semibold mb-2">Contatta i venditori</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Mettiti in contatto direttamente con i venditori o con le agenzie immobiliari
                </p>
              </div>
            </div>
          </section>
          
          <section className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold mb-4">Calcola la tua ipoteca</h2>
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
              Con il nostro calcolatore di ipoteche puoi immediatamente valutare quanto potresti ottenere in prestito 
              dalle banche svizzere e quali sarebbero le rate mensili. Basta inserire i dati relativi al reddito, 
              ai risparmi e al valore della proprietà.
            </p>
            <div className="bg-blue-50 dark:bg-blue-900/30 p-6 rounded-lg mt-4">
              <h3 className="font-semibold mb-3">Vantaggi del calcolatore ipotecario</h3>
              <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
                <li>Calcolo istantaneo basato sui tassi attuali del mercato svizzero</li>
                <li>Valutazione dei requisiti di reddito e capitale proprio</li>
                <li>Simulazione delle rate mensili e degli interessi</li>
                <li>Possibilità di scaricare il risultato in formato PDF</li>
              </ul>
            </div>
          </section>
          
          <section className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold mb-4">Professionisti del settore</h2>
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
              Su BoomHouse puoi trovare tutti i professionisti di cui hai bisogno per completare l'acquisto 
              o la vendita di una proprietà: architetti, notai, artigiani e banche, tutti mappati nella stessa 
              interfaccia facile da usare.
            </p>
            <div className="grid md:grid-cols-2 gap-4 mt-4">
              <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Architetti e progettisti</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Trova architetti nella zona dell'immobile per ristrutturazioni o nuove costruzioni
                </p>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Notai</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Contatta notai per gestire gli aspetti legali dell'acquisto o della vendita
                </p>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Artigiani e imprese edili</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Trova professionisti per lavori di ristrutturazione o manutenzione
                </p>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Banche e istituti di credito</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Confronta le offerte di istituti finanziari per il tuo mutuo ipotecario
                </p>
              </div>
            </div>
          </section>
        </div>
        
        <div className="text-center py-8">
          <h2 className="text-2xl font-bold mb-4">Pronto a trovare la tua nuova casa?</h2>
          <div className="flex flex-col sm:flex-row gap-3 justify-center mt-6">
            <Link href="/">
              <Button size="lg" className="w-full sm:w-auto">
                Cerca immobili
              </Button>
            </Link>
            <Link href="/professionisti">
              <Button variant="outline" size="lg" className="w-full sm:w-auto">
                Trova professionisti
              </Button>
            </Link>
          </div>
        </div>
      </main>
      
      {/* Footer semplice */}
      <footer className="bg-[#003580] text-white py-8 mt-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">BoomHouse</h3>
              <p className="text-sm text-[#b1c0da]">
                Il modo più intelligente per cercare immobili in Svizzera con dati catastali integrati.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Link utili</h3>
              <ul className="space-y-2 text-sm">
                <li><Link href="/chi-siamo"><a className="text-[#b1c0da] hover:text-white">Chi siamo</a></Link></li>
                <li><Link href="/come-funziona"><a className="text-[#b1c0da] hover:text-white">Come funziona</a></Link></li>
                <li><Link href="/boom-reels"><a className="text-[#b1c0da] hover:text-white">Boom Reels</a></Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Legale</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="/privacy" className="text-[#b1c0da] hover:text-white">Privacy</a></li>
                <li><a href="/terms" className="text-[#b1c0da] hover:text-white">Termini e condizioni</a></li>
                <li><a href="/cookies" className="text-[#b1c0da] hover:text-white">Cookie</a></li>
                <li><a href="/disclaimer" className="text-[#b1c0da] hover:text-white">Disclaimer</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contatti</h3>
              <ul className="space-y-2 text-sm">
                <li className="text-[#b1c0da]">Email: info@boomhouse.ch</li>
                <li className="text-[#b1c0da]">Tel: +41 12 345 67 89</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-6 border-t border-[#1A4A8E] text-center text-sm text-[#b1c0da]">
            © {new Date().getFullYear()} BoomHouse. Tutti i diritti riservati.
          </div>
        </div>
      </footer>
    </>
  );
}