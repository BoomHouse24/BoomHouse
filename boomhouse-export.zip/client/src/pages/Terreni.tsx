import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { PropertyType } from "@/lib/types";
import { Ruler, MapPin, Trees, Mountain } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Terreni() {
  const { toast } = useToast();
  const [filterType, setFilterType] = useState<string>("all");
  
  // Funzione per il calcolo ipotecario
  const openCalculator = () => {
    toast({
      title: "Calcolatore non disponibile",
      description: "Il calcolatore ipotecario è disponibile nella home page.",
    });
  };

  // Fetch delle proprietà - filtrando solo terreni
  const { data: properties = [], isLoading } = useQuery<PropertyType[]>({
    queryKey: ['/api/properties', { propertyType: 'land' }],
    queryFn: async () => {
      const response = await fetch(`/api/properties?propertyType=land`);
      if (!response.ok) {
        throw new Error('Failed to fetch properties');
      }
      return response.json();
    }
  });

  // Filtra ulteriormente per tipo (vendita/affitto) se necessario
  const filteredProperties = filterType === "all" 
    ? properties 
    : properties.filter(p => p.listingType === filterType);

  return (
    <>
      <Header onOpenCalculator={openCalculator} />
      <main className="container mx-auto py-10 px-4 md:px-6">
        <div className="flex flex-col items-start mb-8">
          <h1 className="text-3xl font-bold text-primary mb-4">Terreni</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-3xl">
            Esplora la nostra selezione di terreni edificabili e agricoli in tutta la Svizzera.
            Trova il terreno perfetto per il tuo progetto o investimento.
          </p>
          
          <div className="flex flex-wrap gap-3 mb-6">
            <Button 
              variant={filterType === "all" ? "default" : "outline"} 
              onClick={() => setFilterType("all")}
            >
              Tutti
            </Button>
            <Button 
              variant={filterType === "For Sale" ? "default" : "outline"} 
              onClick={() => setFilterType("For Sale")}
            >
              In vendita
            </Button>
            <Button 
              variant={filterType === "For Rent" ? "default" : "outline"} 
              onClick={() => setFilterType("For Rent")}
            >
              In affitto
            </Button>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        ) : filteredProperties.length === 0 ? (
          <div className="text-center py-16">
            <Mountain className="h-16 w-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-medium mb-2">Nessun terreno trovato</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Non ci sono attualmente terreni disponibili con questi criteri.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProperties.map((property) => (
              <Card key={property.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <div className="relative h-48">
                  <img 
                    src={property.imageUrl} 
                    alt={property.title} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 right-2">
                    <div className={`px-2 py-1 text-xs font-medium text-white rounded ${
                      property.listingType === "For Sale" ? "bg-blue-600" : "bg-green-600"
                    }`}>
                      {property.listingType === "For Sale" ? "Vendita" : "Affitto"}
                    </div>
                  </div>
                </div>
                
                <CardContent className="p-4">
                  <h3 className="font-semibold text-lg mb-1 line-clamp-1">{property.title}</h3>
                  <div className="flex items-center text-gray-600 dark:text-gray-400 text-sm mb-3">
                    <MapPin className="h-3.5 w-3.5 mr-1" />
                    <span className="line-clamp-1">{property.address}</span>
                  </div>
                  
                  <p className="font-medium text-lg mb-3">{property.price}</p>
                  
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    {property.area && (
                      <div className="flex items-center">
                        <Ruler className="h-4 w-4 mr-1 text-gray-500" />
                        <span>{property.area} m²</span>
                      </div>
                    )}
                    
                    {property.type && (
                      <div className="flex items-center">
                        <Trees className="h-4 w-4 mr-1 text-gray-500" />
                        <span>{property.type}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
                
                <CardFooter className="p-4 pt-0">
                  <Button className="w-full" variant="outline">
                    Visualizza dettagli
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </main>
      
      {/* Footer */}
      <footer className="bg-[#003580] text-white py-8 mt-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">BoomHouse</h3>
              <p className="text-sm text-[#b1c0da]">
                Il modo più intelligente per cercare immobili in Svizzera con dati catastali integrati.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Link utili</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="/chi-siamo" className="text-[#b1c0da] hover:text-white">Chi siamo</a></li>
                <li><a href="/come-funziona" className="text-[#b1c0da] hover:text-white">Come funziona</a></li>
                <li><a href="/boom-reels" className="text-[#b1c0da] hover:text-white">Boom Reels</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Legale</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="/privacy" className="text-[#b1c0da] hover:text-white">Privacy</a></li>
                <li><a href="/terms" className="text-[#b1c0da] hover:text-white">Termini e condizioni</a></li>
                <li><a href="/cookies" className="text-[#b1c0da] hover:text-white">Cookie</a></li>
                <li><a href="/disclaimer" className="text-[#b1c0da] hover:text-white">Disclaimer</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contatti</h3>
              <ul className="space-y-2 text-sm">
                <li className="text-[#b1c0da]">Email: info@boomhouse.ch</li>
                <li className="text-[#b1c0da]">Tel: +41 12 345 67 89</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-6 border-t border-[#1A4A8E] text-center text-sm text-[#b1c0da]">
            © {new Date().getFullYear()} BoomHouse. Tutti i diritti riservati.
          </div>
        </div>
      </footer>
    </>
  );
}