import { useState, useEffect, lazy, Suspense } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import PropertyDetailModal from "@/components/PropertyDetailModal";
import MortgageCalculator from "@/components/MortgageCalculator";
import PropertiesView from "@/components/PropertiesView";
import SideMenu from "@/components/SideMenu";
import SearchBar from "@/components/SearchBar";
import { PropertyType, ProfessionalType, BankType, FilterType, ListingType } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";

// Lazy load the Map component to avoid issues with Leaflet
const Map = lazy(() => import("@/components/SimpleReactMap"));

export default function Home() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [mobileFiltersVisible, setMobileFiltersVisible] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState<PropertyType | null>(null);
  const [isPropertyModalOpen, setIsPropertyModalOpen] = useState(false);
  const [isMortgageCalculatorOpen, setIsMortgageCalculatorOpen] = useState(false);
  const [filters, setFilters] = useState<FilterType>({
    searchQuery: "",
    propertyType: "all",
    location: "all",
    postalCode: "",
    minPrice: undefined,
    maxPrice: undefined,
    features: [],
    professionalType: "all",
    // Filtri catastali
    cadastralNumber: undefined,
    cadastralZone: undefined,
    cadastralSection: undefined,
    cadastralFolio: undefined,
    cadastralParcel: undefined,
    minBuildingIndex: undefined,
    maxBuildingIndex: undefined,
    minBuildingHeight: undefined,
    maxBuildingHeight: undefined,
    zoning: undefined,
    showCadastralOnly: false,
  });

  // Fetch properties - usiamo una cache stabile per evitare problemi di rendering
  const {
    data: properties = [],
    isLoading: isLoadingProperties,
    error: propertiesError,
  } = useQuery<PropertyType[]>({
    queryKey: ['/api/properties'],
    queryFn: async () => {
      const searchParams = new URLSearchParams();
      
      if (filters.searchQuery) {
        searchParams.append('searchQuery', filters.searchQuery);
      }
      
      if (filters.propertyType && filters.propertyType !== 'all') {
        searchParams.append('propertyType', filters.propertyType);
      }
      
      if (filters.location && filters.location !== 'all') {
        searchParams.append('location', filters.location);
      }
      
      if (filters.postalCode) {
        searchParams.append('postalCode', filters.postalCode);
      }
      
      if (filters.minPrice) {
        searchParams.append('minPrice', filters.minPrice.toString());
      }
      
      if (filters.maxPrice) {
        searchParams.append('maxPrice', filters.maxPrice.toString());
      }
      
      if (filters.features && filters.features.length > 0) {
        filters.features.forEach(feature => {
          searchParams.append('features', feature);
        });
      }
      
      // Aggiungi parametri per i filtri catastali
      if (filters.cadastralNumber) {
        searchParams.append('cadastralNumber', filters.cadastralNumber);
      }
      
      if (filters.cadastralZone) {
        searchParams.append('cadastralZone', filters.cadastralZone);
      }
      
      if (filters.cadastralSection) {
        searchParams.append('cadastralSection', filters.cadastralSection);
      }
      
      if (filters.cadastralFolio) {
        searchParams.append('cadastralFolio', filters.cadastralFolio);
      }
      
      if (filters.cadastralParcel) {
        searchParams.append('cadastralParcel', filters.cadastralParcel);
      }
      
      if (filters.minBuildingIndex !== undefined) {
        searchParams.append('minBuildingIndex', filters.minBuildingIndex.toString());
      }
      
      if (filters.maxBuildingIndex !== undefined) {
        searchParams.append('maxBuildingIndex', filters.maxBuildingIndex.toString());
      }
      
      if (filters.minBuildingHeight !== undefined) {
        searchParams.append('minBuildingHeight', filters.minBuildingHeight.toString());
      }
      
      if (filters.maxBuildingHeight !== undefined) {
        searchParams.append('maxBuildingHeight', filters.maxBuildingHeight.toString());
      }
      
      if (filters.zoning) {
        searchParams.append('zoning', filters.zoning);
      }
      
      if (filters.showCadastralOnly) {
        searchParams.append('showCadastralOnly', 'true');
      }
      
      const url = `/api/properties${searchParams.toString() ? `?${searchParams.toString()}` : ''}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error('Failed to fetch properties');
      }
      
      return response.json();
    }
  });

  // Fetch professionals
  const {
    data: professionals = [],
    isLoading: isLoadingProfessionals,
    error: professionalsError,
  } = useQuery<ProfessionalType[]>({
    queryKey: ['/api/professionals'],
    queryFn: async () => {
      const searchParams = new URLSearchParams();
      
      if (filters.searchQuery) {
        searchParams.append('searchQuery', filters.searchQuery);
      }
      
      if (filters.location && filters.location !== 'all') {
        searchParams.append('location', filters.location);
      }
      
      if (filters.postalCode) {
        searchParams.append('postalCode', filters.postalCode);
      }
      
      if (filters.professionalType && filters.professionalType !== 'all') {
        searchParams.append('type', filters.professionalType);
      }
      
      const url = `/api/professionals${searchParams.toString() ? `?${searchParams.toString()}` : ''}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error('Failed to fetch professionals');
      }
      
      return response.json();
    }
  });

  // Fetch banks
  const {
    data: banks = [],
    isLoading: isLoadingBanks,
    error: banksError,
  } = useQuery<BankType[]>({
    queryKey: ['/api/banks'],
    queryFn: async () => {
      const searchParams = new URLSearchParams();
      
      if (filters.searchQuery) {
        searchParams.append('searchQuery', filters.searchQuery);
      }
      
      if (filters.location && filters.location !== 'all') {
        searchParams.append('location', filters.location);
      }
      
      if (filters.postalCode) {
        searchParams.append('postalCode', filters.postalCode);
      }
      
      const url = `/api/banks${searchParams.toString() ? `?${searchParams.toString()}` : ''}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error('Failed to fetch banks');
      }
      
      return response.json();
    }
  });

  // Effetto per ricaricare le query quando cambiano i filtri
  useEffect(() => {
    // Ricarica le query quando i filtri cambiano
    queryClient.invalidateQueries({ queryKey: ['/api/properties'] });
    queryClient.invalidateQueries({ queryKey: ['/api/professionals'] });
    queryClient.invalidateQueries({ queryKey: ['/api/banks'] });
  }, [filters, queryClient]);
  
  // Gestione errori di caricamento
  useEffect(() => {
    if (propertiesError) {
      toast({
        title: "Error loading properties",
        description: "Please try again later.",
        variant: "destructive",
      });
    }
    if (professionalsError) {
      toast({
        title: "Error loading professionals",
        description: "Please try again later.",
        variant: "destructive",
      });
    }
    if (banksError) {
      toast({
        title: "Error loading banks",
        description: "Please try again later.",
        variant: "destructive",
      });
    }
  }, [propertiesError, professionalsError, banksError, toast]);

  const handleViewProperty = (property: PropertyType) => {
    setSelectedProperty(property);
    setIsPropertyModalOpen(true);
  };

  const handleContactProfessional = (professional: ProfessionalType) => {
    toast({
      title: `Contact request sent to ${professional.name}`,
      description: "They will contact you shortly.",
    });
  };

  const handleContactBank = (bank: BankType) => {
    toast({
      title: `Contact request sent to ${bank.name}`,
      description: "They will contact you shortly.",
    });
  };

  const handleMarkerClick = (item: PropertyType | ProfessionalType | BankType, type: ListingType) => {
    if (type === "property") {
      handleViewProperty(item as PropertyType);
    } else if (type === "professional") {
      handleContactProfessional(item as ProfessionalType);
    } else if (type === "bank") {
      handleContactBank(item as BankType);
    }
  };

  // Loading state
  if (isLoadingProperties || isLoadingProfessionals || isLoadingBanks) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-gray-600">Caricamento dati BoomHouse...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Header onOpenCalculator={() => setIsMortgageCalculatorOpen(true)} />
      <main className="w-full mx-auto relative">
        {/* Hero Bar - Stile Booking.com */}
        <div className="bg-[#003580] py-4 px-4 md:px-8 shadow-md">
          <div className="max-w-screen-2xl mx-auto">
            <h1 className="text-white text-xl md:text-2xl font-bold mb-3">Trova la tua casa ideale in Svizzera</h1>
            <SearchBar 
                filters={filters} 
                onFiltersChange={(newFilters) => {
                  // Applica i nuovi filtri
                  setFilters(newFilters);
                }} 
                onSearchClick={() => {
                  // Invalidate query cache to trigger data reload with new filters
                  queryClient.invalidateQueries({ queryKey: ['/api/properties'] });
                  queryClient.invalidateQueries({ queryKey: ['/api/professionals'] });
                  queryClient.invalidateQueries({ queryKey: ['/api/banks'] });
                  
                  // Show/hide filters panel
                  setMobileFiltersVisible(!mobileFiltersVisible);
                }} 
              />
          </div>
        </div>
        
        {/* Rimossi i banner di Pubblica Annuncio e Boom Reels, ora disponibili nella barra di navigazione mobile */}

        {/* Main content container */}
        <div className="max-w-screen-2xl mx-auto px-2 sm:px-4 lg:px-6 py-4 flex flex-col md:flex-row gap-4">
          {/* Sidebar filtri (versione desktop e mobile) */}
          <div 
            className={`${
              mobileFiltersVisible ? 'block' : 'hidden md:block'
            } md:w-1/4 lg:w-1/5 md:min-w-[280px] bg-white rounded-lg shadow-md p-4 overflow-y-auto max-h-[calc(100vh-220px)]`}
          >
            <Sidebar
              properties={properties}
              professionals={professionals}
              banks={banks}
              onViewProperty={handleViewProperty}
              onContactProfessional={handleContactProfessional}
              onContactBank={handleContactBank}
              filters={filters}
              setFilters={setFilters}
            />
          </div>

          {/* Main content area with map and property listings */}
          <div className={`${mobileFiltersVisible ? 'hidden md:flex' : 'flex'} flex-1 flex-col gap-4`}>
            {/* Stats bar - Stile Booking */}
            <div className="bg-[#f5f5f5] border border-[#e7e7e7] rounded-none p-3 flex justify-between items-center">
              <div className="text-sm md:text-base text-[#262626]">
                <span className="font-semibold text-[#003580]">{properties.length}</span> immobili trovati
                {filters.listingType === "In Vendita" && " in vendita"}
                {filters.listingType === "In Affitto" && " in affitto"}
                {filters.location !== "all" && ` a ${filters.location}`}
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="hidden md:flex items-center border-[#0071c2] text-[#0071c2] hover:bg-[#f2f8fc]"
                  onClick={() => setFilters({
                    searchQuery: "",
                    propertyType: "all",
                    location: "all",
                    minPrice: undefined,
                    maxPrice: undefined,
                    features: [],
                    professionalType: "all",
                    listingType: "all",
                    cadastralNumber: undefined,
                    cadastralZone: undefined,
                    cadastralSection: undefined,
                    cadastralFolio: undefined,
                    cadastralParcel: undefined,
                    minBuildingIndex: undefined,
                    maxBuildingIndex: undefined,
                    minBuildingHeight: undefined,
                    maxBuildingHeight: undefined,
                    zoning: undefined,
                    showCadastralOnly: false,
                  })}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10" />
                    <path d="M8 12h8" />
                    <path d="M12 8v8" />
                  </svg>
                  Azzera filtri
                </Button>
              </div>
            </div>
            
            {/* Map - Now as the main feature */}
            <div className="bg-white rounded-none border border-[#e7e7e7] overflow-hidden h-[420px] md:h-[520px]">
              <Suspense fallback={
                <div className="h-full flex items-center justify-center bg-gray-100">
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#0071c2] mx-auto"></div>
                    <p className="mt-4 text-gray-600">Caricamento mappa...</p>
                  </div>
                </div>
              }>
                <Map
                  properties={properties}
                  professionals={professionals}
                  banks={banks}
                  onMarkerClick={handleMarkerClick}
                  onOpenCalculator={() => setIsMortgageCalculatorOpen(true)}
                />
              </Suspense>
            </div>
            
            {/* Property listings with vertical scrolling option */}
            <div className="p-0 bg-transparent">
              <PropertiesView 
                properties={properties}
                onViewDetails={handleViewProperty}
              />
              
              {properties.length > 6 && (
                <div className="mt-6 mb-2 text-center">
                  <Button className="bg-[#0071c2] hover:bg-[#00487a] text-white px-8 py-3 text-sm font-medium" onClick={() => setMobileFiltersVisible(true)}>
                    Mostra tutti gli immobili ({properties.length})
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Footer - Stile Booking */}
        <div className="bg-[#00224f] text-white py-8 mt-8">
          <div className="max-w-screen-2xl mx-auto px-4 md:px-8">
            {/* Sezione banner newsletter */}
            <div className="mb-12 bg-[#00224f] rounded-sm p-6 border border-[#174e8a]">
              <h3 className="text-2xl font-bold mb-3 text-white">Ricevi notifiche sugli immobili</h3>
              <p className="text-[#b1c0da] mb-6">Iscriviti alla newsletter per ricevere offerte esclusive e nuove proposte immobiliari</p>
              <div className="flex flex-col md:flex-row gap-3">
                <input 
                  type="email" 
                  placeholder="Il tuo indirizzo email" 
                  className="flex-1 py-3 px-4 text-black rounded-sm border-none focus:outline-none focus:ring-2 focus:ring-[#0071c2]"
                />
                <button className="bg-[#0071c2] hover:bg-[#00487a] text-white py-3 px-6 rounded-sm font-bold">
                  Iscriviti
                </button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div>
                <h3 className="text-base font-bold mb-6 uppercase tracking-wide text-white">BoomHouse</h3>
                <ul className="space-y-3">
                  <li className="text-[#b1c0da] hover:text-white cursor-pointer">Chi siamo</li>
                  <li className="text-[#b1c0da] hover:text-white cursor-pointer">Come funziona</li>
                  <li className="text-[#b1c0da] hover:text-white cursor-pointer">Recensioni</li>
                  <li className="text-[#b1c0da] hover:text-white cursor-pointer">Contattaci</li>
                  <li className="text-[#b1c0da] hover:text-white cursor-pointer">Diventa partner</li>
                </ul>
              </div>
              <div>
                <h3 className="text-base font-bold mb-6 uppercase tracking-wide text-white">Immobili</h3>
                <ul className="space-y-3">
                  <li className="text-[#b1c0da] hover:text-white cursor-pointer">Case e appartamenti</li>
                  <li className="text-[#b1c0da] hover:text-white cursor-pointer">Immobili commerciali</li>
                  <li className="text-[#b1c0da] hover:text-white cursor-pointer">Terreni</li>
                  <li className="text-[#b1c0da] hover:text-white cursor-pointer">Annunci più visualizzati</li>
                  <li className="text-[#b1c0da] hover:text-white cursor-pointer">Inserisci un annuncio</li>
                </ul>
              </div>
              <div>
                <h3 className="text-base font-bold mb-6 uppercase tracking-wide text-white">Servizi</h3>
                <ul className="space-y-3">
                  <li className="text-[#b1c0da] hover:text-white cursor-pointer">Calcolo ipoteca</li>
                  <li className="text-[#b1c0da] hover:text-white cursor-pointer">Professionisti</li>
                  <li className="text-[#b1c0da] hover:text-white cursor-pointer">Banche partner</li>
                  <li className="text-[#b1c0da] hover:text-white cursor-pointer">Consulenza immobiliare</li>
                  <li className="text-[#b1c0da] hover:text-white cursor-pointer">Estratti catastali</li>
                </ul>
              </div>
              <div>
                <h3 className="text-base font-bold mb-6 uppercase tracking-wide text-white">Contatti</h3>
                <ul className="space-y-3">
                  <li className="text-[#b1c0da]">
                    <span className="font-semibold block">Email:</span>
                    info@boomhouse.ch
                  </li>
                  <li className="text-[#b1c0da]">
                    <span className="font-semibold block">Telefono:</span>
                    +41 91 000 00 00
                  </li>
                  <li className="text-[#b1c0da]">
                    <span className="font-semibold block">Indirizzo:</span>
                    Via Nassa 1, 6900 Lugano, Svizzera
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="mt-12 pt-8 border-t border-[#174e8a] flex flex-col md:flex-row justify-between items-center">
              <div className="mb-4 md:mb-0">
                <p className="text-sm text-[#b1c0da]">
                  © {new Date().getFullYear()} BoomHouse. Tutti i diritti riservati.
                </p>
              </div>
              <div className="flex space-x-6">
                <a href="/privacy" className="text-[#b1c0da] hover:text-white text-sm">Privacy</a>
                <a href="/terms" className="text-[#b1c0da] hover:text-white text-sm">Termini e condizioni</a>
                <a href="/cookies" className="text-[#b1c0da] hover:text-white text-sm">Cookie</a>
                <a href="/disclaimer" className="text-[#b1c0da] hover:text-white text-sm">Disclaimer</a>
              </div>
            </div>
          </div>
        </div>
        {/* Footer */}
        <footer className="bg-[#003580] text-white pt-12 pb-8 mt-12 border-t border-gray-200">
          <div className="container mx-auto px-4">
            
            {/* Servizi Principali */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
              {/* Boom Reels */}
              <div className="bg-[#0071c2] rounded-lg overflow-hidden shadow-lg">
                <div className="p-4">
                  <div className="flex items-center mb-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-white"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                    <h3 className="font-semibold text-white">Boom Reels</h3>
                  </div>
                  <p className="text-sm text-blue-100 mb-4">Scopri le proprietà in un modo completamente nuovo</p>
                  <a href="/boom-reels" className="inline-flex items-center justify-center bg-white hover:bg-gray-100 text-[#0071c2] w-10 h-10 rounded-full shadow-sm transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polygon points="5 3 19 12 5 21 5 3"></polygon>
                    </svg>
                  </a>
                </div>
              </div>
              
              {/* Calcolo Ipoteca */}
              <div className="bg-[#0071c2] rounded-lg overflow-hidden shadow-lg">
                <div className="p-4">
                  <div className="flex items-center mb-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-white"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                    <h3 className="font-semibold text-white">Calcolo Ipoteca</h3>
                  </div>
                  <p className="text-sm text-blue-100 mb-4">Calcola il tuo mutuo ipotecario in pochi click</p>
                  <button onClick={() => setIsMortgageCalculatorOpen(true)} className="inline-block bg-white hover:bg-gray-100 text-[#0071c2] px-4 py-2 rounded text-sm font-semibold transition-colors">
                    Calcola
                  </button>
                </div>
              </div>
              
              {/* Mappa Immobiliare */}
              <div className="bg-[#0071c2] rounded-lg overflow-hidden shadow-lg">
                <div className="p-4">
                  <div className="flex items-center mb-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-white"><circle cx="12" cy="10" r="3"></circle><path d="M12 21.7C17.3 17 20 13 20 10a8 8 0 1 0-16 0c0 3 2.7 6.9 8 11.7z"></path></svg>
                    <h3 className="font-semibold text-white">Mappa</h3>
                  </div>
                  <p className="text-sm text-blue-100 mb-4">Esplora le proprietà sulla mappa interattiva</p>
                  <a href="/searchable_map.html" target="_blank" className="inline-block bg-white hover:bg-gray-100 text-[#0071c2] px-4 py-2 rounded text-sm font-semibold transition-colors">
                    Apri mappa
                  </a>
                </div>
              </div>
              
              {/* Pubblicazione */}
              <div className="bg-[#0071c2] rounded-lg overflow-hidden shadow-lg">
                <div className="p-4">
                  <div className="flex items-center mb-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-white"><path d="M12 5v14"></path><path d="M5 12h14"></path></svg>
                    <h3 className="font-semibold text-white">Pubblicazione</h3>
                  </div>
                  <p className="text-sm text-blue-100 mb-4">Pubblica il tuo annuncio immobiliare</p>
                  <a href="/inserisci-annuncio" className="inline-block bg-white hover:bg-gray-100 text-[#0071c2] px-4 py-2 rounded text-sm font-semibold transition-colors">
                    Pubblica
                  </a>
                </div>
              </div>
            </div>
            
            {/* Footer Links */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
              <div>
                <h3 className="text-lg font-semibold mb-4 border-b border-blue-700 pb-2">BoomHouse</h3>
                <p className="mb-4 text-blue-100">La piattaforma immobiliare svizzera che trasforma la ricerca di proprietà attraverso la visualizzazione intelligente dei dati.</p>
                <p className="text-blue-200 text-sm">immoscout24.ch</p>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-4 border-b border-blue-700 pb-2">Link Utili</h3>
                <ul className="space-y-2">
                  <li><a href="/chi-siamo" className="text-blue-100 hover:text-white flex items-center transition-colors"><span className="mr-2 text-white">›</span>Chi Siamo</a></li>
                  <li><a href="/come-funziona" className="text-blue-100 hover:text-white flex items-center transition-colors"><span className="mr-2 text-white">›</span>Come Funziona</a></li>
                  <li><a href="/recensioni" className="text-blue-100 hover:text-white flex items-center transition-colors"><span className="mr-2 text-white">›</span>Recensioni</a></li>
                  <li><a href="/contattaci" className="text-blue-100 hover:text-white flex items-center transition-colors"><span className="mr-2 text-white">›</span>Contattaci</a></li>
                  <li><a href="/diventa-partner" className="text-blue-100 hover:text-white flex items-center transition-colors"><span className="mr-2 text-white">›</span>Diventa Partner</a></li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-4 border-b border-blue-700 pb-2">Immobili</h3>
                <ul className="space-y-2">
                  <li><a href="/case-appartamenti" className="text-blue-100 hover:text-white flex items-center transition-colors"><span className="mr-2 text-white">›</span>Case e Appartamenti</a></li>
                  <li><a href="/immobili-commerciali" className="text-blue-100 hover:text-white flex items-center transition-colors"><span className="mr-2 text-white">›</span>Immobili Commerciali</a></li>
                  <li><a href="/terreni" className="text-blue-100 hover:text-white flex items-center transition-colors"><span className="mr-2 text-white">›</span>Terreni</a></li>
                  <li><a href="/inserisci-annuncio" className="text-blue-100 hover:text-white flex items-center transition-colors"><span className="mr-2 text-white">›</span>Inserisci Annuncio</a></li>
                  <li><a href="/stima" className="text-blue-100 hover:text-white flex items-center transition-colors"><span className="mr-2 text-white">›</span>Stima Immobiliare</a></li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-4 border-b border-blue-700 pb-2">Note Legali</h3>
                <ul className="space-y-2">
                  <li><a href="/privacy" className="text-blue-100 hover:text-white flex items-center transition-colors"><span className="mr-2 text-white">›</span>Privacy Policy</a></li>
                  <li><a href="/terms" className="text-blue-100 hover:text-white flex items-center transition-colors"><span className="mr-2 text-white">›</span>Termini e Condizioni</a></li>
                  <li><a href="/cookies" className="text-blue-100 hover:text-white flex items-center transition-colors"><span className="mr-2 text-white">›</span>Cookie Policy</a></li>
                  <li><a href="/disclaimer" className="text-blue-100 hover:text-white flex items-center transition-colors"><span className="mr-2 text-white">›</span>Disclaimer</a></li>
                </ul>
              </div>
            </div>
            
            <div className="border-t border-blue-700 mt-10 pt-8 text-center">
              <p className="text-blue-100">&copy; {new Date().getFullYear()} BoomHouse. Tutti i diritti riservati.</p>
            </div>
          </div>
        </footer>
      </main>

      <PropertyDetailModal
        property={selectedProperty}
        isOpen={isPropertyModalOpen}
        onClose={() => setIsPropertyModalOpen(false)}
      />
      
      <MortgageCalculator
        isOpen={isMortgageCalculatorOpen}
        onClose={() => setIsMortgageCalculatorOpen(false)}
        properties={properties}
        banks={banks}
      />
    </>
  );
}
