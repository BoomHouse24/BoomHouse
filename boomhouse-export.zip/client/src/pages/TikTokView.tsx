import { useState, useRef, useEffect, useMemo, memo } from 'react';
import { useQuery } from "@tanstack/react-query";
import { MapPin, Loader2, Ban, X, Volume2, VolumeX, Plus, Camera, Check, Music } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { PropertyType } from '@/lib/types';
import PropertyDetailModal from '@/components/PropertyDetailModal';
import { useToast } from '@/hooks/use-toast';

// Array di tracce audio di sottofondo
const backgroundTracks = [
  {
    id: 1,
    name: "Musica Lounge",
    url: "https://storage.googleapis.com/media-session/sintel/snowflake.mp3"
  },
  {
    id: 2,
    name: "Musica Relax",
    url: "https://storage.googleapis.com/media-session/big-buck-bunny/big-buck-bunny.mp3"
  },
  {
    id: 3,
    name: "Jazz Moderno",
    url: "https://storage.googleapis.com/media-session/sintel/snowflake.mp3"
  }
];

// Componente ottimizzato per la slide di proprietà
const PropertySlide = memo(({ 
  property, 
  isActive, 
  onClick,
  currentTrack,
  isMuted
}: { 
  property: PropertyType; 
  isActive: boolean; 
  onClick: () => void;
  currentTrack: number;
  isMuted: boolean;
}) => {
  return (
    <div 
      className="absolute top-0 left-0 w-full h-full"
      style={{ 
        transform: 'translateY(0%)',
        visibility: isActive ? 'visible' : 'hidden' 
      }}
      onClick={onClick}
    >
      {/* Property Background Image */}
      <div className="absolute inset-0">
        <img 
          src={property.imageUrl} 
          alt={property.title} 
          className="w-full h-full object-cover"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/80"></div>
      </div>
      
      {/* Audio Player (nascosto) */}
      {isActive && !isMuted && (
        <audio 
          src={backgroundTracks[currentTrack % backgroundTracks.length].url} 
          autoPlay
          loop 
          className="hidden"
        />
      )}
      
      {/* Etichetta vendita/affitto */}
      <div className="absolute top-24 right-4 z-10">
        <div className={`px-4 py-2 rounded-md text-white font-medium ${property.listingType === "For Sale" ? "bg-blue-600" : "bg-green-600"}`}>
          {property.listingType === "For Sale" ? "Vendita" : "Affitto"}
        </div>
      </div>
      
      {/* Main content - versione semplificata */}
      <div className="absolute bottom-0 left-0 right-0 p-6 z-10 bg-gradient-to-t from-black to-transparent pt-16">
        <div className="mb-4">
          <h3 className="text-white text-3xl font-bold drop-shadow-lg mb-2">{property.title}</h3>
          <p className="text-white/90 text-lg font-medium drop-shadow-md">{property.price}</p>
          <div className="flex items-center text-white/80 mt-2">
            <MapPin size={16} className="mr-1" />
            <span className="text-sm">{property.address}</span>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-2 mb-4">
          {property.beds && (
            <div className="bg-white/10 backdrop-blur-sm px-2 py-2 rounded text-center">
              <div className="text-white font-medium">{property.beds}</div>
              <div className="text-white/70 text-xs">locali</div>
            </div>
          )}
          
          {property.baths && (
            <div className="bg-white/10 backdrop-blur-sm px-2 py-2 rounded text-center">
              <div className="text-white font-medium">{property.baths}</div>
              <div className="text-white/70 text-xs">bagni</div>
            </div>
          )}
          
          <div className="bg-white/10 backdrop-blur-sm px-2 py-2 rounded text-center">
            <div className="text-white font-medium">{property.area}</div>
            <div className="text-white/70 text-xs">m²</div>
          </div>
        </div>
        
        {/* Bottone dettagli integrato */}
        <button 
          className="w-full bg-white/20 backdrop-blur-md hover:bg-white/30 border border-white/40 text-white py-3 rounded-md font-medium"
          onClick={(e) => { e.stopPropagation(); onClick(); }}
        >
          Mostra dettagli immobile
        </button>
      </div>
    </div>
  );
});

PropertySlide.displayName = 'PropertySlide';

// Componente per la creazione di un nuovo Boom Reel
const CreateReelModal = memo(({ 
  isOpen, 
  onClose,
  onSave
}: { 
  isOpen: boolean; 
  onClose: () => void;
  onSave: (videoBlob: Blob, selectedTrack: number) => void;
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [selectedTrack, setSelectedTrack] = useState(0);
  const [recordingTime, setRecordingTime] = useState(0);
  const [recordedVideo, setRecordedVideo] = useState<Blob | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunks = useRef<BlobPart[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const maxRecordingSeconds = 60; // 1 minuto

  // Inizializza la fotocamera
  useEffect(() => {
    if (isOpen) {
      const startCamera = async () => {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: "environment" }, 
            audio: true 
          });
          
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
          
          streamRef.current = stream;
        } catch (err) {
          console.error("Errore nell'accesso alla fotocamera:", err);
        }
      };
      
      startCamera();
      
      return () => {
        if (streamRef.current) {
          streamRef.current.getTracks().forEach(track => track.stop());
        }
        
        if (timerRef.current) {
          clearTimeout(timerRef.current);
        }
      };
    }
  }, [isOpen]);

  // Controlla il countdown e la registrazione
  useEffect(() => {
    if (countdown > 0) {
      timerRef.current = setTimeout(() => setCountdown(prev => prev - 1), 1000);
      
      if (countdown === 1) {
        startRecording();
      }
    }
    
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [countdown]);

  // Gestisce il timer di registrazione
  useEffect(() => {
    if (isRecording) {
      timerRef.current = setTimeout(() => {
        if (recordingTime < maxRecordingSeconds) {
          setRecordingTime(prev => prev + 1);
        } else {
          stopRecording();
        }
      }, 1000);
    }
    
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [isRecording, recordingTime]);

  const startCountdown = () => {
    setCountdown(3);
  };

  const startRecording = () => {
    if (!streamRef.current) return;
    
    chunks.current = [];
    setIsRecording(true);
    setRecordingTime(0);
    
    const mediaRecorder = new MediaRecorder(streamRef.current);
    mediaRecorderRef.current = mediaRecorder;
    
    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) {
        chunks.current.push(e.data);
      }
    };
    
    mediaRecorder.onstop = () => {
      const videoBlob = new Blob(chunks.current, { type: 'video/webm' });
      setRecordedVideo(videoBlob);
      setIsRecording(false);
      
      if (videoRef.current) {
        videoRef.current.srcObject = null;
        videoRef.current.src = URL.createObjectURL(videoBlob);
        videoRef.current.play();
      }
    };
    
    mediaRecorder.start();
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
  };

  const resetRecording = () => {
    setRecordedVideo(null);
    setRecordingTime(0);
    
    if (streamRef.current && videoRef.current) {
      videoRef.current.srcObject = streamRef.current;
    }
  };

  const handleSave = () => {
    if (recordedVideo) {
      onSave(recordedVideo, selectedTrack);
      onClose();
    }
  };

  const formattedTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col">
      {/* Header */}
      <div className="p-4 flex justify-between items-center">
        <button onClick={onClose} className="text-white">
          <X size={24} />
        </button>
        <h2 className="text-white font-medium">Crea Boom Reel</h2>
        <div></div>
      </div>
      
      {/* Video preview */}
      <div className="flex-1 relative">
        <video 
          ref={videoRef}
          autoPlay 
          playsInline 
          muted 
          className="w-full h-full object-cover"
        />
        
        {/* Countdown overlay */}
        {countdown > 0 && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/50">
            <span className="text-white text-8xl font-bold">{countdown}</span>
          </div>
        )}
        
        {/* Recording indicator */}
        {isRecording && (
          <div className="absolute top-4 left-0 right-0 flex justify-center items-center">
            <div className="bg-black/70 rounded-full px-4 py-2 flex items-center">
              <div className="w-3 h-3 rounded-full bg-red-500 mr-2 animate-pulse"></div>
              <span className="text-white">{formattedTime(recordingTime)} / {formattedTime(maxRecordingSeconds)}</span>
            </div>
          </div>
        )}
      </div>
      
      {/* Controls */}
      <div className="p-4 bg-black">
        {!recordedVideo ? (
          <>
            {!isRecording ? (
              <button 
                onClick={startCountdown}
                className="w-full bg-blue-600 text-white py-3 rounded-md font-medium"
              >
                Inizia a registrare
              </button>
            ) : (
              <button 
                onClick={stopRecording}
                className="w-full bg-red-600 text-white py-3 rounded-md font-medium"
              >
                Ferma registrazione
              </button>
            )}
          </>
        ) : (
          <div className="space-y-4">
            {/* Selezione traccia audio */}
            <div>
              <label className="text-white mb-2 block">Scegli musica di sottofondo:</label>
              <select 
                value={selectedTrack}
                onChange={(e) => setSelectedTrack(Number(e.target.value))}
                className="w-full p-2 rounded bg-white/10 text-white border border-white/20"
              >
                {backgroundTracks.map((track, idx) => (
                  <option key={track.id} value={idx}>{track.name}</option>
                ))}
              </select>
            </div>
            
            <div className="flex space-x-2">
              <button 
                onClick={resetRecording}
                className="flex-1 bg-white/10 text-white py-3 rounded-md font-medium"
              >
                Registra di nuovo
              </button>
              <button 
                onClick={handleSave}
                className="flex-1 bg-blue-600 text-white py-3 rounded-md font-medium"
              >
                Pubblica
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
});

CreateReelModal.displayName = 'CreateReelModal';

export default function BoomReels() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [activeIndex, setActiveIndex] = useState(0);
  const [startY, setStartY] = useState(0);
  const [isPropertyModalOpen, setIsPropertyModalOpen] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState<PropertyType | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTrack, setCurrentTrack] = useState(0);
  const [isCreateReelModalOpen, setIsCreateReelModalOpen] = useState(false);
  const [userReels, setUserReels] = useState<{ video: string; trackId: number }[]>([]);

  // Fetch properties from API
  const { data: properties = [], isLoading, error } = useQuery<PropertyType[]>({
    queryKey: ['/api/properties'],
    staleTime: 5 * 60 * 1000, // Cache per 5 minuti
    queryFn: async () => {
      const response = await fetch('/api/properties');
      if (!response.ok) {
        throw new Error('Failed to fetch properties');
      }
      return response.json();
    }
  });

  // Disabilita lo scroll della pagina quando si è in questa vista
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    
    return () => {
      document.body.style.overflow = '';
    };
  }, []);

  // Gestione eventi unificata e memoizzata per prestazioni migliori
  useEffect(() => {
    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      
      // Throttle per evitare scorrimenti troppo veloci
      if (e.deltaY > 50 && activeIndex < properties.length - 1) {
        setActiveIndex(prev => prev + 1);
      } else if (e.deltaY < -50 && activeIndex > 0) {
        setActiveIndex(prev => prev - 1);
      }
    };

    const container = containerRef.current;
    if (container) {
      container.addEventListener('wheel', handleWheel, { passive: false });
    }

    return () => {
      if (container) {
        container.removeEventListener('wheel', handleWheel);
      }
    };
  }, [activeIndex, properties.length]);

  // Imposta proprietà attiva quando si clicca
  const handleViewProperty = (property: PropertyType) => {
    setSelectedProperty(property);
    setIsPropertyModalOpen(true);
  };

  // Gestione touch per mobile - semplificata
  const handleTouchStart = (e: React.TouchEvent) => {
    setStartY(e.touches[0].clientY);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    const endY = e.changedTouches[0].clientY;
    const diff = startY - endY;
    
    // Threshold per il cambiamento di slide
    if (Math.abs(diff) > 80) {
      if (diff > 0 && activeIndex < properties.length - 1) {
        setActiveIndex(prev => prev + 1);
      } else if (diff < 0 && activeIndex > 0) {
        setActiveIndex(prev => prev - 1);
      }
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-black">
        <Loader2 className="h-12 w-12 animate-spin text-white mb-4" />
        <p className="text-white text-lg">Caricamento immobili...</p>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-black">
        <div className="text-white text-center p-4">
          <p className="text-xl mb-4">Si è verificato un errore nel caricamento degli immobili</p>
          <button 
            onClick={() => window.location.reload()} 
            className="px-4 py-2 bg-white/10 rounded-lg text-white hover:bg-white/20"
          >
            Riprova
          </button>
        </div>
      </div>
    );
  }

  // No properties found
  if (properties.length === 0) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-black">
        <div className="text-white text-center p-4">
          <Ban size={48} className="mx-auto mb-4 text-gray-400" />
          <p className="text-xl">Nessun immobile disponibile</p>
          <p className="text-gray-400 mt-2 mb-4">Prova a modificare i filtri di ricerca</p>
          <Link href="/" className="px-4 py-2 bg-white/10 rounded-lg text-white hover:bg-white/20 inline-block">
            Torna alla home
          </Link>
        </div>
      </div>
    );
  }

  // Gestisci il salvataggio di un nuovo reel
  const handleSaveReel = (videoBlob: Blob, trackId: number) => {
    const videoUrl = URL.createObjectURL(videoBlob);
    setUserReels(prev => [...prev, { video: videoUrl, trackId }]);
    
    // Chiudi il modale e torna al feed principale
    setIsCreateReelModalOpen(false);
    
    toast({
      title: "Boom Reel pubblicato!",
      description: "Il tuo Reel è stato pubblicato con successo",
      duration: 3000
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black">
      {/* Header with exit button */}
      <div className="absolute top-0 left-0 right-0 z-40 py-4 px-4 flex justify-between items-center bg-gradient-to-b from-black/80 to-transparent">
        <Link href="/" className="flex items-center text-white">
          <div className="text-lg font-bold">BoomHouse</div>
          <div className="ml-2 bg-blue-600 text-white px-2 py-0.5 rounded-sm text-xs">
            Boom Reels
          </div>
        </Link>
        
        <div className="flex items-center">
          {/* Pulsante per creare un nuovo reel */}
          <button 
            onClick={() => setIsCreateReelModalOpen(true)}
            className="mr-2 w-10 h-10 flex items-center justify-center rounded-full bg-blue-600 text-white"
          >
            <Plus size={20} />
          </button>
          
          {/* Toggle audio */}
          <button 
            onClick={() => setIsMuted(prev => !prev)}
            className="mr-2 w-10 h-10 flex items-center justify-center rounded-full bg-black/50 text-white"
          >
            {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
          </button>
          
          {/* Chiudi */}
          <Link href="/" className="w-10 h-10 flex items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/70">
            <X size={20} />
          </Link>
        </div>
      </div>
      
      {/* Main swipable feed - semplificato */}
      <div 
        ref={containerRef}
        className="h-full w-full relative bg-black overflow-hidden" 
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        {/* Indicatore di progresso */}
        <div className="absolute bottom-16 left-0 right-0 z-30 flex justify-center">
          <div className="bg-black/50 text-white text-sm px-4 py-2 rounded-full">
            {activeIndex + 1} di {properties.length}
          </div>
        </div>
        
        {/* Cambio traccia audio */}
        <div className="absolute bottom-28 right-4 z-30">
          <button 
            onClick={() => setCurrentTrack(prev => (prev + 1) % backgroundTracks.length)}
            className="w-12 h-12 flex items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/70"
          >
            <Music size={20} />
          </button>
        </div>
        
        {/* Contenitore delle slide - semplificato */}
        <div className="h-full w-full relative">
          {properties.map((property, index) => (
            <PropertySlide 
              key={property.id}
              property={property} 
              isActive={index === activeIndex}
              onClick={() => handleViewProperty(property)}
              currentTrack={currentTrack}
              isMuted={isMuted}
            />
          ))}
        </div>
      </div>
      
      {/* Property Details Modal */}
      <PropertyDetailModal
        property={selectedProperty}
        isOpen={isPropertyModalOpen}
        onClose={() => setIsPropertyModalOpen(false)}
      />
      
      {/* Create Reel Modal */}
      <CreateReelModal
        isOpen={isCreateReelModalOpen}
        onClose={() => setIsCreateReelModalOpen(false)}
        onSave={handleSaveReel}
      />
    </div>
  );
}