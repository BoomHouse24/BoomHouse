import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { BankType } from '@/lib/types';
import Header from '@/components/Header';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Phone, Mail, Globe, MapPin, Search } from 'lucide-react';

export default function Banche() {
  const [searchQuery, setSearchQuery] = useState('');
  
  // Carica le banche
  const { data: banks = [], isLoading } = useQuery<BankType[]>({
    queryKey: ['/api/banks'],
  });

  // Funzione per filtrare le banche
  const filteredBanks = banks.filter(bank => 
    bank.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onOpenCalculator={() => {}} />
      
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6 text-gray-900">Banche e Assicurazioni</h1>
        
        {/* Filtri */}
        <div className="mb-8">
          <div className="relative max-w-md">
            <Input
              type="text"
              placeholder="Cerca banca o assicurazione..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          </div>
        </div>
        
        {/* Lista delle banche */}
        {isLoading ? (
          <div className="flex justify-center my-12">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
          </div>
        ) : filteredBanks.length === 0 ? (
          <div className="text-center my-12 p-8 bg-white rounded-lg shadow">
            <h3 className="text-xl font-medium text-gray-700">Nessuna banca trovata</h3>
            <p className="text-gray-500 mt-2">Prova a modificare i criteri di ricerca</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBanks.map(bank => (
              <Card key={bank.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardHeader className="flex justify-center items-center pt-6 pb-4">
                  <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l9-4 9 4m-9 4v10m-9-10v10m18-10v10M3 16l9 4 9-4" />
                    </svg>
                  </div>
                </CardHeader>
                <CardContent>
                  <h3 className="text-xl font-bold text-center mb-4">{bank.name}</h3>
                  
                  <div className="space-y-3">
                    <div className="flex items-start">
                      <MapPin size={18} className="text-gray-400 mr-2 mt-0.5" />
                      <span className="text-sm">{bank.address}</span>
                    </div>
                    
                    {bank.phone && (
                      <div className="flex items-center">
                        <Phone size={18} className="text-gray-400 mr-2" />
                        <span className="text-sm">{bank.phone}</span>
                      </div>
                    )}
                    
                    {bank.email && (
                      <div className="flex items-center">
                        <Mail size={18} className="text-gray-400 mr-2" />
                        <span className="text-sm truncate">{bank.email}</span>
                      </div>
                    )}
                    
                    {bank.website && (
                      <div className="flex items-center">
                        <Globe size={18} className="text-gray-400 mr-2" />
                        <a 
                          href={bank.website} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="text-sm text-blue-600 hover:underline truncate"
                        >
                          {bank.website.replace(/^https?:\/\//, '')}
                        </a>
                      </div>
                    )}
                    
                    <div className="pt-4">
                      <Button className="w-full mt-2 bg-amber-500 hover:bg-amber-600">
                        Richiedi Consulenza
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
      
      <footer className="bg-gray-100 py-8 mt-12">
        <div className="container mx-auto px-4">
          <p className="text-center text-gray-600 text-sm">
            © {new Date().getFullYear()} BoomHouse - Tutti i diritti riservati
          </p>
        </div>
      </footer>
    </div>
  );
}