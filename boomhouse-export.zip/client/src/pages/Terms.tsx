import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function Terms() {
  return (
    <>
      <Header onOpenCalculator={() => {}} />
      <main className="max-w-screen-xl mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href="/">
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <ArrowLeft className="h-4 w-4" />
              <span>Torna alla Home</span>
            </Button>
          </Link>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8">
          <h1 className="text-3xl font-bold mb-6">Termini e Condizioni</h1>
          
          <div className="prose max-w-none">
            <h2 className="text-xl font-semibold mt-6 mb-4">1. Accettazione dei Termini</h2>
            <p>
              Utilizzando il sito web di BoomHouse, accetti di essere vincolato dai presenti Termini e Condizioni. Se non accetti questi termini, sei pregato di non utilizzare il nostro sito.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">2. Registrazione e Account</h2>
            <p>
              Per accedere a determinate funzionalità del nostro sito, potrebbe essere necessario registrarsi e creare un account. 
              Sei responsabile di mantenere la riservatezza delle tue credenziali di accesso e di tutte le attività che si verificano sotto il tuo account.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">3. Contenuti del Sito</h2>
            <p>
              I contenuti presenti sul nostro sito, inclusi testi, grafica, loghi, immagini e software, sono di proprietà di BoomHouse o dei suoi fornitori e sono protetti da leggi sul copyright e altre leggi sulla proprietà intellettuale.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">4. Inserzioni Immobiliari</h2>
            <p>
              BoomHouse non garantisce l'accuratezza delle informazioni contenute nelle inserzioni immobiliari. 
              Gli utenti che pubblicano annunci sono responsabili dell'accuratezza e della legalità delle informazioni fornite.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">5. Limitazione di Responsabilità</h2>
            <p>
              BoomHouse non sarà responsabile per danni diretti, indiretti, incidentali, speciali o consequenziali derivanti dall'utilizzo o dall'impossibilità di utilizzare i nostri servizi.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">6. Indennizzo</h2>
            <p>
              Accetti di indennizzare e tenere indenni BoomHouse e i suoi affiliati da qualsiasi reclamo, responsabilità, danno, perdita e spesa derivante dalla violazione di questi Termini.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">7. Legge Applicabile</h2>
            <p>
              Questi Termini sono regolati e interpretati in conformità con le leggi della Svizzera, senza riguardo alle sue disposizioni in materia di conflitto di leggi.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">8. Modifiche ai Termini</h2>
            <p>
              Ci riserviamo il diritto, a nostra esclusiva discrezione, di modificare o sostituire questi Termini in qualsiasi momento. 
              La versione più aggiornata sarà sempre disponibile sul nostro sito.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">9. Contattaci</h2>
            <p>
              Se hai domande su questi Termini, contattaci all'indirizzo: legal@boomhouse.ch
            </p>
          </div>
        </div>
      </main>
    </>
  );
}