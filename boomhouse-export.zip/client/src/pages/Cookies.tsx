import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function Cookies() {
  return (
    <>
      <Header onOpenCalculator={() => {}} />
      <main className="max-w-screen-xl mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href="/">
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <ArrowLeft className="h-4 w-4" />
              <span>Torna alla Home</span>
            </Button>
          </Link>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8">
          <h1 className="text-3xl font-bold mb-6">Informativa sui Cookie</h1>
          
          <div className="prose max-w-none">
            <h2 className="text-xl font-semibold mt-6 mb-4">1. Cosa sono i cookie</h2>
            <p>
              I cookie sono piccoli file di testo che vengono memorizzati sul tuo dispositivo quando visiti un sito web. 
              Sono ampiamente utilizzati per far funzionare i siti web in modo più efficiente, nonché per fornire informazioni ai proprietari del sito.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">2. Come utilizziamo i cookie</h2>
            <p>
              Utilizziamo diversi tipi di cookie per le seguenti finalità:
            </p>
            <ul className="list-disc pl-6 mt-2 mb-4">
              <li><strong>Cookie necessari:</strong> essenziali per il funzionamento del sito web</li>
              <li><strong>Cookie di preferenze:</strong> permettono al sito di ricordare le tue preferenze</li>
              <li><strong>Cookie statistici:</strong> aiutano a capire come gli utenti interagiscono con il sito</li>
              <li><strong>Cookie di marketing:</strong> utilizzati per tracciare i visitatori attraverso i siti web</li>
            </ul>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">3. Cookie di terze parti</h2>
            <p>
              Il nostro sito utilizza anche servizi forniti da terze parti che possono impostare i propri cookie. 
              Questi servizi includono:
            </p>
            <ul className="list-disc pl-6 mt-2 mb-4">
              <li>Google Analytics</li>
              <li>Servizi di mappe interattive</li>
              <li>Social media buttons</li>
            </ul>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">4. Gestione dei cookie</h2>
            <p>
              Puoi controllare e gestire i cookie in vari modi. La maggior parte dei browser web ti consente di 
              gestire le tue preferenze sui cookie tramite le impostazioni del browser.
            </p>
            <p>
              Se desideri limitare o bloccare i cookie, puoi farlo attraverso le impostazioni del tuo browser. 
              Le funzionalità "Aiuto" nel tuo browser dovrebbero fornirti informazioni su come farlo.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">5. Cookie specifici utilizzati</h2>
            <p>
              Di seguito è riportato un elenco dei principali cookie utilizzati sul nostro sito:
            </p>
            <ul className="list-disc pl-6 mt-2 mb-4">
              <li><strong>session_id:</strong> Mantiene la tua sessione attiva durante la navigazione</li>
              <li><strong>preferences:</strong> Memorizza le tue preferenze di visualizzazione</li>
              <li><strong>_ga, _gid:</strong> Cookie di Google Analytics per analisi del traffico</li>
            </ul>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">6. Modifiche all'informativa sui cookie</h2>
            <p>
              Potremmo aggiornare questa Informativa sui Cookie di tanto in tanto per riflettere, ad esempio, 
              cambiamenti nei cookie che utilizziamo o per altri motivi operativi, legali o normativi.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">7. Contattaci</h2>
            <p>
              Per qualsiasi domanda sulla nostra Informativa sui Cookie, contattaci a: privacy@boomhouse.ch
            </p>
          </div>
        </div>
      </main>
    </>
  );
}