import { useState } from "react";
import { Link } from "wouter";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { StarIcon } from "lucide-react";

// Dati fittizi per le recensioni
const recensioni = [
  {
    id: 1,
    nome: "Marco Rossi",
    città: "Lugano",
    data: "12 marzo 2023",
    voto: 5,
    testo: "Ho trovato la mia casa ideale grazie a BoomHouse. La possibilità di vedere i dati catastali direttamente sulla mappa è stata fondamentale per la mia scelta. Servizio eccellente!",
    avatar: "/avatars/avatar-1.jpg"
  },
  {
    id: 2,
    nome: "Laura Bianchi",
    città: "Bellinzona",
    data: "5 aprile 2023",
    voto: 4,
    testo: "Il calcolatore ipotecario mi ha dato una visione chiara di cosa potevo permettermi. Ho trovato un appartamento perfetto nel mio budget grazie ai filtri avanzati.",
    avatar: "/avatars/avatar-2.jpg"
  },
  {
    id: 3,
    nome: "Alessandro Verdi",
    città: "Locarno",
    data: "18 maggio 2023",
    voto: 5,
    testo: "La funzione Boom Reels è fantastica! Mi ha permesso di vedere tanti immobili in modo rapido e divertente. Ho trovato casa in una settimana!",
    avatar: "/avatars/avatar-3.jpg"
  },
  {
    id: 4,
    nome: "Francesca Neri",
    città: "Mendrisio",
    data: "2 giugno 2023",
    voto: 5,
    testo: "BoomHouse mi ha aiutato a trovare non solo la casa, ma anche tutti i professionisti di cui avevo bisogno: notaio, architetto e banca. Tutto in un unico posto!",
    avatar: "/avatars/avatar-4.jpg"
  },
  {
    id: 5,
    nome: "Luca Gialli",
    città: "Chiasso",
    data: "15 luglio 2023",
    voto: 4,
    testo: "Ottima piattaforma per la ricerca immobiliare. L'interfaccia è intuitiva e i filtri sono molto precisi. Avrei solo voluto più immobili nella mia zona.",
    avatar: "/avatars/avatar-5.jpg"
  },
  {
    id: 6,
    nome: "Sofia Ferrari",
    città: "Biasca",
    data: "3 agosto 2023",
    voto: 5,
    testo: "Ho pubblicato l'annuncio del mio appartamento e ho ricevuto diverse richieste in pochi giorni. Facile da usare e molto efficace!",
    avatar: "/avatars/avatar-6.jpg"
  }
];

// Componente per mostrare stelle di valutazione
const RatingStars = ({ rating }: { rating: number }) => {
  return (
    <div className="flex">
      {[...Array(5)].map((_, i) => (
        <StarIcon 
          key={i} 
          className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
        />
      ))}
    </div>
  );
};

export default function Recensioni() {
  // Funzione fittizia per il calcolo ipotecario (usata solo per il passaggio al componente Header)
  const openCalculator = () => {
    console.log("Questa funzione non fa nulla in questa pagina");
  };

  const [filterRating, setFilterRating] = useState<number | null>(null);

  // Filtra le recensioni in base al voto selezionato
  const recensioniFiltered = filterRating 
    ? recensioni.filter(rec => rec.voto === filterRating)
    : recensioni;

  return (
    <>
      <Header onOpenCalculator={openCalculator} />
      <main className="container mx-auto py-10 px-4 md:px-6 lg:px-8 max-w-6xl">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-primary mb-4">Cosa dicono i nostri utenti</h1>
          <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            Scopri le esperienze degli utenti che hanno utilizzato BoomHouse per trovare 
            la casa dei loro sogni o per vendere la loro proprietà.
          </p>
        </div>

        {/* Filtri per le recensioni */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          <Button 
            variant={filterRating === null ? "default" : "outline"}
            onClick={() => setFilterRating(null)}
            className="min-w-[100px]"
          >
            Tutte
          </Button>
          {[5, 4, 3, 2, 1].map(rating => (
            <Button
              key={rating}
              variant={filterRating === rating ? "default" : "outline"}
              onClick={() => setFilterRating(rating)}
              className="min-w-[100px]"
            >
              {rating} <StarIcon className="ml-1 h-4 w-4 fill-current" />
            </Button>
          ))}
        </div>

        {/* Lista delle recensioni */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {recensioniFiltered.map((recensione) => (
            <Card key={recensione.id} className="h-full flex flex-col">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex items-center space-x-4">
                    <Avatar>
                      <AvatarFallback>{recensione.nome.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="text-lg">{recensione.nome}</CardTitle>
                      <CardDescription>{recensione.città} • {recensione.data}</CardDescription>
                    </div>
                  </div>
                  <RatingStars rating={recensione.voto} />
                </div>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-gray-700 dark:text-gray-300">{recensione.testo}</p>
              </CardContent>
              <CardFooter className="border-t pt-4">
                <div className="text-sm text-gray-500 dark:text-gray-400">
                  Verificato da BoomHouse
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-16 bg-blue-50 dark:bg-blue-900/20 rounded-lg p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Sei soddisfatto di BoomHouse?</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-2xl mx-auto">
            Condividi la tua esperienza e aiuta altre persone a trovare la casa dei loro sogni.
            La tua recensione è importante per noi e per la nostra comunità.
          </p>
          <Button size="lg" className="min-w-[200px]">
            Scrivi una recensione
          </Button>
        </div>
      </main>
      
      {/* Footer semplice */}
      <footer className="bg-[#003580] text-white py-8 mt-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">BoomHouse</h3>
              <p className="text-sm text-[#b1c0da]">
                Il modo più intelligente per cercare immobili in Svizzera con dati catastali integrati.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Link utili</h3>
              <ul className="space-y-2 text-sm">
                <li><Link href="/chi-siamo"><a className="text-[#b1c0da] hover:text-white">Chi siamo</a></Link></li>
                <li><Link href="/come-funziona"><a className="text-[#b1c0da] hover:text-white">Come funziona</a></Link></li>
                <li><Link href="/boom-reels"><a className="text-[#b1c0da] hover:text-white">Boom Reels</a></Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Legale</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="/privacy" className="text-[#b1c0da] hover:text-white">Privacy</a></li>
                <li><a href="/terms" className="text-[#b1c0da] hover:text-white">Termini e condizioni</a></li>
                <li><a href="/cookies" className="text-[#b1c0da] hover:text-white">Cookie</a></li>
                <li><a href="/disclaimer" className="text-[#b1c0da] hover:text-white">Disclaimer</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contatti</h3>
              <ul className="space-y-2 text-sm">
                <li className="text-[#b1c0da]">Email: info@boomhouse.ch</li>
                <li className="text-[#b1c0da]">Tel: +41 12 345 67 89</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-6 border-t border-[#1A4A8E] text-center text-sm text-[#b1c0da]">
            © {new Date().getFullYear()} BoomHouse. Tutti i diritti riservati.
          </div>
        </div>
      </footer>
    </>
  );
}