import React, { useEffect } from 'react';
import Header from '@/components/Header';

export default function PubblicaAnnuncio() {
  useEffect(() => {
    // Al caricamento della pagina, apriamo automaticamente il modulo di pubblicazione
    setTimeout(() => {
      document.getElementById("publish-property-trigger")?.click();
    }, 100);
  }, []);

  return (
    <div className="container mx-auto py-8">
      <Header onOpenCalculator={() => console.log("No calculator available here")} />
      <div className="p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md mt-4">
        <h1 className="text-2xl font-bold mb-4">Pubblica un annuncio</h1>
        <p className="mb-4">Compila il form per pubblicare il tuo annuncio su BoomHouse.</p>
        <p className="mb-4">Il modulo dovrebbe apparire automaticamente. Se non appare, puoi <button 
          onClick={() => document.getElementById("publish-property-trigger")?.click()}
          className="text-blue-600 dark:text-blue-400 underline hover:text-blue-800 dark:hover:text-blue-300"
        >
          cliccare qui
        </button> per aprirlo manualmente.</p>
        
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-2">Vantaggi di pubblicare con BoomHouse</h2>
          <ul className="list-disc pl-5 space-y-2">
            <li>Visibilità su tutta la Svizzera</li>
            <li>Pubblicazione gratuita</li>
            <li>Interfaccia semplice e intuitiva</li>
            <li>Gestione delle richieste centralizzata</li>
            <li>Integrazione con i professionisti del settore</li>
          </ul>
        </div>
      </div>
    </div>
  );
}