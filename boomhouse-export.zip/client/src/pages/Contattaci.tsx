import { useState } from "react";
import { Link } from "wouter";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useToast } from "@/hooks/use-toast";
import { 
  Mail, 
  Phone, 
  MapPin, 
  Clock, 
  Send 
} from "lucide-react";

// Schema di validazione per il form di contatto
const contactFormSchema = z.object({
  nome: z.string().min(2, {
    message: "Il nome deve essere di almeno 2 caratteri",
  }),
  email: z.string().email({
    message: "Inserisci un indirizzo email valido",
  }),
  telefono: z.string().optional(),
  oggetto: z.string().min(5, {
    message: "L'oggetto deve essere di almeno 5 caratteri",
  }),
  messaggio: z.string().min(10, {
    message: "Il messaggio deve essere di almeno 10 caratteri",
  }),
  privacy: z.boolean().refine(value => value === true, {
    message: "Devi accettare la privacy policy",
  }),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

export default function Contattaci() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Funzione fittizia per il calcolo ipotecario (usata solo per il passaggio al componente Header)
  const openCalculator = () => {
    console.log("Questa funzione non fa nulla in questa pagina");
  };

  // Inizializza il form
  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      nome: "",
      email: "",
      telefono: "",
      oggetto: "",
      messaggio: "",
      privacy: false,
    },
  });

  // Gestisce l'invio del form
  const onSubmit = async (data: ContactFormValues) => {
    setIsSubmitting(true);
    
    // Simula una chiamata API
    setTimeout(() => {
      console.log("Dati del form:", data);
      
      toast({
        title: "Messaggio inviato",
        description: "Ti risponderemo il prima possibile. Grazie per averci contattato!",
      });
      
      form.reset();
      setIsSubmitting(false);
    }, 1500);
  };

  return (
    <>
      <Header onOpenCalculator={openCalculator} />
      <main className="container mx-auto py-10 px-4 md:px-6 lg:px-8 max-w-6xl">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-primary mb-4">Contattaci</h1>
          <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            Hai domande, suggerimenti o hai bisogno di assistenza? 
            Il nostro team è qui per aiutarti. Compila il form sottostante o utilizza 
            uno dei nostri canali di contatto.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Scrivici un messaggio</CardTitle>
                <CardDescription>
                  Compila il form sottostante e ti risponderemo entro 24 ore lavorative.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="nome"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nome completo</FormLabel>
                            <FormControl>
                              <Input placeholder="Mario Rossi" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input placeholder="tuamail@esempio.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="telefono"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Telefono (opzionale)</FormLabel>
                            <FormControl>
                              <Input placeholder="+41 12 345 67 89" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="oggetto"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Oggetto</FormLabel>
                            <FormControl>
                              <Input placeholder="Informazioni su..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="messaggio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Messaggio</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Scrivi qui il tuo messaggio..." 
                              className="min-h-[150px]" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="privacy"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <input
                              type="checkbox"
                              checked={field.value}
                              onChange={field.onChange}
                              className="h-4 w-4 mt-1"
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Privacy Policy</FormLabel>
                            <FormDescription>
                              Accetto che i miei dati vengano utilizzati secondo la{" "}
                              <Link href="/privacy">
                                <a className="text-primary hover:underline">Privacy Policy</a>
                              </Link>
                              .
                            </FormDescription>
                            <FormMessage />
                          </div>
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      disabled={isSubmitting}
                      className="w-full md:w-auto"
                    >
                      {isSubmitting ? (
                        <div className="flex items-center">
                          <div className="animate-spin mr-2 h-4 w-4 border-2 border-current border-t-transparent rounded-full"></div>
                          Invio in corso...
                        </div>
                      ) : (
                        <div className="flex items-center">
                          <Send className="mr-2 h-4 w-4" />
                          Invia messaggio
                        </div>
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
          
          <div>
            <Card className="h-full">
              <CardHeader>
                <CardTitle>Informazioni di contatto</CardTitle>
                <CardDescription>
                  Puoi contattarci anche direttamente tramite i seguenti canali.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center">
                  <Mail className="h-5 w-5 mr-3 text-primary" />
                  <div>
                    <p className="font-medium">Email</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">info@boomhouse.ch</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <Phone className="h-5 w-5 mr-3 text-primary" />
                  <div>
                    <p className="font-medium">Telefono</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">+41 12 345 67 89</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 mr-3 text-primary" />
                  <div>
                    <p className="font-medium">Indirizzo</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Via Example 123<br />
                      6900 Lugano<br />
                      Svizzera
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <Clock className="h-5 w-5 mr-3 text-primary" />
                  <div>
                    <p className="font-medium">Orari di supporto</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Lun - Ven: 9:00 - 18:00<br />
                      Sab: 9:00 - 12:00<br />
                      Dom: Chiuso
                    </p>
                  </div>
                </div>
                
                <div className="pt-4 border-t">
                  <p className="font-medium mb-2">Seguici sui social</p>
                  <div className="flex space-x-4">
                    <a href="#" className="text-gray-600 hover:text-primary">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
                    </a>
                    <a href="#" className="text-gray-600 hover:text-primary">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
                    </a>
                    <a href="#" className="text-gray-600 hover:text-primary">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path></svg>
                    </a>
                    <a href="#" className="text-gray-600 hover:text-primary">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg>
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* FAQ */}
        <div className="mt-16 bg-blue-50 dark:bg-blue-900/20 rounded-lg p-8">
          <h2 className="text-2xl font-bold mb-6 text-center">Domande frequenti</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold mb-2">Come posso vendere la mia proprietà su BoomHouse?</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Puoi pubblicare il tuo annuncio gratuitamente cliccando sul pulsante "Pubblica" nella barra in alto e seguendo le istruzioni.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">È necessario creare un account?</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Per cercare immobili non è necessario un account. Per pubblicare annunci o salvare preferiti ti consigliamo di registrarti.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Come funziona il calcolatore ipotecario?</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Il calcolatore ipotecario utilizza i tassi attuali e le condizioni delle banche svizzere per darti una stima accurata del tuo potere d'acquisto.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Posso contattare direttamente i proprietari?</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Sì, puoi contattare direttamente i venditori o le agenzie tramite i dettagli forniti negli annunci o utilizzando il nostro sistema di messaggistica.
              </p>
            </div>
          </div>
        </div>
      </main>
      
      {/* Footer semplice */}
      <footer className="bg-[#003580] text-white py-8 mt-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">BoomHouse</h3>
              <p className="text-sm text-[#b1c0da]">
                Il modo più intelligente per cercare immobili in Svizzera con dati catastali integrati.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Link utili</h3>
              <ul className="space-y-2 text-sm">
                <li><Link href="/chi-siamo"><a className="text-[#b1c0da] hover:text-white">Chi siamo</a></Link></li>
                <li><Link href="/come-funziona"><a className="text-[#b1c0da] hover:text-white">Come funziona</a></Link></li>
                <li><Link href="/boom-reels"><a className="text-[#b1c0da] hover:text-white">Boom Reels</a></Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Legale</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="/privacy" className="text-[#b1c0da] hover:text-white">Privacy</a></li>
                <li><a href="/terms" className="text-[#b1c0da] hover:text-white">Termini e condizioni</a></li>
                <li><a href="/cookies" className="text-[#b1c0da] hover:text-white">Cookie</a></li>
                <li><a href="/disclaimer" className="text-[#b1c0da] hover:text-white">Disclaimer</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contatti</h3>
              <ul className="space-y-2 text-sm">
                <li className="text-[#b1c0da]">Email: info@boomhouse.ch</li>
                <li className="text-[#b1c0da]">Tel: +41 12 345 67 89</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-6 border-t border-[#1A4A8E] text-center text-sm text-[#b1c0da]">
            © {new Date().getFullYear()} BoomHouse. Tutti i diritti riservati.
          </div>
        </div>
      </footer>
    </>
  );
}