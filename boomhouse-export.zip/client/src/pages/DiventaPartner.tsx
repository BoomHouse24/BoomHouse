import { Link } from "wouter";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { CheckIcon } from "lucide-react";

// Dati sui vantaggi per i partner
const vantaggi = [
  {
    titolo: "Maggiore visibilità",
    descrizione: "I tuoi immobili e servizi avranno una posizione privilegiata nelle ricerche degli utenti."
  },
  {
    titolo: "Accesso a dati esclusivi",
    descrizione: "Statistiche dettagliate sul mercato immobiliare svizzero e sul comportamento degli utenti."
  },
  {
    titolo: "Strumenti avanzati",
    descrizione: "Dashboard personalizzata, analisi delle performance e strumenti di marketing automatizzati."
  },
  {
    titolo: "Supporto prioritario",
    descrizione: "Assistenza dedicata tramite un account manager personale."
  },
  {
    titolo: "Networking",
    descrizione: "Accesso a eventi esclusivi e opportunità di networking con altri professionisti del settore."
  },
  {
    titolo: "Presenza sul blog",
    descrizione: "Possibilità di pubblicare articoli esperti e casi studio sulla nostra piattaforma."
  }
];

// Pacchetti di partnership
const pacchetti = [
  {
    nome: "Base",
    prezzo: "CHF 149",
    periodo: "al mese",
    descrizione: "Ideale per agenti immobiliari indipendenti e piccoli studi.",
    caratteristiche: [
      "Fino a 10 annunci in evidenza",
      "Statistiche di base",
      "Logo e profilo personalizzato",
      "Supporto email",
      "1 utente"
    ],
    popolare: false,
    colore: "bg-blue-600"
  },
  {
    nome: "Pro",
    prezzo: "CHF 299",
    periodo: "al mese",
    descrizione: "Perfetto per agenzie immobiliari di medie dimensioni.",
    caratteristiche: [
      "Fino a 30 annunci in evidenza",
      "Statistiche avanzate",
      "Dashboard personalizzata",
      "Supporto prioritario",
      "5 utenti",
      "API access",
      "Esportazione dati"
    ],
    popolare: true,
    colore: "bg-gradient-to-r from-blue-600 to-indigo-600"
  },
  {
    nome: "Enterprise",
    prezzo: "Contattaci",
    periodo: "",
    descrizione: "Soluzione su misura per grandi agenzie e sviluppatori immobiliari.",
    caratteristiche: [
      "Annunci illimitati in evidenza",
      "Analisi di mercato personalizzate",
      "Account manager dedicato",
      "Supporto telefonico 24/7",
      "Utenti illimitati",
      "Integrazione API completa",
      "White label solution",
      "Formazione personalizzata"
    ],
    popolare: false,
    colore: "bg-gray-800"
  }
];

// Testimonianze di partner
const testimonianze = [
  {
    nome: "Roberto Bernasconi",
    ruolo: "Direttore, Immobiliare Lugano SA",
    testo: "Da quando siamo diventati partner di BoomHouse, abbiamo visto un incremento del 35% nelle richieste per i nostri immobili. La piattaforma è intuitiva e il supporto è eccellente.",
    avatar: "/avatars/partner-1.jpg"
  },
  {
    nome: "Maria Rossi",
    ruolo: "Agente immobiliare indipendente",
    testo: "Come agente indipendente, BoomHouse mi ha dato la visibilità che non potevo permettermi con altri canali. Il pacchetto Base è perfetto per le mie esigenze.",
    avatar: "/avatars/partner-2.jpg"
  },
  {
    nome: "Studio Architettura Moderno",
    ruolo: "Studio di architettura",
    testo: "La partnership con BoomHouse ci ha permesso di entrare in contatto con nuovi clienti e di ampliare il nostro portfolio. Consigliato a tutti i professionisti del settore.",
    avatar: "/avatars/partner-3.jpg"
  }
];

export default function DiventaPartner() {
  // Funzione fittizia per il calcolo ipotecario (usata solo per il passaggio al componente Header)
  const openCalculator = () => {
    console.log("Questa funzione non fa nulla in questa pagina");
  };

  return (
    <>
      <Header onOpenCalculator={openCalculator} />
      <main className="container mx-auto py-10 px-4 md:px-6 lg:px-8 max-w-7xl">
        {/* Hero section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl mb-4">
            Diventa partner di BoomHouse
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            Unisciti alla piattaforma immobiliare leader in Svizzera e fai crescere il tuo business
            con strumenti avanzati e maggiore visibilità.
          </p>
        </div>

        {/* Target audience */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <Card className="bg-gradient-to-b from-blue-50 to-white dark:from-blue-900/20 dark:to-gray-800">
            <CardHeader>
              <CardTitle>Agenti immobiliari</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-400">
                Aumenta la tua visibilità, raggiungi più clienti e utilizza strumenti avanzati per differenziarti dalla concorrenza.
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-b from-indigo-50 to-white dark:from-indigo-900/20 dark:to-gray-800">
            <CardHeader>
              <CardTitle>Agenzie immobiliari</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-400">
                Gestisci il tuo portfolio di proprietà in modo efficiente, accedi a statistiche dettagliate e ottieni lead qualificati.
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-b from-sky-50 to-white dark:from-sky-900/20 dark:to-gray-800">
            <CardHeader>
              <CardTitle>Professionisti</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-400">
                Architetti, notai, artigiani e banche: promuovete i vostri servizi direttamente a chi sta cercando una proprietà.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Vantaggi */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-10">Perché diventare partner</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {vantaggi.map((vantaggio, index) => (
              <div key={index} className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700">
                <h3 className="text-xl font-semibold mb-3">{vantaggio.titolo}</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  {vantaggio.descrizione}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Pricing */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-4">Scegli il tuo piano</h2>
          <p className="text-center text-gray-600 dark:text-gray-400 max-w-2xl mx-auto mb-10">
            Offriamo diverse soluzioni per adattarsi alle esigenze di ogni tipo di partner. 
            Tutti i piani includono un periodo di prova gratuito di 14 giorni.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {pacchetti.map((pacchetto, index) => (
              <div key={index} className="relative">
                {pacchetto.popolare && (
                  <div className="absolute top-0 inset-x-0 -translate-y-1/2">
                    <span className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white text-xs font-semibold px-4 py-1 rounded-full uppercase tracking-wide shadow-md">
                      Più popolare
                    </span>
                  </div>
                )}
                
                <Card className={`h-full ${pacchetto.popolare ? 'border-blue-400 dark:border-blue-500 shadow-md' : ''}`}>
                  <CardHeader className={`rounded-t-lg text-white ${pacchetto.colore}`}>
                    <CardTitle className="text-2xl">{pacchetto.nome}</CardTitle>
                    <div className="mt-2">
                      <span className="text-3xl font-bold">{pacchetto.prezzo}</span>
                      {pacchetto.periodo && <span className="text-sm opacity-90"> {pacchetto.periodo}</span>}
                    </div>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <p className="text-gray-600 dark:text-gray-400 mb-6">
                      {pacchetto.descrizione}
                    </p>
                    <ul className="space-y-3">
                      {pacchetto.caratteristiche.map((feature, i) => (
                        <li key={i} className="flex items-start">
                          <CheckIcon className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                          <span className="text-gray-600 dark:text-gray-400">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      variant={pacchetto.popolare ? "default" : "outline"} 
                      className="w-full"
                    >
                      {pacchetto.nome === "Enterprise" ? "Contattaci" : "Attiva piano"}
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            ))}
          </div>
        </div>

        {/* CTA FAQ */}
        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-8 mb-16">
          <h2 className="text-2xl font-bold mb-6 text-center">Domande frequenti</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold mb-2">Per quanto tempo devo impegnarmi?</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                I nostri abbonamenti sono mensili e possono essere cancellati in qualsiasi momento. Per i piani annuali offriamo uno sconto del 15%.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Come funziona il periodo di prova?</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Puoi provare qualsiasi piano per 14 giorni senza impegno. Non è richiesta una carta di credito per iniziare.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Posso cambiare piano in seguito?</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Sì, puoi passare a un piano superiore o inferiore in qualsiasi momento. Il cambiamento sarà effettivo dal ciclo di fatturazione successivo.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Quali metodi di pagamento accettate?</h3>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Accettiamo tutte le principali carte di credito, PayPal e bonifico bancario per le aziende svizzere.
              </p>
            </div>
          </div>
        </div>

        {/* Testimonianze */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-10">
            Partner soddisfatti
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonianze.map((testimonianza, index) => (
              <Card key={index} className="bg-white dark:bg-gray-800">
                <CardContent className="pt-6">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                      <span className="text-blue-600 font-bold">{testimonianza.nome.charAt(0)}</span>
                    </div>
                    <div>
                      <p className="font-semibold">{testimonianza.nome}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{testimonianza.ruolo}</p>
                    </div>
                  </div>
                  <p className="text-gray-600 dark:text-gray-400 italic">
                    "{testimonianza.testo}"
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA finale */}
        <div className="text-center py-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-blue-600 to-indigo-700 rounded-lg">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl mb-4">
            Pronto a far crescere il tuo business?
          </h2>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto mb-8">
            Unisciti ai partner di BoomHouse oggi stesso e porta la tua attività al livello successivo.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" variant="secondary" className="bg-white text-blue-700 hover:bg-blue-50">
              Inizia la prova gratuita
            </Button>
            <Link href="/contattaci">
              <Button size="lg" variant="outline" className="text-white border-white hover:bg-blue-700">
                Contattaci
              </Button>
            </Link>
          </div>
        </div>
      </main>
      
      {/* Footer semplice */}
      <footer className="bg-[#003580] text-white py-8 mt-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">BoomHouse</h3>
              <p className="text-sm text-[#b1c0da]">
                Il modo più intelligente per cercare immobili in Svizzera con dati catastali integrati.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Link utili</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="/chi-siamo" className="text-[#b1c0da] hover:text-white">Chi siamo</a></li>
                <li><a href="/come-funziona" className="text-[#b1c0da] hover:text-white">Come funziona</a></li>
                <li><a href="/boom-reels" className="text-[#b1c0da] hover:text-white">Boom Reels</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Legale</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="/privacy" className="text-[#b1c0da] hover:text-white">Privacy</a></li>
                <li><a href="/terms" className="text-[#b1c0da] hover:text-white">Termini e condizioni</a></li>
                <li><a href="/cookies" className="text-[#b1c0da] hover:text-white">Cookie</a></li>
                <li><a href="/disclaimer" className="text-[#b1c0da] hover:text-white">Disclaimer</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contatti</h3>
              <ul className="space-y-2 text-sm">
                <li className="text-[#b1c0da]">Email: info@boomhouse.ch</li>
                <li className="text-[#b1c0da]">Tel: +41 12 345 67 89</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-6 border-t border-[#1A4A8E] text-center text-sm text-[#b1c0da]">
            © {new Date().getFullYear()} BoomHouse. Tutti i diritti riservati.
          </div>
        </div>
      </footer>
    </>
  );
}