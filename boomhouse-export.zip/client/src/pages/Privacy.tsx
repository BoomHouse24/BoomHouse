import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function Privacy() {
  return (
    <>
      <Header onOpenCalculator={() => {}} />
      <main className="max-w-screen-xl mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href="/">
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <ArrowLeft className="h-4 w-4" />
              <span>Torna alla Home</span>
            </Button>
          </Link>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8">
          <h1 className="text-3xl font-bold mb-6">Informativa sulla Privacy</h1>
          
          <div className="prose max-w-none">
            <h2 className="text-xl font-semibold mt-6 mb-4">1. Introduzione</h2>
            <p>
              La presente Informativa sulla Privacy descrive come BoomHouse raccoglie, utilizza e condivide le tue informazioni personali quando utilizzi il nostro sito web.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">2. Dati raccolti</h2>
            <p>
              Raccogliamo i seguenti tipi di informazioni:
            </p>
            <ul className="list-disc pl-6 mt-2 mb-4">
              <li>Informazioni fornite direttamente da te (nome, email, numero di telefono)</li>
              <li>Informazioni sulla tua attività sul sito</li>
              <li>Dati di ubicazione raccolti con il tuo consenso</li>
              <li>Informazioni del dispositivo (indirizzo IP, tipo di browser)</li>
            </ul>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">3. Finalità del trattamento</h2>
            <p>
              Utilizziamo i tuoi dati personali per:
            </p>
            <ul className="list-disc pl-6 mt-2 mb-4">
              <li>Fornirti i nostri servizi</li>
              <li>Comunicare con te</li>
              <li>Migliorare e ottimizzare il nostro sito</li>
              <li>Rispettare obblighi legali</li>
            </ul>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">4. Cookie</h2>
            <p>
              Utilizziamo cookie e tecnologie simili per migliorare l'esperienza utente, analizzare l'utilizzo del sito e personalizzare contenuti e annunci.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">5. Sicurezza dei dati</h2>
            <p>
              Adottiamo misure di sicurezza appropriate per proteggere i tuoi dati personali da accessi non autorizzati, alterazioni, divulgazioni o distruzioni.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">6. I tuoi diritti</h2>
            <p>
              In qualità di residente nell'UE o in Svizzera, hai diritto a:
            </p>
            <ul className="list-disc pl-6 mt-2 mb-4">
              <li>Accedere ai tuoi dati personali</li>
              <li>Correggere informazioni inesatte</li>
              <li>Richiedere la cancellazione dei tuoi dati</li>
              <li>Opporti al trattamento dei tuoi dati</li>
              <li>Richiedere la limitazione del trattamento</li>
              <li>Richiedere la portabilità dei dati</li>
            </ul>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">7. Modifiche alla Privacy Policy</h2>
            <p>
              Potremmo aggiornare la nostra Informativa sulla Privacy di tanto in tanto. Ti informeremo di eventuali modifiche pubblicando la nuova Informativa sulla Privacy su questa pagina.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">8. Contattaci</h2>
            <p>
              Per qualsiasi domanda sulla nostra Informativa sulla Privacy, contattaci a: privacy@boomhouse.ch
            </p>
          </div>
        </div>
      </main>
    </>
  );
}