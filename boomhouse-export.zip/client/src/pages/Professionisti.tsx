import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { FilterType, ProfessionalType } from '@/lib/types';
import Header from '@/components/Header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Phone, Mail, MapPin, Search } from 'lucide-react';

export default function Professionisti() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  
  // Carica i professionisti
  const { data: professionals = [], isLoading } = useQuery<ProfessionalType[]>({
    queryKey: ['/api/professionals'],
  });

  // Funzione per filtrare i professionisti
  const filteredProfessionals = professionals.filter(prof => {
    // Filtra per nome
    const nameMatch = prof.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Filtra per tipo
    const typeMatch = selectedType === 'all' || prof.type === selectedType;
    
    return nameMatch && typeMatch;
  });

  // Mappa tipo a nome visualizzato
  const getTypeName = (type: string): string => {
    switch (type) {
      case 'architect': return 'Architetto';
      case 'notary': return 'Notaio';
      case 'artisan': return 'Artigiano';
      default: return type;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onOpenCalculator={() => {}} />
      
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6 text-gray-900">Professionisti</h1>
        
        {/* Filtri */}
        <div className="mb-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="col-span-1 md:col-span-2">
            <div className="relative">
              <Input
                type="text"
                placeholder="Cerca per nome..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            </div>
          </div>
          
          <div className="flex space-x-2">
            <Button 
              variant={selectedType === 'all' ? 'default' : 'outline'}
              onClick={() => setSelectedType('all')}
              className="flex-1"
            >
              Tutti
            </Button>
            <Button 
              variant={selectedType === 'architect' ? 'default' : 'outline'}
              onClick={() => setSelectedType('architect')}
              className="flex-1"
            >
              Architetti
            </Button>
            <Button 
              variant={selectedType === 'notary' ? 'default' : 'outline'}
              onClick={() => setSelectedType('notary')}
              className="flex-1"
            >
              Notai
            </Button>
            <Button 
              variant={selectedType === 'artisan' ? 'default' : 'outline'}
              onClick={() => setSelectedType('artisan')}
              className="flex-1"
            >
              Artigiani
            </Button>
          </div>
        </div>
        
        {/* Lista dei professionisti */}
        {isLoading ? (
          <div className="flex justify-center my-12">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
          </div>
        ) : filteredProfessionals.length === 0 ? (
          <div className="text-center my-12 p-8 bg-white rounded-lg shadow">
            <h3 className="text-xl font-medium text-gray-700">Nessun professionista trovato</h3>
            <p className="text-gray-500 mt-2">Prova a modificare i filtri di ricerca</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProfessionals.map(professional => (
              <Card key={professional.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardHeader className="bg-primary/5 pb-3">
                  <CardTitle className="text-xl text-primary">
                    {professional.name}
                  </CardTitle>
                  <div className="flex items-center text-sm text-gray-500 font-medium">
                    <span className="inline-block px-2 py-1 rounded-full bg-primary/10 text-primary text-xs mr-2">
                      {getTypeName(professional.type)}
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="pt-4">
                  <div className="space-y-3">
                    <div className="flex items-start">
                      <MapPin size={18} className="text-gray-400 mr-2 mt-0.5" />
                      <span className="text-sm">{professional.address}</span>
                    </div>
                    
                    {professional.phone && (
                      <div className="flex items-center">
                        <Phone size={18} className="text-gray-400 mr-2" />
                        <span className="text-sm">{professional.phone}</span>
                      </div>
                    )}
                    
                    {professional.email && (
                      <div className="flex items-center">
                        <Mail size={18} className="text-gray-400 mr-2" />
                        <span className="text-sm truncate">{professional.email}</span>
                      </div>
                    )}
                    
                    {professional.description && (
                      <p className="text-sm text-gray-600 mt-2">{professional.description}</p>
                    )}
                    
                    <div className="pt-4">
                      <Button className="w-full bg-primary hover:bg-primary/90">
                        Contatta
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
      
      <footer className="bg-gray-100 py-8 mt-12">
        <div className="container mx-auto px-4">
          <p className="text-center text-gray-600 text-sm">
            © {new Date().getFullYear()} BoomHouse - Tutti i diritti riservati
          </p>
        </div>
      </footer>
    </div>
  );
}