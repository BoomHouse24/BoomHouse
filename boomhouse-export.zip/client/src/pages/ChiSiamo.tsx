import React from 'react';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { ArrowRight, Phone, Mail, MapPin, Clock } from 'lucide-react';

export default function ChiSiamo() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header onOpenCalculator={() => {}} />
      
      <main className="container mx-auto px-4 py-8">
        <section className="mb-16">
          <h1 className="text-4xl font-bold mb-4 text-gray-900">Chi Siamo</h1>
          <div className="w-20 h-1 bg-primary mb-8"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-2xl font-semibold mb-4 text-gray-800">La nostra missione</h2>
              <p className="text-gray-600 mb-4">
                BoomHouse nasce con l'obiettivo di rivoluzionare il mercato immobiliare svizzero, 
                rendendo più semplice e trasparente il processo di ricerca e acquisto di proprietà.
              </p>
              <p className="text-gray-600 mb-4">
                Integriamo dati catastali ufficiali con informazioni immobiliari e finanziarie, 
                creando un ecosistema completo per guidarti nel percorso verso la casa dei tuoi sogni.
              </p>
              <p className="text-gray-600 mb-6">
                Siamo più di un portale immobiliare: siamo un partner che ti accompagna in ogni fase, 
                dalla ricerca all'acquisto, con strumenti innovativi e una rete di professionisti qualificati.
              </p>
              
              <div className="flex space-x-4">
                <Button className="bg-primary hover:bg-primary/90">
                  Contattaci <ArrowRight size={16} className="ml-2" />
                </Button>
              </div>
            </div>
            
            <div className="rounded-lg overflow-hidden h-[400px] shadow-lg">
              <img 
                src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1073&q=80" 
                alt="BoomHouse Team" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </section>
        
        <section className="mb-16 bg-white rounded-lg shadow-sm p-8">
          <h2 className="text-2xl font-semibold mb-6 text-center text-gray-800">I nostri valori</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 border border-gray-100 rounded-lg hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-medium mb-2">Innovazione</h3>
              <p className="text-gray-600">
                Sviluppiamo continuamente nuovi strumenti e tecnologie per migliorare l'esperienza immobiliare.
              </p>
            </div>
            
            <div className="text-center p-6 border border-gray-100 rounded-lg hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-xl font-medium mb-2">Affidabilità</h3>
              <p className="text-gray-600">
                Forniamo dati accurati e verificati, collaborando con fonti ufficiali e professionisti del settore.
              </p>
            </div>
            
            <div className="text-center p-6 border border-gray-100 rounded-lg hover:shadow-md transition-shadow">
              <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-medium mb-2">Community</h3>
              <p className="text-gray-600">
                Creiamo connessioni tra acquirenti, venditori e professionisti, costruendo un ecosistema immobiliare collaborativo.
              </p>
            </div>
          </div>
        </section>
        
        <section className="mb-16">
          <h2 className="text-2xl font-semibold mb-8 text-center text-gray-800">Contattaci</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="bg-white p-8 rounded-lg shadow-sm">
              <h3 className="text-xl font-medium mb-6 text-gray-800">Informazioni di contatto</h3>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <MapPin className="text-primary mr-3 mt-1" />
                  <div>
                    <p className="text-gray-700 font-medium">Indirizzo</p>
                    <p className="text-gray-600">Via Lugano 15, 6900 Lugano, Svizzera</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Phone className="text-primary mr-3 mt-1" />
                  <div>
                    <p className="text-gray-700 font-medium">Telefono</p>
                    <p className="text-gray-600">+41 91 234 56 78</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Mail className="text-primary mr-3 mt-1" />
                  <div>
                    <p className="text-gray-700 font-medium">Email</p>
                    <p className="text-gray-600">info@boomhouse.ch</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Clock className="text-primary mr-3 mt-1" />
                  <div>
                    <p className="text-gray-700 font-medium">Orari di apertura</p>
                    <p className="text-gray-600">Lunedì - Venerdì: 9:00 - 18:00</p>
                    <p className="text-gray-600">Sabato: 9:00 - 12:00</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-sm">
              <h3 className="text-xl font-medium mb-6 text-gray-800">Scrivici</h3>
              
              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Nome</label>
                    <input
                      type="text"
                      id="name"
                      className="w-full p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input
                      type="email"
                      id="email"
                      className="w-full p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">Oggetto</label>
                  <input
                    type="text"
                    id="subject"
                    className="w-full p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
                  />
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">Messaggio</label>
                  <textarea
                    id="message"
                    rows={4}
                    className="w-full p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
                  ></textarea>
                </div>
                
                <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
                  Invia messaggio
                </Button>
              </form>
            </div>
          </div>
        </section>
      </main>
      
      <footer className="bg-gray-100 py-8">
        <div className="container mx-auto px-4">
          <p className="text-center text-gray-600 text-sm">
            © {new Date().getFullYear()} BoomHouse - Tutti i diritti riservati
          </p>
        </div>
      </footer>
    </div>
  );
}