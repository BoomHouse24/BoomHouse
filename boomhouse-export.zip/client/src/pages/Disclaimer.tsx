import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function Disclaimer() {
  return (
    <>
      <Header onOpenCalculator={() => {}} />
      <main className="max-w-screen-xl mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href="/">
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <ArrowLeft className="h-4 w-4" />
              <span>Torna alla Home</span>
            </Button>
          </Link>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8">
          <h1 className="text-3xl font-bold mb-6">Disclaimer Legale</h1>
          
          <div className="prose max-w-none">
            <h2 className="text-xl font-semibold mt-6 mb-4">1. Accuratezza delle Informazioni</h2>
            <p>
              BoomHouse si impegna a fornire informazioni accurate e aggiornate sul proprio sito web, ma non 
              garantisce la completezza, l'affidabilità o l'accuratezza di tali informazioni. Qualsiasi 
              utilizzo o affidamento su qualsiasi contenuto o materiale pubblicato sul sito o ottenuto 
              tramite il sito è a tuo rischio.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">2. Informazioni Immobiliari</h2>
            <p>
              Le informazioni relative agli immobili in vendita o in affitto sono fornite da terzi e 
              BoomHouse non è responsabile della loro accuratezza. Gli utenti dovrebbero verificare in modo 
              indipendente tutte le informazioni prima di prendere decisioni basate su di esse.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">3. Calcolatore di Mutui</h2>
            <p>
              Il calcolatore di mutui ipotecari fornito sul nostro sito è solo a scopo indicativo e non 
              costituisce un'offerta di finanziamento. I tassi e le condizioni di un mutuo ipotecario effettivo 
              dipenderanno dalla tua situazione finanziaria personale, dal punteggio di credito e da altri 
              fattori determinati dagli istituti di credito.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">4. Link a Siti di Terzi</h2>
            <p>
              Il nostro sito può contenere link a siti web di terzi. Questi link sono forniti solo per 
              comodità. BoomHouse non ha alcun controllo su questi siti web e non si assume alcuna 
              responsabilità per il loro contenuto.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">5. Consulenza Professionale</h2>
            <p>
              Le informazioni fornite sul nostro sito non costituiscono consulenza legale, fiscale, 
              finanziaria o immobiliare. Per consigli specifici sulla tua situazione, dovresti consultare 
              un professionista qualificato.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">6. Limitazione di Responsabilità</h2>
            <p>
              In nessun caso BoomHouse, i suoi funzionari, direttori, dipendenti, agenti, partner o fornitori 
              saranno responsabili per qualsiasi danno diretto, indiretto, incidentale, speciale, esemplare 
              o consequenziale derivante dall'utilizzo o dall'impossibilità di utilizzare il sito.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">7. Modifiche</h2>
            <p>
              BoomHouse si riserva il diritto di modificare i contenuti di questo disclaimer in qualsiasi 
              momento senza preavviso. Continuando a utilizzare il sito dopo tali modifiche, l'utente accetta 
              i termini modificati.
            </p>
            
            <h2 className="text-xl font-semibold mt-6 mb-4">8. Contattaci</h2>
            <p>
              Per qualsiasi domanda su questo disclaimer, contattaci a: legal@boomhouse.ch
            </p>
          </div>
        </div>
      </main>
    </>
  );
}