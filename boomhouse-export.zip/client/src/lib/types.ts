export type ListingType = "property" | "professional" | "bank";

export interface PropertyType {
  id: number;
  title: string;
  address: string;
  price: string;
  beds?: number;
  baths?: number;
  area: number;
  lat: number;
  lng: number;
  imageUrl: string;
  additionalImages?: string[];
  propertyType: string;
  listingType: "In Vendita" | "In Affitto";
  description?: string;
  features?: string[];
  landArea?: number;
  yearBuilt?: number;
  // Dati catastali
  cadastralNumber?: string;
  cadastralZone?: string;
  cadastralSection?: string;
  cadastralFolio?: string;
  cadastralParcel?: string;
  cadastralSubparcel?: string;
  zoning?: string;
  buildingIndex?: number;
  buildingHeight?: number;
}

export interface ProfessionalType {
  id: number;
  name: string;
  type: "architect" | "notary" | "artisan";
  address: string;
  lat: number;
  lng: number;
  phone?: string;
  email?: string;
  description?: string;
}

export interface BankType {
  id: number;
  name: string;
  address: string;
  lat: number;
  lng: number;
  phone?: string;
  email?: string;
  website?: string;
  logoUrl?: string;
}

export interface FilterType {
  searchQuery?: string;
  propertyType: string;
  location: string;
  postalCode?: string;
  minPrice?: number;
  maxPrice?: number;
  features?: string[];
  professionalType?: "all" | "architect" | "notary" | "artisan";
  listingType?: "all" | "In Vendita" | "In Affitto";
  // Filtri catastali
  cadastralNumber?: string;
  cadastralZone?: string;
  cadastralSection?: string;
  cadastralFolio?: string;
  cadastralParcel?: string;
  minBuildingIndex?: number;
  maxBuildingIndex?: number;
  minBuildingHeight?: number;
  maxBuildingHeight?: number;
  zoning?: string;
  showCadastralOnly?: boolean;
}
