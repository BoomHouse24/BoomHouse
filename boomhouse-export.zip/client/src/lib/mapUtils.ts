import { ListingType } from "./types";

// Crea un'icona personalizzata per i marker sulla mappa
export function createMarkerIcon(type: ListingType): any {
  // Se Leaflet non è stato ancora caricato, restituisci una funzione vuota
  if (typeof window === 'undefined' || !window.L) {
    return {};
  }
  
  const L = window.L;
  let bgColor = "";
  let iconHTML = "";
  
  // Personalizza l'icona in base al tipo
  if (type === "property") {
    bgColor = "#3b82f6"; // blu
    iconHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4">
        <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
        <polyline points="9 22 9 12 15 12 15 22"></polyline>
      </svg>
    `;
  } else if (type === "professional") {
    bgColor = "#10b981"; // verde
    iconHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4">
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
        <circle cx="12" cy="7" r="4"></circle>
      </svg>
    `;
  } else {
    // Banche
    bgColor = "#f59e0b"; // giallo
    iconHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4">
        <rect x="2" y="6" width="20" height="12" rx="2"></rect>
        <path d="M12 12a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"></path>
        <path d="M6 12h.01M18 12h.01"></path>
      </svg>
    `;
  }
  
  // Crea l'HTML dell'icona
  const html = `
    <div style="background-color: ${bgColor}; color: white; border-radius: 50%; width: 32px; height: 32px; display: flex; justify-content: center; align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.3);">
      ${iconHTML}
    </div>
  `;
  
  // Crea e restituisci l'icona
  return L.divIcon({
    html: html,
    className: 'custom-marker-icon',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  });
}