import { db } from "./index";
import * as schema from "@shared/schema";
import { InsertProperty, InsertProfessional, InsertBank } from "@shared/schema";
import { eq } from "drizzle-orm";

async function seed() {
  try {
    console.log("🌱 Seeding database...");

    // Seed properties
    const propertiesData: InsertProperty[] = [
      // Lugano Area Properties
      {
        title: "Attico di Lusso vista lago",
        address: "Via Paradiso 8, Lugano",
        price: "CHF 3.200.000",
        beds: 4,
        baths: 3,
        area: 220,
        propertyType: "Attico",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1493809842364-78817add7ffb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        additionalImages: [
          "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100",
          "https://images.unsplash.com/photo-1560448204-61dc36dc98c8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100"
        ],
        description: "Spettacolare attico con vista panoramica sul lago di Lugano in posizione esclusiva. Questo prestigioso immobile offre ampi spazi abitativi con finiture di altissima qualità, terrazze private, e accesso diretto all'ascensore. Dotato di domotica avanzata, sistema di sicurezza e due posti auto nel garage sotterraneo.",
        features: ["Vista Lago", "Terrazza", "Domotica", "Ascensore Privato", "Garage", "Piscina Condominiale"],
        lat: 46.005,
        lng: 8.967,
        landArea: 0,
        yearBuilt: 2018,
        cadastralNumber: "CH-TI-1001",
        cadastralZone: "Lugano",
        cadastralSection: "A",
        cadastralFolio: "5",
        cadastralParcel: "123",
        zoning: "Residenziale",
        buildingIndex: 0.8,
        buildingHeight: 21
      },
      {
        title: "Appartamento Moderno Castagnola",
        address: "Via San Giorgio 15, Castagnola",
        price: "CHF 3.500/mese",
        beds: 3,
        baths: 2,
        area: 130,
        propertyType: "Appartamento",
        listingType: "In Affitto",
        imageUrl: "https://images.unsplash.com/photo-1584622781564-1d987f7333c1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        additionalImages: [
          "https://images.unsplash.com/photo-1574362848149-11496d93a7c7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100",
          "https://images.unsplash.com/photo-1560185893-a55cbc8c57e8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100"
        ],
        description: "Raffinato appartamento in stile contemporaneo nel caratteristico quartiere di Castagnola. L'immobile è dotato di ampie finestre che offrono una vista mozzafiato sul lago e le montagne circostanti. Recentemente ristrutturato con materiali pregiati, dispone di tre camere da letto, due bagni moderni e una spaziosa zona giorno con cucina aperta.",
        features: ["Vista Lago", "Ristrutturato", "Riscaldamento a Pavimento", "Balcone", "Cantina"],
        lat: 46.009,
        lng: 8.975,
        landArea: 0,
        yearBuilt: 1990,
        cadastralNumber: "CH-TI-1002",
        cadastralZone: "Castagnola",
        cadastralSection: "B",
        cadastralFolio: "8",
        cadastralParcel: "456",
        zoning: "Residenziale",
        buildingIndex: 0.6,
        buildingHeight: 15
      },
      {
        title: "Ufficio Premium Lugano Centro",
        address: "Via Nassa 12, Lugano",
        price: "CHF 1.850.000",
        area: 160,
        propertyType: "Commerciale",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1497366811353-6870744d04b2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        additionalImages: [
          "https://images.unsplash.com/photo-1604328698692-f76ea9498e76?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100",
          "https://images.unsplash.com/photo-1497215842964-222b430dc094?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100"
        ],
        description: "Prestigioso spazio per uffici situato nella rinomata Via Nassa nel cuore di Lugano. Questo immobile di 160 m² offre un ambiente di lavoro raffinato con finiture di alto livello, suddiviso in sei stanze luminose, sala riunioni e due bagni. L'immobile è provvisto di aria condizionata, fibra ottica e sistema di sicurezza avanzato.",
        features: ["Posizione Centrale", "Alta Visibilità", "Aria Condizionata", "Fibra Ottica", "Sistema di Sicurezza"],
        lat: 46.003,
        lng: 8.95,
        landArea: 0,
        yearBuilt: 2005,
        cadastralNumber: "CH-TI-1003",
        cadastralZone: "Lugano",
        cadastralSection: "C",
        cadastralFolio: "3",
        cadastralParcel: "789",
        zoning: "Commerciale",
        buildingIndex: 1.0,
        buildingHeight: 17
      },
      
      // Bellinzona Area Properties
      {
        title: "Villetta Bifamiliare Giubiasco",
        address: "Via Fabiana 23, Giubiasco",
        price: "CHF 1.250.000",
        beds: 4,
        baths: 3,
        area: 180,
        propertyType: "Villa",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1576941089067-2de3c901e126?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        description: "Elegante villetta bifamiliare situata in zona residenziale tranquilla a Giubiasco. Disposta su tre livelli, offre spazi abitativi ampi e luminosi con quattro camere da letto, tre bagni, soggiorno con camino e cucina abitabile. Completa la proprietà un giardino ben curato, una taverna al piano seminterrato e un garage doppio.",
        features: ["Giardino", "Taverna", "Garage Doppio", "Camino", "Zona Tranquilla"],
        lat: 46.178,
        lng: 9.001,
        landArea: 380,
        yearBuilt: 2005,
        cadastralNumber: "CH-TI-1004",
        cadastralZone: "Giubiasco",
        cadastralSection: "D",
        cadastralFolio: "12",
        cadastralParcel: "234",
        zoning: "Residenziale",
        buildingIndex: 0.45,
        buildingHeight: 9
      },
      {
        title: "Spazioso Attico Sementina",
        address: "Via dei Fiori 8, Sementina",
        price: "CHF 1.050.000",
        beds: 3,
        baths: 2,
        area: 140,
        propertyType: "Attico",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        additionalImages: [
          "https://images.unsplash.com/photo-1560185007-c5ca9d2c014d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100",
          "https://images.unsplash.com/photo-1561023127-c7122e1f5447?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100"
        ],
        description: "Luminoso attico in un recente condominio di Sementina con vista panoramica sulla valle. L'appartamento dispone di tre ampie camere da letto, due bagni, e una spaziosa zona living con accesso a un'ampia terrazza di 50 m². Completano la proprietà una cantina, un ripostiglio e due posti auto coperti.",
        features: ["Terrazza Panoramica", "Ascensore", "Posto Auto Coperto", "Cantina", "Classe Energetica A"],
        lat: 46.183,
        lng: 8.996,
        landArea: 0,
        yearBuilt: 2018,
        cadastralNumber: "CH-TI-1005",
        cadastralZone: "Sementina",
        cadastralSection: "E",
        cadastralFolio: "7",
        cadastralParcel: "345",
        zoning: "Residenziale",
        buildingIndex: 0.7,
        buildingHeight: 12
      },
      {
        title: "Appartamento Storico Centro Bellinzona",
        address: "Piazza Nosetto 5, Bellinzona",
        price: "CHF 2.200/mese",
        beds: 2,
        baths: 1,
        area: 95,
        propertyType: "Appartamento",
        listingType: "In Affitto",
        imageUrl: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        description: "Caratteristico appartamento situato in un palazzo storico nel centro di Bellinzona. L'immobile, completamente ristrutturato conservando elementi d'epoca, offre due camere da letto, un bagno, un soggiorno con soffitti alti e una cucina separata. A pochi passi dai castelli UNESCO, negozi e servizi.",
        features: ["Centro Storico", "Ristrutturato", "Elementi d'Epoca", "Soffitti Alti", "Vicino ai Trasporti"],
        lat: 46.192,
        lng: 9.022,
        landArea: 0,
        yearBuilt: 1850,
        cadastralNumber: "CH-TI-1006",
        cadastralZone: "Bellinzona",
        cadastralSection: "F",
        cadastralFolio: "1",
        cadastralParcel: "456",
        zoning: "Centro Storico",
        buildingIndex: 0.9,
        buildingHeight: 14
      },
      
      // Locarno Area Properties
      {
        title: "Villa Moderna Minusio",
        address: "Via San Gottardo 34, Minusio",
        price: "CHF 2.850.000",
        beds: 5,
        baths: 4,
        area: 320,
        propertyType: "Villa",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        additionalImages: [
          "https://images.unsplash.com/photo-1600607688969-a5bfcd646154?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100",
          "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100"
        ],
        description: "Straordinaria villa contemporanea costruita nel 2020 a Minusio con vista sul Lago Maggiore. Questa proprietà di design offre interni spaziosi con cinque camere da letto, quattro bagni, un soggiorno a doppia altezza e una cucina di alta gamma. All'esterno, un giardino paesaggistico con piscina a sfioro, zona relax e terrazza panoramica.",
        features: ["Vista Lago", "Piscina a Sfioro", "Domotica", "Design Contemporaneo", "Impianto Fotovoltaico", "Garage Triplo"],
        lat: 46.178,
        lng: 8.8,
        landArea: 1100,
        yearBuilt: 2020,
        cadastralNumber: "CH-TI-1007",
        cadastralZone: "Minusio",
        cadastralSection: "G",
        cadastralFolio: "9",
        cadastralParcel: "567",
        zoning: "Residenziale",
        buildingIndex: 0.5,
        buildingHeight: 10.5
      },
      {
        title: "Residenza Turistico-Alberghiera Muralto",
        address: "Via Sempione 10, Muralto",
        price: "CHF 875.000",
        beds: 2,
        baths: 2,
        area: 85,
        propertyType: "Appartamento",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        description: "Elegante appartamento all'interno di una residenza turistico-alberghiera a Muralto, a pochi passi dal Lago Maggiore. L'unità completamente arredata offre due camere da letto, due bagni, una zona giorno con angolo cottura e un balcone con vista sul lago. La struttura dispone di servizi alberghieri come reception, pulizia e manutenzione.",
        features: ["Vista Lago", "Servizi Alberghieri", "Arredato", "Balcone", "Vicino alla Stazione"],
        lat: 46.171,
        lng: 8.8,
        landArea: 0,
        yearBuilt: 2010,
        cadastralNumber: "CH-TI-1008",
        cadastralZone: "Muralto",
        cadastralSection: "H",
        cadastralFolio: "5",
        cadastralParcel: "678",
        zoning: "Turistico",
        buildingIndex: 1.1,
        buildingHeight: 22
      },
      {
        title: "Negozio Centro Locarno",
        address: "Piazza Grande 25, Locarno",
        price: "CHF 3.600/mese",
        area: 70,
        propertyType: "Commerciale",
        listingType: "In Affitto",
        imageUrl: "https://images.unsplash.com/photo-1581349437898-cebbe9831942?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        description: "Locale commerciale in posizione privilegiata su Piazza Grande a Locarno, ideale per negozio al dettaglio o showroom. Il locale offre un'ampia vetrina, uno spazio principale di 70 m² e un magazzino di 15 m². Completamente ristrutturato con impianti a norma, aria condizionata e sistema di allarme.",
        features: ["Posizione Premium", "Ampia Vetrina", "Aria Condizionata", "Magazzino", "Alta Visibilità"],
        lat: 46.168,
        lng: 8.793,
        landArea: 0,
        yearBuilt: 1920,
        cadastralNumber: "CH-TI-1009",
        cadastralZone: "Locarno",
        cadastralSection: "I",
        cadastralFolio: "2",
        cadastralParcel: "789",
        zoning: "Commerciale",
        buildingIndex: 1.4,
        buildingHeight: 16
      },
      
      // Mendrisio Area Properties
      {
        title: "Rustico Ristrutturato Tremona",
        address: "Via al Castello 6, Tremona",
        price: "CHF 890.000",
        beds: 3,
        baths: 2,
        area: 150,
        propertyType: "Rustico",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1598228723793-52759bba239c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        description: "Affascinante rustico completamente ristrutturato nel borgo storico di Tremona. Questa casa in pietra del XVIII secolo è stata sapientemente restaurata combinando elementi originali con comfort moderni. Offre tre camere da letto, due bagni, una spaziosa zona giorno con camino a legna e una cucina in stile country. All'esterno, un grazioso giardino terrazzato con pergolato.",
        features: ["Ristrutturato", "Elementi Originali", "Camino", "Giardino Terrazzato", "Vista Panoramica"],
        lat: 45.884,
        lng: 8.95,
        landArea: 250,
        yearBuilt: 1780,
        cadastralNumber: "CH-TI-1010",
        cadastralZone: "Tremona",
        cadastralSection: "L",
        cadastralFolio: "4",
        cadastralParcel: "123",
        zoning: "Centro Storico",
        buildingIndex: 0.3,
        buildingHeight: 8
      },
      {
        title: "Appartamento Duplex Mendrisio",
        address: "Via Praella 8, Mendrisio",
        price: "CHF 1.150.000",
        beds: 4,
        baths: 2,
        area: 160,
        propertyType: "Appartamento",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1567767292278-a4f21aa2d36e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        additionalImages: [
          "https://images.unsplash.com/photo-1588854337221-4cf9fa96059c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100",
          "https://images.unsplash.com/photo-1583608205776-bfd35f0d9f83?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100"
        ],
        description: "Elegante appartamento duplex in una palazzina di nuova costruzione nel cuore di Mendrisio. Distribuito su due livelli, offre quattro camere da letto, due bagni, una spaziosa zona giorno open-space e una cucina di design. Dotato di riscaldamento a pavimento, domotica e finiture di alta qualità. Completa la proprietà un'ampia terrazza, cantina e due posti auto.",
        features: ["Duplex", "Terrazza", "Domotica", "Classe Energetica A", "Posto Auto", "Cantina"],
        lat: 45.869,
        lng: 8.981,
        landArea: 0,
        yearBuilt: 2022,
        cadastralNumber: "CH-TI-1011",
        cadastralZone: "Mendrisio",
        cadastralSection: "M",
        cadastralFolio: "6",
        cadastralParcel: "234",
        zoning: "Residenziale",
        buildingIndex: 0.8,
        buildingHeight: 13
      },
      
      // Biasca and Valle Leventina Properties
      {
        title: "Chalet Tradizionale Airolo",
        address: "Via San Gottardo 45, Airolo",
        price: "CHF 695.000",
        beds: 3,
        baths: 2,
        area: 120,
        propertyType: "Chalet",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1542718610-a1d656d1884c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        description: "Autentico chalet alpino immerso nella natura ad Airolo, vicino alle piste sciistiche. Questa accogliente proprietà in legno offre tre camere da letto, due bagni, un soggiorno con stufa a legna e una cucina in stile montano. Terrazza panoramica, giardino privato e un piccolo deposito per attrezzature da sci completano l'offerta.",
        features: ["Stile Alpino", "Stufa a Legna", "Terrazza", "Vicino alle Piste", "Giardino"],
        lat: 46.529,
        lng: 8.612,
        landArea: 400,
        yearBuilt: 1985,
        cadastralNumber: "CH-TI-1012",
        cadastralZone: "Airolo",
        cadastralSection: "N",
        cadastralFolio: "11",
        cadastralParcel: "345",
        zoning: "Turistico",
        buildingIndex: 0.3,
        buildingHeight: 7.5
      },
      {
        title: "Appartamento Residenziale Faido",
        address: "Via Stazione 12, Faido",
        price: "CHF 1.850/mese",
        beds: 3,
        baths: 1,
        area: 95,
        propertyType: "Appartamento",
        listingType: "In Affitto",
        imageUrl: "https://images.unsplash.com/photo-1585128792020-803d29415281?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        description: "Luminoso appartamento di 3,5 locali situato in zona tranquilla a Faido. L'immobile si compone di un soggiorno con accesso al balcone, una cucina separata, tre camere da letto e un bagno. A disposizione cantina e posto auto esterno. Posizione comoda vicino alla stazione ferroviaria e ai servizi.",
        features: ["Balcone", "Cantina", "Posto Auto", "Vicino ai Trasporti", "Recentemente Rinnovato"],
        lat: 46.481,
        lng: 8.792,
        landArea: 0,
        yearBuilt: 1995,
        cadastralNumber: "CH-TI-1013",
        cadastralZone: "Faido",
        cadastralSection: "O",
        cadastralFolio: "8",
        cadastralParcel: "456",
        zoning: "Residenziale",
        buildingIndex: 0.5,
        buildingHeight: 10
      },
      
      // Valle Maggia Properties
      {
        title: "Rustico con Giardino Cevio",
        address: "Via Principale 8, Cevio",
        price: "CHF 850.000",
        beds: 3,
        baths: 2,
        area: 140,
        propertyType: "Rustico",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1518780664697-55e3ad937233?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        description: "Affascinante rustico completamente ristrutturato nel cuore della Valle Maggia. Questa proprietà del XVIII secolo combina materiali tradizionali con comfort moderni. Dispone di tre camere da letto, due bagni, e una spaziosa zona giorno con camino e travi a vista. Il giardino pianeggiante di 200 m² offre viste panoramiche sulle montagne circostanti.",
        features: ["Ristrutturato", "Camino", "Travi a Vista", "Giardino", "Vista Montagne"],
        lat: 46.318,
        lng: 8.603,
        landArea: 350,
        yearBuilt: 1780,
        cadastralNumber: "CH-TI-1014",
        cadastralZone: "Cevio",
        cadastralSection: "P",
        cadastralFolio: "10",
        cadastralParcel: "567",
        zoning: "Nucleo Storico",
        buildingIndex: 0.4,
        buildingHeight: 7.5
      },
      {
        title: "Villa di Campagna Maggia",
        address: "Via Campagna 15, Maggia",
        price: "CHF 1.480.000",
        beds: 4,
        baths: 3,
        area: 210,
        propertyType: "Villa",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1602343168117-bb8ffe3e2e9f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        additionalImages: [
          "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100",
          "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100"
        ],
        description: "Splendida villa immersa nel verde della Valle Maggia. Costruita nel 2010 con materiali di alta qualità, offre ampi spazi abitativi distribuiti su due livelli. La proprietà comprende quattro camere da letto, tre bagni, una cucina moderna, un ampio soggiorno con accesso diretto al portico e un ufficio. Il terreno di 800 m² include un giardino ben curato con piscina e area barbecue.",
        features: ["Piscina", "Portico", "Giardino", "Ufficio", "Garage", "Pannelli Solari"],
        lat: 46.264,
        lng: 8.691,
        landArea: 800,
        yearBuilt: 2010,
        cadastralNumber: "CH-TI-1015",
        cadastralZone: "Maggia",
        cadastralSection: "Q",
        cadastralFolio: "6",
        cadastralParcel: "678",
        zoning: "Residenziale",
        buildingIndex: 0.3,
        buildingHeight: 8
      },
      
      // Riviera e Valli Properties
      {
        title: "Appartamento con Giardino Biasca",
        address: "Via Lucomagno 18, Biasca",
        price: "CHF 550.000",
        beds: 3,
        baths: 2,
        area: 110,
        propertyType: "Appartamento",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1605276374104-dee2a0ed3cd6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        description: "Moderno appartamento al piano terra con giardino privato in una residenza di recente costruzione a Biasca. L'immobile offre tre camere da letto, due bagni, una cucina aperta sul soggiorno e accesso diretto al giardino di 120 m². L'appartamento è dotato di riscaldamento a pavimento, pannelli solari e domotica. Posizione tranquilla ma comoda per tutti i servizi.",
        features: ["Giardino Privato", "Piano Terra", "Riscaldamento a Pavimento", "Domotica", "Classe Energetica A"],
        lat: 46.362,
        lng: 8.97,
        landArea: 120,
        yearBuilt: 2020,
        cadastralNumber: "CH-TI-1016",
        cadastralZone: "Biasca",
        cadastralSection: "R",
        cadastralFolio: "9",
        cadastralParcel: "789",
        zoning: "Residenziale",
        buildingIndex: 0.5,
        buildingHeight: 9
      },
      {
        title: "Terreno con Progetto Approvato Cresciano",
        address: "Via ai Monti, Cresciano",
        price: "CHF 450.000",
        area: 0,
        propertyType: "Terreno",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        description: "Terreno edificabile di 700 m² situato in posizione privilegiata a Cresciano con vista panoramica sulla valle. Venduto con progetto approvato per la costruzione di una villa unifamiliare di 200 m² su due livelli con piscina. Il progetto include ampio soggiorno, cucina separata, tre camere da letto, due bagni, taverna e garage doppio. Tutte le utenze già predisposte.",
        features: ["Progetto Approvato", "Vista Panoramica", "Zona Tranquilla", "Utenze Predisposte", "Orientamento Sud-Ovest"],
        lat: 46.289,
        lng: 8.976,
        landArea: 700,
        cadastralNumber: "CH-TI-1017",
        cadastralZone: "Cresciano",
        cadastralSection: "S",
        cadastralFolio: "14",
        cadastralParcel: "890",
        zoning: "Residenziale",
        buildingIndex: 0.4,
        buildingHeight: 8.5
      },
      {
        title: "Villa di Lusso",
        address: "Via Cantonale 23, Lugano",
        price: "CHF 2.450.000",
        beds: 4,
        baths: 3,
        area: 280,
        propertyType: "Villa",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        additionalImages: [
          "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100",
          "https://images.unsplash.com/photo-1556911220-bff31c812dba?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100",
          "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100",
          "https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100"
        ],
        description: "Questa magnifica villa moderna è situata in una prestigiosa zona di Lugano con viste mozzafiato sul lago. Costruita nel 2015 con materiali di alta qualità, la proprietà dispone di una zona giorno open-concept con finestre a tutta altezza, una cucina di design, quattro ampie camere da letto e tre bagni elegantemente arredati. La villa offre un giardino privato con piscina, una terrazza coperta per ricevere ospiti e un garage per due auto. Le caratteristiche aggiuntive includono riscaldamento a pavimento, aria condizionata e un sofisticato sistema di sicurezza.",
        features: ["Piscina", "Giardino", "Garage (2 posti)", "Aria Condizionata", "Riscaldamento a Pavimento", "Sistema di Sicurezza"],
        lat: 46.003,
        lng: 8.951,
        landArea: 950,
        yearBuilt: 2015,
        cadastralNumber: "CH-TI-1234",
        cadastralZone: "Lugano",
        cadastralSection: "B",
        cadastralFolio: "12",
        cadastralParcel: "567",
        zoning: "Residenziale",
        buildingIndex: 0.7,
        buildingHeight: 12.5
      },
      {
        title: "Appartamento Moderno",
        address: "Via Monte Boglia 12, Lugano",
        price: "CHF 2.800/mese",
        beds: 2,
        baths: 2,
        area: 110,
        propertyType: "Appartamento",
        listingType: "In Affitto",
        imageUrl: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        additionalImages: [
          "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100",
          "https://images.unsplash.com/photo-1565183928294-7063f23ce0f8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100"
        ],
        description: "Elegante e contemporaneo appartamento con vista panoramica sul Lago di Lugano. Questa spaziosa proprietà presenta finiture di alta gamma, con un luminoso soggiorno open-space, una cucina moderna con elettrodomestici premium, due confortevoli camere da letto e due bagni eleganti. L'ampio balcone offre una vista mozzafiato e uno spazio per cenare all'aperto. I servizi dell'edificio includono parcheggio sotterraneo, ripostiglio e un giardino comune.",
        features: ["Balcone", "Vista Lago", "Parcheggio Sotterraneo", "Ripostiglio"],
        lat: 46.008,
        lng: 8.956,
        cadastralNumber: "CH-TI-2345",
        cadastralZone: "Lugano",
        cadastralSection: "A",
        cadastralFolio: "8",
        cadastralParcel: "123",
        zoning: "Residenziale",
        buildingIndex: 0.5,
        buildingHeight: 18
      },
      {
        title: "Spazio Ufficio",
        address: "Piazza Collegiata, Bellinzona",
        price: "CHF 950.000",
        area: 180,
        propertyType: "Commerciale",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1564069114553-7215e1ff1890?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        description: "Spazio commerciale di prima qualità nel cuore del centro storico di Bellinzona. Questo ufficio ben mantenuto dispone di 8 stanze, 2 bagni e un angolo cottura. La proprietà è stata recentemente ristrutturata con installazioni moderne pur conservando elementi storici. Posizione ideale vicino a edifici governativi, trasporti pubblici e servizi.",
        features: ["Posizione Centrale", "Recentemente Ristrutturato", "Edificio Storico", "Accesso ai Trasporti Pubblici"],
        lat: 46.196,
        lng: 9.024,
        cadastralNumber: "CH-TI-3456",
        cadastralZone: "Bellinzona",
        cadastralSection: "C",
        cadastralFolio: "15",
        cadastralParcel: "789",
        zoning: "Commerciale",
        buildingIndex: 0.8,
        buildingHeight: 14
      },
      {
        title: "Casa Rustica a Biasca",
        address: "Via Chiasso 23, Biasca",
        price: "CHF 780.000",
        beds: 4,
        baths: 2,
        area: 180,
        propertyType: "Casa",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        additionalImages: [
          "https://images.unsplash.com/photo-1599619351208-3e6c839d6828?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100",
          "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100"
        ],
        description: "Affascinante casa rustica completamente ristrutturata a Biasca. Questa abitazione tradizionale svizzera combina elementi storici con comfort moderni. La casa dispone di 4 camere da letto, 2 bagni, una spaziosa cucina in stile rustico e un accogliente soggiorno con camino in pietra. Il giardino privato offre uno splendido panorama sulle montagne circostanti. La proprietà include anche una cantina, un ripostiglio esterno e un parcheggio per due auto.",
        features: ["Ristrutturata", "Camino", "Giardino", "Vista Montagne", "Cantina", "Elementi Storici"],
        lat: 46.361,
        lng: 8.971,
        landArea: 450,
        yearBuilt: 1890,
        cadastralNumber: "CH-TI-4567",
        cadastralZone: "Biasca",
        cadastralSection: "D",
        cadastralFolio: "22",
        cadastralParcel: "345",
        zoning: "Residenziale",
        buildingIndex: 0.45,
        buildingHeight: 9.5
      },
      {
        title: "Terreno Edificabile a Bellinzona",
        address: "Via San Giovanni, Bellinzona",
        price: "CHF 580.000",
        area: 0,
        propertyType: "Terreno",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        additionalImages: [
          "https://images.unsplash.com/photo-1591825729269-caeb344f6df2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=100"
        ],
        description: "Ampio terreno edificabile situato in una posizione strategica a Bellinzona. Questo lotto di 1200 m² è ideale per la costruzione di una villa unifamiliare o bifamiliare. Il terreno si trova in una zona residenziale tranquilla ma vicina a tutti i servizi essenziali. Ha una vista panoramica sulle montagne e i castelli di Bellinzona. Tutte le utenze sono già predisposte a bordo lotto. Indice di edificabilità: 0.5.",
        features: ["Edificabile", "Vista Panoramica", "Utenze Predisposte", "Zona Residenziale"],
        lat: 46.193,
        lng: 9.030,
        landArea: 1200,
        cadastralNumber: "CH-TI-5678",
        cadastralZone: "Bellinzona",
        cadastralSection: "A",
        cadastralFolio: "7",
        cadastralParcel: "456",
        zoning: "Residenziale",
        buildingIndex: 0.5,
        buildingHeight: 11
      },
      {
        title: "Loft Industriale a Biasca",
        address: "Via della Stazione 12, Biasca",
        price: "CHF 1.600/mese",
        beds: 1,
        baths: 1,
        area: 85,
        propertyType: "Loft",
        listingType: "In Affitto",
        imageUrl: "https://images.unsplash.com/photo-1536376072261-38c75010e6c9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        description: "Moderno loft industriale ricavato da un'ex officina a Biasca. Questo spazio open-space è caratterizzato da soffitti alti, travi a vista e ampie finestre che garantiscono abbondante luce naturale. Il loft include una zona giorno spaziosa, una camera da letto soppalcata, un bagno moderno e una cucina completamente attrezzata. L'appartamento è a pochi passi dalla stazione ferroviaria e da tutti i servizi del centro città.",
        features: ["Open Space", "Soffitti Alti", "Stile Industriale", "Vicino ai Trasporti", "Arredato"],
        lat: 46.358,
        lng: 8.969,
        yearBuilt: 2020,
        cadastralNumber: "CH-TI-6789",
        cadastralZone: "Biasca",
        cadastralSection: "E",
        cadastralFolio: "3",
        cadastralParcel: "567",
        zoning: "Misto",
        buildingIndex: 0.9,
        buildingHeight: 12
      },
      {
        title: "Edificio Commerciale a Bellinzona",
        address: "Viale Stazione 15, Bellinzona",
        price: "CHF 1.850.000",
        area: 350,
        propertyType: "Commerciale",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        description: "Edificio commerciale completamente rinnovato nel centro di Bellinzona. La struttura si sviluppa su tre piani per un totale di 350 m². Il piano terra è attualmente adibito a negozio con ampia vetrina su strada, mentre i due piani superiori ospitano uffici moderni e funzionali. L'immobile gode di una posizione strategica vicino alla stazione ferroviaria e al centro storico. L'edificio è dotato di ascensore, sistema di climatizzazione centralizzato e impianto di allarme.",
        features: ["Posizione Strategica", "Rinnovato", "Vetrine su Strada", "Ascensore", "Climatizzazione"],
        lat: 46.197,
        lng: 9.026,
        yearBuilt: 1970,
        cadastralNumber: "CH-TI-7890",
        cadastralZone: "Bellinzona",
        cadastralSection: "B",
        cadastralFolio: "9",
        cadastralParcel: "678",
        zoning: "Commerciale",
        buildingIndex: 1.2,
        buildingHeight: 15
      },
      {
        title: "Terreno Agricolo a Lodrino",
        address: "Via ai Ronchi, Lodrino",
        price: "CHF 320.000",
        area: 0,
        propertyType: "Terreno",
        listingType: "In Vendita",
        imageUrl: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
        description: "Ampio terreno agricolo di 8000 m² situato nella soleggiata valle di Lodrino. Il terreno è pianeggiante e facilmente accessibile dalla strada principale. Attualmente coltivato a prato, è ideale per l'agricoltura o l'allevamento di piccoli animali. La proprietà include una piccola struttura in pietra che può essere ristrutturata come ricovero attrezzi. Possibilità di allacciamento all'acquedotto comunale.",
        features: ["Terreno Pianeggiante", "Facilmente Accessibile", "Soleggiato", "Struttura in Pietra"],
        lat: 46.3,
        lng: 8.98,
        landArea: 8000,
        cadastralNumber: "CH-TI-8901",
        cadastralZone: "Lodrino",
        cadastralSection: "F",
        cadastralFolio: "14",
        cadastralParcel: "789",
        zoning: "Agricolo",
        buildingIndex: 0.05,
        buildingHeight: 5
      }
    ];

    // Seed professionals
    const professionalsData: InsertProfessional[] = [
      {
        name: "Studio Architetti Associati",
        type: "architect",
        address: "Via Nassa 29, Lugano",
        phone: "+41 91 234 5678",
        email: "info@architetti-associati.ch",
        description: "Studio di architettura pluripremiato specializzato in design residenziale e commerciale con particolare attenzione alla sostenibilità e all'estetica alpina.",
        lat: 46.005,
        lng: 8.946
      },
      {
        name: "Architekten Planungsgruppe",
        type: "architect",
        address: "Via San Gottardo 14, Bellinzona",
        phone: "+41 91 345 6789",
        email: "contact@planungsgruppe.ch",
        description: "Studio di architettura leader con competenze in pianificazione urbana, ristrutturazione di edifici storici e sviluppi residenziali moderni.",
        lat: 46.197,
        lng: 9.020
      },
      {
        name: "Notaio Rossi & Associati",
        type: "notary",
        address: "Via Pretorio 7, Lugano",
        phone: "+41 91 456 7890",
        email: "info@notaiorossi.ch",
        description: "Studio notarile affermato che fornisce servizi completi per transazioni immobiliari, contratti commerciali e pianificazione successoria.",
        lat: 46.004,
        lng: 8.953
      },
      {
        name: "Studio Notarile Bianchi",
        type: "notary",
        address: "Piazza Grande 8, Locarno",
        phone: "+41 91 567 8901",
        email: "contatto@notarilebianchi.ch",
        description: "Ufficio notarile di fiducia con decenni di esperienza nella gestione di trasferimenti immobiliari, documentazione legale e questioni successorie.",
        lat: 46.170,
        lng: 8.798
      },
      {
        name: "Swiss Artigiani Costruzioni",
        type: "artisan",
        address: "Via Industria 22, Mendrisio",
        phone: "+41 91 678 9012",
        email: "info@ticinoartigiani.ch",
        description: "Team di specialisti edili qualificati che offrono servizi di ristrutturazione, restauro e costruzione su misura in tutta la Svizzera.",
        lat: 46.040,
        lng: 8.960
      },
      {
        name: "Studio d'Architettura Bernasconi",
        type: "architect",
        address: "Via Parallela 8, Biasca",
        phone: "+41 91 789 0123",
        email: "studio@bernasconi-arch.ch",
        description: "Studio di architettura locale specializzato in progetti residenziali e recupero di edifici storici nella regione di Biasca e delle Tre Valli.",
        lat: 46.360,
        lng: 8.970
      },
      {
        name: "Biasca Notai Sagl",
        type: "notary",
        address: "Piazza Centrale 5, Biasca",
        phone: "+41 91 890 1234",
        email: "info@biascanotai.ch",
        description: "Studio notarile che serve la comunità di Biasca e dintorni, offrendo consulenza per compravendite immobiliari, successioni e costituzioni societarie.",
        lat: 46.359,
        lng: 8.971
      },
      {
        name: "Bellinzona Costruzioni SA",
        type: "artisan",
        address: "Via Industria 14, Bellinzona",
        phone: "+41 91 901 2345",
        email: "info@bellinzonacostruzioni.ch",
        description: "Impresa di costruzioni con oltre 30 anni di esperienza nella realizzazione e ristrutturazione di edifici residenziali e commerciali nel Bellinzonese.",
        lat: 46.195,
        lng: 9.022
      },
      {
        name: "Studio Tecnico Martinelli",
        type: "architect",
        address: "Via Lavizzari 18, Bellinzona",
        phone: "+41 91 912 3456",
        email: "info@martinelli-tecnico.ch",
        description: "Studio tecnico che offre servizi di progettazione architettonica, direzione lavori e consulenza energetica con particolare attenzione alla sostenibilità.",
        lat: 46.194,
        lng: 9.025
      },
      {
        name: "Artigiani Ticino Sagl",
        type: "artisan",
        address: "Via Chiasso 9, Biasca",
        phone: "+41 91 923 4567",
        email: "contatto@artigianiticino.ch",
        description: "Cooperativa di artigiani locali specializzati in falegnameria, carpenteria, idraulica ed elettricità per ristrutturazioni di qualità.",
        lat: 46.362,
        lng: 8.969
      }
    ];

    // Seed banks
    const banksData: InsertBank[] = [
      {
        name: "BancaStato",
        address: "Via Pioda 7, Lugano",
        phone: "+41 91 789 0123",
        email: "info@bancastato.ch",
        website: "https://www.bancastato.ch",
        lat: 46.040,
        lng: 8.960,
        logoUrl: "/static/images/banks/bank-banca-stato.svg"
      },
      {
        name: "UBS Switzerland AG",
        address: "Via Pretorio 14, Lugano",
        phone: "+41 91 890 1234",
        email: "info@ubs.com",
        website: "https://www.ubs.com/ch/it.html",
        lat: 46.003,
        lng: 8.950,
        logoUrl: "/static/images/banks/bank-ubs.svg"
      },
      {
        name: "Credit Suisse",
        address: "Piazza della Riforma 3, Lugano",
        phone: "+41 91 901 2345",
        email: "info@credit-suisse.ch",
        website: "https://www.credit-suisse.com/ch/it.html",
        lat: 46.002,
        lng: 8.952,
        logoUrl: "/static/images/banks/bank-credit-suisse.svg"
      },
      {
        name: "Raiffeisen",
        address: "Via Canova 15, Lugano",
        phone: "+41 91 912 3456",
        email: "info@raiffeisen.ch",
        website: "https://www.raiffeisen.ch/lugano/it.html",
        lat: 46.000,
        lng: 8.955,
        logoUrl: "https://www.raiffeisen.ch/etc/designs/raiffeisen-internet/clientlib-all/images/logo/raiffeisen-logo.svg"
      },
      {
        name: "PostFinance",
        address: "Via Serafino Balestra 22, Lugano",
        phone: "+41 91 923 4567",
        email: "contact@postfinance.ch",
        website: "https://www.postfinance.ch/it/privati.html",
        lat: 46.006,
        lng: 8.948,
        logoUrl: "https://www.postfinance.ch/content/dam/pfch/images-template/frame/en/logo.svg"
      }
    ];

    // Insert data into database (handle existing data gracefully)
    // Pulisci la tabella properties per reinserire tutti i nuovi dati
    console.log("Removing existing properties...");
    await db.delete(schema.properties);
    
    console.log("Seeding all properties...");
    for (const property of propertiesData) {
      await db.insert(schema.properties).values(property);
    }
    console.log(`Added ${propertiesData.length} properties to the database`);

    const existingProfessionals = await db.query.professionals.findMany();
    if (existingProfessionals.length === 0) {
      console.log("Seeding professionals...");
      for (const professional of professionalsData) {
        await db.insert(schema.professionals).values(professional);
      }
    } else {
      console.log("Updating professionals data...");
      // Find and update the artisan with the new name and description
      const artisan = existingProfessionals.find(p => p.type === "artisan");
      if (artisan) {
        await db.update(schema.professionals)
          .set({
            name: "Swiss Artigiani Costruzioni",
            description: "Skilled team of construction specialists offering renovation, restoration, and custom building services throughout Switzerland."
          })
          .where(eq(schema.professionals.id, artisan.id));
        console.log("Updated artisan professional");
      }
    }

    const existingBanks = await db.query.banks.findMany();
    if (existingBanks.length === 0) {
      console.log("Seeding banks...");
      for (const bank of banksData) {
        await db.insert(schema.banks).values(bank);
      }
    } else {
      console.log("Updating banks data...");
      // Aggiornamento dei dati delle banche esistenti con nuovi loghi e URL completi
      for (let i = 0; i < Math.min(existingBanks.length, banksData.length); i++) {
        await db.update(schema.banks)
          .set({
            name: banksData[i].name,
            website: banksData[i].website,
            logoUrl: banksData[i].logoUrl
          })
          .where(eq(schema.banks.id, existingBanks[i].id));
      }
      
      // Aggiungi eventuali banche aggiuntive
      if (existingBanks.length < banksData.length) {
        for (let i = existingBanks.length; i < banksData.length; i++) {
          await db.insert(schema.banks).values(banksData[i]);
        }
      }
      console.log("Banks data updated with logos and full website URLs");
    }

    console.log("✅ Seeding complete!");
  } catch (error) {
    console.error("Error seeding database:", error);
  } finally {
    process.exit(0);
  }
}

seed();
