/**
 * Service per l'integrazione con local.ch API
 * Richiede una API key da impostare come variabile d'ambiente LOCALCH_API_KEY
 */

import { Professional } from '@shared/schema';

// Interfaccia per i risultati di ricerca local.ch
interface LocalChResponse {
  results: LocalChResult[];
  total: number;
  page: number;
  pageSize: number;
}

interface LocalChResult {
  id: string;
  name: string;
  type: string;
  address: {
    streetName?: string;
    streetNumber?: string;
    zip?: string;
    city?: string;
    full?: string;
  };
  location?: {
    lat: number;
    lng: number;
  };
  contact?: {
    phone?: string;
    email?: string;
    website?: string;
  };
  category?: string;
}

/**
 * Cerca professionisti su local.ch
 * Se LOCALCH_API_KEY non è impostata, restituirà i dati dal database locale
 */
export async function searchProfessionals(
  query: string, 
  location: string, 
  type: string,
  dbFallbackFn: () => Promise<Professional[]>
): Promise<Professional[]> {
  // Controlla se la API key è impostata
  const apiKey = process.env.LOCALCH_API_KEY;
  
  if (!apiKey) {
    console.log('LOCALCH_API_KEY non impostata, utilizzo dati locali');
    // Se non è impostata, restituisci i professionisti dal database locale
    return dbFallbackFn();
  }
  
  try {
    // Costruisci i parametri di ricerca
    const searchType = mapProfessionalType(type);
    const searchParams = new URLSearchParams({
      q: `${searchType} ${query}`.trim(),
      where: location,
      key: apiKey,
      limit: '10',
    });
    
    // Esegui la richiesta a local.ch API
    const response = await fetch(`https://api.local.ch/v2/search?${searchParams.toString()}`);
    
    if (!response.ok) {
      throw new Error(`Errore nella richiesta local.ch: ${response.statusText}`);
    }
    
    const data: LocalChResponse = await response.json();
    
    // Converti i risultati nel formato Professional
    return data.results.map((result): Professional => ({
      id: parseInt(result.id.replace('localch-', ''), 10),
      name: result.name,
      type: mapLocalChType(result.category || '', type),
      address: formatAddress(result.address),
      lat: result.location?.lat || 46.008,
      lng: result.location?.lng || 8.956,
      phone: result.contact?.phone,
      email: result.contact?.email,
      description: `Professionista trovato su local.ch`,
    }));
  } catch (error) {
    console.error('Errore nella ricerca su local.ch:', error);
    // In caso di errore, restituisci i professionisti dal database locale
    return dbFallbackFn();
  }
}

/**
 * Mappa il tipo di professionista al termine di ricerca appropriato
 */
function mapProfessionalType(type: string): string {
  switch (type) {
    case 'architect':
      return 'architetto';
    case 'notary':
      return 'notaio';
    case 'artisan':
      return 'artigiano';
    default:
      return '';
  }
}

/**
 * Mappa la categoria local.ch al tipo di professionista nel sistema
 */
function mapLocalChType(category: string, defaultType: string): 'architect' | 'notary' | 'artisan' {
  const lcCategory = category.toLowerCase();
  
  if (lcCategory.includes('archit')) {
    return 'architect';
  } else if (lcCategory.includes('notai') || lcCategory.includes('notaries')) {
    return 'notary';
  } else if (lcCategory.includes('artig') || lcCategory.includes('craft')) {
    return 'artisan';
  } else {
    return defaultType as 'architect' | 'notary' | 'artisan';
  }
}

/**
 * Formatta l'indirizzo dai dati local.ch
 */
function formatAddress(address: LocalChResult['address']): string {
  if (address.full) {
    return address.full;
  }
  
  const parts: string[] = [];
  
  if (address.streetName) {
    parts.push(address.streetName);
    
    if (address.streetNumber) {
      parts[0] += ` ${address.streetNumber}`;
    }
  }
  
  if (address.zip || address.city) {
    parts.push(`${address.zip || ''} ${address.city || ''}`.trim());
  }
  
  return parts.join(', ');
}