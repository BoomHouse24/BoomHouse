import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { Property, Professional, Bank, User, properties } from "@shared/schema";
import { eq, and, gte, lte, like, inArray } from "drizzle-orm";
import { searchProfessionals } from "./localch";
import { setupAuth } from "./auth";
import { db } from "../db";
import { favorites } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";
import express, { static as expressStatic } from "express";

// Configurazione per il caricamento delle immagini
const uploadDir = path.join(process.cwd(), 'uploads');

// Assicurati che la directory uploads esista
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configura multer per il caricamento delle immagini
const storage_config = multer.diskStorage({
  destination: function(_req, _file, cb) {
    cb(null, uploadDir);
  },
  filename: function(_req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

// Imposta i tipi di file consentiti
const fileFilter = (_req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Formato file non supportato. Usa JPEG, PNG o WebP.'));
  }
};

const upload = multer({
  storage: storage_config,
  limits: { fileSize: 5 * 1024 * 1024 }, // Limite di 5MB
  fileFilter
});

// Funzioni di supporto per geocoding
function extractStreetFromDisplayName(displayName: string): string {
  // La strada è spesso il primo o secondo elemento
  const parts = displayName.split(',').map(p => p.trim());
  // Se il primo elemento contiene un numero, probabilmente è un indirizzo completo (via + numero)
  if (/\d/.test(parts[0])) {
    // Rimuoviamo il numero dalla strada
    return parts[0].replace(/\s+\d+.*$/, '');
  }
  // Altrimenti il primo elemento è probabilmente il nome della strada
  return parts[0];
}

function extractHouseNumberFromDisplayName(displayName: string): string {
  // Cerchiamo un pattern per il numero civico
  const match = displayName.match(/\b\d+\w*\b/);
  return match ? match[0] : '';
}

function extractCityFromDisplayName(displayName: string): string {
  // La città è spesso il secondo o terzo elemento
  const parts = displayName.split(',').map(p => p.trim());
  // Se abbiamo almeno 2 parti, prendiamo la seconda
  if (parts.length >= 2) {
    // Verifichiamo che non sia un CAP (codice postale)
    const secondPart = parts[1];
    if (!/^\d+$/.test(secondPart)) {
      return secondPart;
    }
    // Se la seconda parte è un CAP, proviamo con la terza
    if (parts.length >= 3) {
      return parts[2];
    }
  }
  return ''; // Fallback
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);
  // API routes for properties
  app.get("/api/properties", async (req, res) => {
    try {
      const { 
        searchQuery,
        propertyType, 
        location, 
        minPrice, 
        maxPrice, 
        features,
        // Filtri catastali
        cadastralNumber,
        cadastralZone,
        cadastralSection,
        cadastralFolio,
        cadastralParcel,
        minBuildingIndex,
        maxBuildingIndex,
        minBuildingHeight,
        maxBuildingHeight,
        zoning,
        showCadastralOnly
      } = req.query;

      // Costruiamo un array di condizioni per i filtri
      let conditions = [];
      
      // Filtro per tipo di proprietà
      if (propertyType && propertyType !== "all") {
        conditions.push(eq(storage.properties.propertyType, propertyType as string));
      }

      // Filtro per località
      if (location && location !== "all") {
        // Usiamo ILIKE per una ricerca case-insensitive nell'indirizzo
        // %location% trova location in qualsiasi posizione dell'indirizzo
        conditions.push(like(storage.properties.address, `%${location}%`));
      }
      
      // Filtro per codice postale
      if (req.query.postalCode) {
        const postalCode = req.query.postalCode as string;
        // Cerca il codice postale nell'indirizzo
        conditions.push(like(storage.properties.address, `%${postalCode}%`));
      }
      
      // Filtro per tipo di annuncio (vendita/affitto)
      if (req.query.listingType && req.query.listingType !== "all") {
        conditions.push(eq(storage.properties.listingType, req.query.listingType as string));
      }
      
      // Eseguiamo la query con le condizioni
      let properties;
      if (conditions.length > 0) {
        // Combiniamo le condizioni con AND
        properties = await storage.db.select().from(storage.properties)
          .where(and(...conditions));
      } else {
        // Senza filtri, otteniamo tutte le proprietà
        properties = await storage.db.select().from(storage.properties);
      }

      // For price filtering, we'd need to parse the price string
      // This is a simplified implementation - fatto in-memory perché price è una stringa
      
      // Ora properties è già stato recuperato dal database
      
      // Apply search query filter in memory (for simplicity)
      let filteredBySearch = properties;
      if (searchQuery && typeof searchQuery === 'string' && searchQuery.trim() !== '') {
        const lowercaseQuery = searchQuery.toLowerCase();
        filteredBySearch = properties.filter(property => 
          (property.title && property.title.toLowerCase().includes(lowercaseQuery)) ||
          (property.address && property.address.toLowerCase().includes(lowercaseQuery)) ||
          (property.propertyType && property.propertyType.toLowerCase().includes(lowercaseQuery)) ||
          (property.description && property.description.toLowerCase().includes(lowercaseQuery))
        );
      }
      
      // Then filter by features (if any) - this is done in memory since features is stored as JSON
      let filteredProperties = filteredBySearch;
      if (features && Array.isArray(features) && features.length > 0) {
        filteredProperties = filteredBySearch.filter(property => {
          if (!property.features) return false;
          return (features as string[]).every(feature => 
            property.features?.includes(feature)
          );
        });
      }

      // Filtri catastali (in-memory filtering)
      
      // Se showCadastralOnly è impostato, mostra solo proprietà con dati catastali
      if (showCadastralOnly === 'true') {
        filteredProperties = filteredProperties.filter(property => 
          property.cadastralNumber || property.cadastralZone || property.cadastralParcel
        );
      }
      
      // Numero catastale
      if (cadastralNumber && typeof cadastralNumber === 'string' && cadastralNumber.trim() !== '') {
        filteredProperties = filteredProperties.filter(property => 
          property.cadastralNumber && property.cadastralNumber.toLowerCase().includes(cadastralNumber.toLowerCase())
        );
      }
      
      // Zona catastale
      if (cadastralZone && typeof cadastralZone === 'string' && cadastralZone.trim() !== '') {
        filteredProperties = filteredProperties.filter(property => 
          property.cadastralZone && property.cadastralZone.toLowerCase().includes(cadastralZone.toLowerCase())
        );
      }
      
      // Sezione catastale
      if (cadastralSection && typeof cadastralSection === 'string' && cadastralSection.trim() !== '') {
        filteredProperties = filteredProperties.filter(property => 
          property.cadastralSection && property.cadastralSection.toLowerCase().includes(cadastralSection.toLowerCase())
        );
      }
      
      // Foglio catastale
      if (cadastralFolio && typeof cadastralFolio === 'string' && cadastralFolio.trim() !== '') {
        filteredProperties = filteredProperties.filter(property => 
          property.cadastralFolio && property.cadastralFolio.toLowerCase().includes(cadastralFolio.toLowerCase())
        );
      }
      
      // Particella catastale
      if (cadastralParcel && typeof cadastralParcel === 'string' && cadastralParcel.trim() !== '') {
        filteredProperties = filteredProperties.filter(property => 
          property.cadastralParcel && property.cadastralParcel.toLowerCase().includes(cadastralParcel.toLowerCase())
        );
      }
      
      // Zonizzazione
      if (zoning && typeof zoning === 'string' && zoning.trim() !== '') {
        filteredProperties = filteredProperties.filter(property => 
          property.zoning && property.zoning.toLowerCase() === zoning.toLowerCase()
        );
      }
      
      // Indice di edificabilità (min)
      if (minBuildingIndex && !isNaN(Number(minBuildingIndex))) {
        const minIndex = Number(minBuildingIndex);
        filteredProperties = filteredProperties.filter(property => 
          property.buildingIndex !== undefined && property.buildingIndex !== null && property.buildingIndex >= minIndex
        );
      }
      
      // Indice di edificabilità (max)
      if (maxBuildingIndex && !isNaN(Number(maxBuildingIndex))) {
        const maxIndex = Number(maxBuildingIndex);
        filteredProperties = filteredProperties.filter(property => 
          property.buildingIndex !== undefined && property.buildingIndex !== null && property.buildingIndex <= maxIndex
        );
      }
      
      // Altezza massima (min)
      if (minBuildingHeight && !isNaN(Number(minBuildingHeight))) {
        const minHeight = Number(minBuildingHeight);
        filteredProperties = filteredProperties.filter(property => 
          property.buildingHeight !== undefined && property.buildingHeight !== null && property.buildingHeight >= minHeight
        );
      }
      
      // Altezza massima (max)
      if (maxBuildingHeight && !isNaN(Number(maxBuildingHeight))) {
        const maxHeight = Number(maxBuildingHeight);
        filteredProperties = filteredProperties.filter(property => 
          property.buildingHeight !== undefined && property.buildingHeight !== null && property.buildingHeight <= maxHeight
        );
      }

      res.json(filteredProperties);
    } catch (error) {
      console.error("Error fetching properties:", error);
      res.status(500).json({ error: "Failed to fetch properties" });
    }
  });

  app.get("/api/properties/:id", async (req, res) => {
    try {
      const propertyId = parseInt(req.params.id);
      const property = await storage.getPropertyById(propertyId);
      
      if (!property) {
        return res.status(404).json({ error: "Property not found" });
      }
      
      res.json(property);
    } catch (error) {
      console.error("Error fetching property:", error);
      res.status(500).json({ error: "Failed to fetch property" });
    }
  });

  // API routes for professionals
  app.get("/api/professionals", async (req, res) => {
    try {
      const { type, searchQuery, location } = req.query;
      
      // Crea una funzione per recuperare i professionisti dal database locale
      const getLocalProfessionals = async () => {
        let query = storage.db.select().from(storage.professionals);
        
        // Filter by professional type
        if (type) {
          query = query.where(eq(storage.professionals.type, type as string));
        }
        
        // Get all professionals
        const professionals = await query;
        
        // Apply text search if needed (in-memory filtering)
        let filteredProfessionals = professionals;
        
        // Filter by search query
        if (searchQuery && typeof searchQuery === 'string' && searchQuery.trim() !== '') {
          const lowercaseQuery = searchQuery.toLowerCase();
          filteredProfessionals = filteredProfessionals.filter(professional => 
            (professional.name && professional.name.toLowerCase().includes(lowercaseQuery)) ||
            (professional.address && professional.address.toLowerCase().includes(lowercaseQuery)) ||
            (professional.description && professional.description.toLowerCase().includes(lowercaseQuery))
          );
        }
        
        // Filter by location if specified
        if (location && typeof location === 'string' && location !== 'all') {
          filteredProfessionals = filteredProfessionals.filter(professional => 
            professional.address && professional.address.toLowerCase().includes(location.toLowerCase())
          );
        }
        
        // Filter by postal code if specified
        if (req.query.postalCode && typeof req.query.postalCode === 'string' && req.query.postalCode.trim() !== '') {
          const postalCode = req.query.postalCode;
          filteredProfessionals = filteredProfessionals.filter(professional => 
            professional.address && professional.address.toLowerCase().includes(postalCode.toLowerCase())
          );
        }
        
        return filteredProfessionals;
      };
      
      // Cerca i professionisti prima sul database locale, poi su local.ch se necessario
      let professionals;
      
      if (searchQuery && location && location !== 'all') {
        // Usa local.ch per cercare professionisti
        professionals = await searchProfessionals(
          searchQuery as string,
          location as string,
          type as string || 'architect',
          getLocalProfessionals
        );
      } else {
        // Usa solo i dati locali
        professionals = await getLocalProfessionals();
      }
      
      res.json(professionals);
    } catch (error) {
      console.error("Error fetching professionals:", error);
      res.status(500).json({ error: "Failed to fetch professionals" });
    }
  });

  app.get("/api/professionals/:id", async (req, res) => {
    try {
      const professionalId = parseInt(req.params.id);
      const professional = await storage.getProfessionalById(professionalId);
      
      if (!professional) {
        return res.status(404).json({ error: "Professional not found" });
      }
      
      res.json(professional);
    } catch (error) {
      console.error("Error fetching professional:", error);
      res.status(500).json({ error: "Failed to fetch professional" });
    }
  });

  // API routes for banks
  app.get("/api/banks", async (req, res) => {
    try {
      const { searchQuery, location } = req.query;
      
      // Get all banks
      const banks = await storage.db.select().from(storage.banks);
      
      // Apply text search if needed (in-memory filtering)
      let filteredBanks = banks;
      
      // Filter by search query
      if (searchQuery && typeof searchQuery === 'string' && searchQuery.trim() !== '') {
        const lowercaseQuery = searchQuery.toLowerCase();
        filteredBanks = filteredBanks.filter(bank => 
          (bank.name && bank.name.toLowerCase().includes(lowercaseQuery)) ||
          (bank.address && bank.address.toLowerCase().includes(lowercaseQuery)) ||
          (bank.website && bank.website.toLowerCase().includes(lowercaseQuery))
        );
      }
      
      // Filter by location if specified
      if (location && typeof location === 'string' && location !== 'all') {
        filteredBanks = filteredBanks.filter(bank => 
          bank.address && bank.address.toLowerCase().includes(location.toLowerCase())
        );
      }
      
      // Filter by postal code if specified
      if (req.query.postalCode && typeof req.query.postalCode === 'string' && req.query.postalCode.trim() !== '') {
        const postalCode = req.query.postalCode;
        filteredBanks = filteredBanks.filter(bank => 
          bank.address && bank.address.toLowerCase().includes(postalCode.toLowerCase())
        );
      }
      
      res.json(filteredBanks);
    } catch (error) {
      console.error("Error fetching banks:", error);
      res.status(500).json({ error: "Failed to fetch banks" });
    }
  });

  app.get("/api/banks/:id", async (req, res) => {
    try {
      const bankId = parseInt(req.params.id);
      const bank = await storage.getBankById(bankId);
      
      if (!bank) {
        return res.status(404).json({ error: "Bank not found" });
      }
      
      res.json(bank);
    } catch (error) {
      console.error("Error fetching bank:", error);
      res.status(500).json({ error: "Failed to fetch bank" });
    }
  });

  // WMS proxy route for cadastral map data
  app.get("/api/wms", async (req, res) => {
    try {
      // Proxy the request to the Swiss Federal WMS service
      const wmsUrl = "https://wms.geo.admin.ch/service";
      
      // Forward the request to the WMS service and return the response
      const response = await fetch(`${wmsUrl}?${new URLSearchParams(req.query as Record<string, string>)}`);
      
      if (!response.ok) {
        return res.status(response.status).json({ error: "WMS service error" });
      }
      
      const contentType = response.headers.get("content-type");
      if (contentType) {
        res.setHeader("Content-Type", contentType);
      }
      
      const buffer = await response.arrayBuffer();
      res.send(Buffer.from(buffer));
    } catch (error) {
      console.error("Error proxying WMS request:", error);
      res.status(500).json({ error: "Failed to proxy WMS request" });
    }
  });
  
  // Geocoding proxy route for address search
  app.get("/api/geocode", async (req, res) => {
    try {
      const { q, limit = "1", lang = "it" } = req.query;
      
      if (!q) {
        return res.status(400).json({ error: "Query parameter 'q' is required" });
      }
      
      // Append Ticino and Switzerland to improve results
      const query = `${q}, Ticino, Switzerland`;
      
      // Try Photon API first (better results, faster)
      try {
        console.log(`Searching with Photon API: "${query}"`);
        const photonUrl = `https://photon.komoot.io/api/?q=${encodeURIComponent(query)}&limit=${limit}&lang=${lang}`;
        console.log(`Photon URL: ${photonUrl}`);
        
        const photonResponse = await fetch(photonUrl);
        console.log(`Photon response status: ${photonResponse.status}`);
        
        if (photonResponse.ok) {
          const data = await photonResponse.json();
          console.log(`Photon results: ${data.features ? data.features.length : 0} features`);
          
          if (data.features && data.features.length > 0) {
            // Format the response in a consistent structure
            const results = {
              features: data.features.map((feature: any) => {
                const coords = feature.geometry.coordinates;
                const props = feature.properties;
                
                // Log what we're extracting
                console.log(`Found location: ${props.name || "unknown"}, ${props.street || ""} ${props.housenumber || ""}, ${props.city || ""}`);
                
                return {
                  geometry: {
                    coordinates: coords
                  },
                  properties: {
                    name: props.name || "",
                    street: props.street || "",
                    housenumber: props.housenumber || "",
                    city: props.city || "",
                    state: props.state || "",
                    country: props.country || "Switzerland"
                  }
                };
              })
            };
            
            console.log(`Returning Photon results for: ${query}`);
            return res.json(results);
          }
        }
        
        // If Photon fails, fall back to Nominatim
        console.log("Photon API failed, falling back to Nominatim");
      } catch (error) {
        console.error("Error with Photon API:", error);
        // Fall through to Nominatim
      }
      
      // Fallback to Nominatim 
      console.log(`Searching with Nominatim API: "${query}"`);
      const nominatimUrl = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=${limit}&countrycodes=ch`;
      console.log(`Nominatim URL: ${nominatimUrl}`);
      
      const nominatimResponse = await fetch(
        nominatimUrl,
        {
          headers: {
            'User-Agent': 'BoomHouse/1.0'
          }
        }
      );
      
      console.log(`Nominatim response status: ${nominatimResponse.status}`);
      
      if (!nominatimResponse.ok) {
        console.error(`Nominatim API error: ${nominatimResponse.status}`);
        return res.status(nominatimResponse.status).json({ error: "Geocoding service error" });
      }
      
      const nominatimData = await nominatimResponse.json();
      console.log(`Nominatim results: ${Array.isArray(nominatimData) ? nominatimData.length : 0} places found`);
      if (Array.isArray(nominatimData) && nominatimData.length > 0) {
        console.log("First result:", JSON.stringify(nominatimData[0], null, 2).substring(0, 200) + "...");
      }
      
      // Trasformiamo la risposta di Nominatim nel formato Photon (GeoJSON)
      if (Array.isArray(nominatimData) && nominatimData.length > 0) {
        // Convertiamo i dati in formato Photon compatibile
        const photonCompatibleData = {
          features: nominatimData.map(place => ({
            geometry: {
              coordinates: [parseFloat(place.lon), parseFloat(place.lat)]
            },
            properties: {
              name: place.display_name.split(',')[0].trim(),
              street: extractStreetFromDisplayName(place.display_name),
              housenumber: extractHouseNumberFromDisplayName(place.display_name),
              city: place.address?.city || 
                   place.address?.town || 
                   place.address?.village || 
                   extractCityFromDisplayName(place.display_name),
              state: place.address?.state || "Ticino",
              country: place.address?.country || "Switzerland"
            }
          }))
        };
        
        return res.json(photonCompatibleData);
      }
      
      // Se non ci sono risultati, restituiamo un oggetto vuoto compatibile
      return res.json({ features: [] });
      
    } catch (error) {
      console.error("Error proxying geocoding request:", error);
      res.status(500).json({ error: "Failed to geocode address" });
    }
  });

  // Favorites API routes
  app.get("/api/favorites", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Non autenticato" });
      }
      
      const userId = (req.user as any).id;
      const userFavorites = await db.select().from(favorites)
        .where(eq(favorites.userId, userId));
      
      // Ottieni i dettagli completi per ogni preferito
      const enrichedFavorites = await Promise.all(userFavorites.map(async (favorite) => {
        let itemDetails = null;
        let type = "";
        
        if (favorite.propertyId) {
          itemDetails = await storage.getPropertyById(favorite.propertyId);
          type = "property";
        } else if (favorite.professionalId) {
          itemDetails = await storage.getProfessionalById(favorite.professionalId);
          type = "professional";
        } else if (favorite.bankId) {
          itemDetails = await storage.getBankById(favorite.bankId);
          type = "bank";
        }
        
        return {
          id: favorite.id,
          type,
          details: itemDetails,
          createdAt: favorite.createdAt
        };
      }));
      
      res.json(enrichedFavorites);
    } catch (error) {
      console.error("Error fetching favorites:", error);
      res.status(500).json({ error: "Failed to fetch favorites" });
    }
  });
  
  // Add item to favorites
  app.post("/api/favorites", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Non autenticato" });
      }
      
      const userId = (req.user as any).id;
      const { propertyId, professionalId, bankId } = req.body;
      
      // Verifica che sia specificato almeno uno tra proprietà, professionista o banca
      if (!propertyId && !professionalId && !bankId) {
        return res.status(400).json({ message: "È necessario specificare un elemento da aggiungere ai preferiti" });
      }
      
      // Verifica che l'elemento non sia già tra i preferiti
      const existingFavorite = await db.select({ id: favorites.id }).from(favorites)
        .where(
          and(
            eq(favorites.userId, userId),
            propertyId ? eq(favorites.propertyId, propertyId) : 
            professionalId ? eq(favorites.professionalId, professionalId) :
            eq(favorites.bankId, bankId)
          )
        );
      
      if (existingFavorite.length > 0) {
        return res.status(409).json({ message: "Elemento già aggiunto ai preferiti" });
      }
      
      // Aggiungi ai preferiti
      const newFavorite = await db.insert(favorites).values({
        userId,
        propertyId: propertyId || null,
        professionalId: professionalId || null,
        bankId: bankId || null
      }).returning();
      
      res.status(201).json(newFavorite[0]);
    } catch (error) {
      console.error("Error adding to favorites:", error);
      res.status(500).json({ error: "Failed to add to favorites" });
    }
  });
  
  // Remove from favorites
  app.delete("/api/favorites/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Non autenticato" });
      }
      
      const userId = (req.user as any).id;
      const favoriteId = parseInt(req.params.id);
      
      // Verifica che l'elemento sia tra i preferiti dell'utente
      const existingFavorite = await db.select().from(favorites)
        .where(and(eq(favorites.id, favoriteId), eq(favorites.userId, userId)));
      
      if (existingFavorite.length === 0) {
        return res.status(404).json({ message: "Preferito non trovato" });
      }
      
      // Rimuovi dai preferiti
      await db.delete(favorites).where(eq(favorites.id, favoriteId));
      
      res.status(200).json({ message: "Elemento rimosso dai preferiti" });
    } catch (error) {
      console.error("Error removing from favorites:", error);
      res.status(500).json({ error: "Failed to remove from favorites" });
    }
  });

  // Rotta per aggiungere nuove proprietà con controllo delle immagini
  app.post("/api/properties", upload.array('images', 10), async (req, res) => {
    try {
      // Controllo autenticazione
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: "Devi essere autenticato per pubblicare un annuncio" });
      }

      const { 
        title, 
        description, 
        address, 
        price, 
        beds, 
        baths, 
        area, 
        propertyType, 
        listingType,
        landArea,
        yearBuilt,
        lat,
        lng
      } = req.body;

      // Validazione base
      if (!title || !address || !price || !propertyType || !listingType || !area) {
        return res.status(400).json({ error: "Mancano alcuni campi obbligatori" });
      }

      // Verifica che siano state caricate delle immagini
      const files = req.files as Express.Multer.File[];
      if (!files || files.length === 0) {
        return res.status(400).json({ error: "È necessario caricare almeno un'immagine" });
      }

      // Validazione coordinate
      if (!lat || !lng || isNaN(Number(lat)) || isNaN(Number(lng))) {
        return res.status(400).json({ error: "Coordinate non valide" });
      }

      // Preparazione dati per l'inserimento
      const newProperty = {
        title,
        address,
        price,
        beds: beds ? parseInt(beds) : null,
        baths: baths ? parseInt(baths) : null,
        area: parseInt(area),
        propertyType,
        listingType,
        description: description || null,
        features: [], // Array vuoto di default
        lat: parseFloat(lat),
        lng: parseFloat(lng),
        landArea: landArea ? parseInt(landArea) : null,
        yearBuilt: yearBuilt ? parseInt(yearBuilt) : null,
        // L'immagine principale è la prima caricata
        imageUrl: `/uploads/${files[0].filename}`,
        // Lista delle immagini aggiuntive
        additionalImages: files.slice(1).map(file => `/uploads/${file.filename}`),
        createdAt: new Date().toISOString(),
      };

      // Inserimento nel database
      const [property] = await db.insert(properties).values(newProperty).returning();

      // Risposta
      res.status(201).json({
        message: "Proprietà aggiunta con successo",
        property
      });
    } catch (error) {
      console.error("Error adding property:", error);
      res.status(500).json({ error: "Si è verificato un errore durante l'aggiunta della proprietà" });
    }
  });

  // Rotta per servire le immagini caricate
  if (fs.existsSync(uploadDir)) {
    app.use('/uploads', (req, res, next) => {
      // Se l'utente non è autenticato, controlla se l'immagine è pubblica
      // In questo caso specifico, consideriamo tutte le immagini come pubbliche
      // ma in un'applicazione reale potresti avere un controllo più dettagliato
      next();
    }, expressStatic(uploadDir));
  } else {
    app.use('/uploads', (req, res) => {
      res.status(404).send('Uploads directory not found');
    });
  }

  const httpServer = createServer(app);
  return httpServer;
}
