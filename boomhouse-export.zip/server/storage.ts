import { db } from "@db";
import * as schema from "@shared/schema";
import { eq } from "drizzle-orm";

export const storage = {
  db,
  properties: schema.properties,
  professionals: schema.professionals,
  banks: schema.banks,

  // Properties
  async getAllProperties() {
    return await db.select().from(schema.properties);
  },

  async getPropertyById(id: number) {
    const properties = await db
      .select()
      .from(schema.properties)
      .where(eq(schema.properties.id, id));
    
    return properties.length > 0 ? properties[0] : null;
  },

  // Professionals
  async getAllProfessionals() {
    return await db.select().from(schema.professionals);
  },

  async getProfessionalById(id: number) {
    const professionals = await db
      .select()
      .from(schema.professionals)
      .where(eq(schema.professionals.id, id));
    
    return professionals.length > 0 ? professionals[0] : null;
  },

  async getProfessionalsByType(type: string) {
    return await db
      .select()
      .from(schema.professionals)
      .where(eq(schema.professionals.type, type));
  },

  // Banks
  async getAllBanks() {
    return await db.select().from(schema.banks);
  },

  async getBankById(id: number) {
    const banks = await db
      .select()
      .from(schema.banks)
      .where(eq(schema.banks.id, id));
    
    return banks.length > 0 ? banks[0] : null;
  }
};
